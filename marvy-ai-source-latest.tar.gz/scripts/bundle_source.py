#!/usr/bin/env python3
"""
Marvy AI - Full Source Code Bundler Script.
Archives the complete, up-to-date application codebase for download.
Excludes node_modules, dist, git, and zip files.
"""

import os
import zipfile
import sys

EXCLUDE_DIRS = {
    'node_modules',
    '.git',
    'dist',
    '.aistudio',
    '__pycache__',
    '.turbo',
    '.next'
}

EXCLUDE_EXTS = {
    '.zip',
    '.tar',
    '.gz',
    '.pyc'
}

def create_source_bundle():
    workspace_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    out_root_zip = os.path.join(workspace_root, 'marvy-ai-source-latest.zip')
    out_public_dir = os.path.join(workspace_root, 'public')
    out_public_zip = os.path.join(out_public_dir, 'marvy-ai-source-latest.zip')

    os.makedirs(out_public_dir, exist_ok=True)

    print(f"📦 Packing Marvy AI source from: {workspace_root}")

    # Remove existing zips before packing
    for target in [out_root_zip, out_public_zip]:
        if os.path.exists(target):
            try:
                os.remove(target)
            except Exception as e:
                print(f"Notice: could not remove old {target}: {e}")

    file_count = 0
    with zipfile.ZipFile(out_root_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(workspace_root):
            # Prune excluded directories in-place
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith('.git')]

            for file in files:
                # Exclude unwanted extensions and specific files
                _, ext = os.path.splitext(file)
                if ext in EXCLUDE_EXTS:
                    continue
                if file.startswith('.') and file not in ['.env.example', '.gitignore']:
                    continue

                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, workspace_root)

                # Skip if inside public and is an existing zip
                if rel_path.endswith('.zip'):
                    continue

                zf.write(full_path, rel_path)
                file_count += 1

    # Copy to public folder so browser can serve static download
    import shutil
    shutil.copyfile(out_root_zip, out_public_zip)

    size_kb = os.path.getsize(out_root_zip) / 1024
    print(f"✅ Source bundle successfully created!")
    print(f"   Files archived: {file_count}")
    print(f"   Bundle size: {size_kb:.2f} KB")
    print(f"   Paths: {out_root_zip} & {out_public_zip}")

if __name__ == '__main__':
    create_source_bundle()
