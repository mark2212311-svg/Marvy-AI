import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { apiHandler } from './server/api.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  // Middleware for CORS (allows Android APK WebViews & external clients to connect)
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(204);
    }
    next();
  });

  // Middleware for JSON body parsing
  app.use(express.json({ limit: '10mb' }));

  // API router
  // Unknown /api routes get a JSON 404 (never the SPA index.html), and async errors are caught.
  app.use('/api', (req, res) => {
    apiHandler(req, res).catch((err) => {
      console.error('[Marvy API] Unhandled error:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Internal server error' });
      }
    });
  });

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    // Development mode: mount Vite middlewares
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[Marvy AI] Server listening on http://0.0.0.0:${port}`);
    const cartesiaKey = (process.env.CARTESIA_API_KEY || '').trim();
    const cartesiaUsable = Boolean(cartesiaKey) && cartesiaKey !== 'your_cartesia_api_key_here';
    console.log(`[Marvy AI] NODE_ENV=${process.env.NODE_ENV || '(unset)'} CARTESIA_API_KEY usable=${cartesiaUsable} (len=${cartesiaKey.length})`);
    if (!process.env.CARTESIA_API_KEY || process.env.CARTESIA_API_KEY.trim() === 'your_cartesia_api_key_here') {
      console.warn('[Marvy AI] Paalala: walang CARTESIA_API_KEY. Hindi magsasalita si Marvy hangga\'t hindi ito nalalagay.');
    }
  });
}

startServer().catch((err) => {
  console.error('Failed to start Marvy AI server:', err);
});
