import { useState, useRef, useEffect, useCallback } from 'react';
import {
  ChatMessage,
  ConversationState,
  RobotEmotion,
  SentimentAnalysis,
  UserMemory,
  AvatarFormId,
  AVATAR_FORMS,
  AVAILABLE_GEMINI_MODELS,
  sanitizeTextForSpeech,
} from '../utils/conversation';
import {
  DEFAULT_CARTESIA_VOICE_ID,
  isValidCartesiaVoiceId,
  loadSavedCartesiaVoiceId,
  saveCartesiaVoiceId,
} from '../utils/cartesia';
import { MemoryStore } from '../utils/memoryStore';
import { sfx } from '../utils/soundEffects';
import {
  sendChatMessage,
  requestCartesiaTts,
  getCustomBackendUrl,
  setCustomBackendUrl,
  isApkOrStandaloneEnvironment,
  VisionResponsePayload,
} from '../utils/apiClient';

interface IWindow extends Window {
  webkitSpeechRecognition?: any;
  SpeechRecognition?: any;
}

const GENDER_KEY = 'marvy_voice_gender';
const AVATAR_KEY = 'marvy_avatar_form';
const MODEL_KEY = 'marvy_ai_model';
const GEMINI_KEY_KEY = 'marvy_custom_gemini_key';
const CARTESIA_KEY_KEY = 'marvy_custom_cartesia_key';
const DEFAULT_MODEL = 'gemini-3.1-flash-lite';

function readLocal(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writeLocal(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch {
    // storage unavailable — keep the in-memory value only
  }
}

export function useVoiceConversation() {
  // ---- Conversation state ----
  const [state, setState] = useState<ConversationState>('idle');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [lastAssistantMessage, setLastAssistantMessage] = useState<ChatMessage | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isHandsFree, setIsHandsFreeState] = useState<boolean>(true);
  const [isMuted, setIsMutedState] = useState<boolean>(false);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [isCallActive, setIsCallActiveState] = useState<boolean>(false);
  const [userSpeechInterim, setUserSpeechInterim] = useState<string>('');
  const [emotion, setEmotion] = useState<RobotEmotion>('happy');

  // ---- Persona & voice (persisted) ----
  const [selectedGender, setSelectedGenderState] = useState<'female' | 'male'>(() =>
    readLocal(GENDER_KEY) === 'female' ? 'female' : 'male'
  );
  const [voiceId, setVoiceIdState] = useState<string>(() => loadSavedCartesiaVoiceId());
  const [avatarForm, setAvatarFormState] = useState<AvatarFormId>(() => {
    const saved = readLocal(AVATAR_KEY);
    return AVATAR_FORMS.some((f) => f.id === saved) ? (saved as AvatarFormId) : 'quantum_core';
  });

  // ---- AI & sentiment ----
  const [aiModel, setAiModelState] = useState<string>(() => {
    const saved = readLocal(MODEL_KEY);
    return saved && AVAILABLE_GEMINI_MODELS.some((m) => m.id === saved) ? saved : DEFAULT_MODEL;
  });
  const [lastSentiment, setLastSentiment] = useState<SentimentAnalysis | undefined>(undefined);
  const [customGeminiKey, setCustomGeminiKeyState] = useState<string>(() => readLocal(GEMINI_KEY_KEY) || '');
  const [cartesiaClientKey, setCartesiaClientKeyState] = useState<string>(() => readLocal(CARTESIA_KEY_KEY) || '');
  const cartesiaClientKeyRef = useRef<string>(cartesiaClientKey);
  cartesiaClientKeyRef.current = cartesiaClientKey;

  // ---- Backend / platform ----
  const [backendUrl, setBackendUrlState] = useState<string>(() => getCustomBackendUrl());
  const [isApk] = useState<boolean>(() => isApkOrStandaloneEnvironment());

  // ---- Memory & callsign ----
  const [callsign, setCallsign] = useState<string>(() => MemoryStore.getCallsign());
  const [memories, setMemories] = useState<UserMemory[]>(() => MemoryStore.getMemories());

  // ---- Refs (always hold the latest value, so long-lived callbacks never go stale) ----
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);
  const currentAudioUrlRef = useRef<string | null>(null);
  const recognitionRef = useRef<any>(null);
  const isRecognizingRef = useRef<boolean>(false);
  const speechTokenRef = useRef<number>(0);
  const callTimerRef = useRef<any>(null);

  const stateRef = useRef<ConversationState>(state);
  const messagesRef = useRef<ChatMessage[]>(messages);
  const isHandsFreeRef = useRef<boolean>(isHandsFree);
  const isMutedRef = useRef<boolean>(isMuted);
  const isCallActiveRef = useRef<boolean>(isCallActive);
  const voiceIdRef = useRef<string>(voiceId);
  const genderRef = useRef<'female' | 'male'>(selectedGender);
  const aiModelRef = useRef<string>(aiModel);
  const avatarFormRef = useRef<AvatarFormId>(avatarForm);
  const customGeminiKeyRef = useRef<string>(customGeminiKey);
  const callsignRef = useRef<string>(callsign);

  stateRef.current = state;
  messagesRef.current = messages;
  isHandsFreeRef.current = isHandsFree;
  isMutedRef.current = isMuted;
  isCallActiveRef.current = isCallActive;
  voiceIdRef.current = voiceId;
  genderRef.current = selectedGender;
  aiModelRef.current = aiModel;
  avatarFormRef.current = avatarForm;
  customGeminiKeyRef.current = customGeminiKey;
  callsignRef.current = callsign;

  // Filled in below; lets the speech-recognition callbacks call the latest handlers.
  const handleSendMessageRef = useRef<(text: string) => Promise<void>>(async () => {});
  const startListeningRef = useRef<() => void>(() => {});

  // ---- Call duration counter ----
  useEffect(() => {
    if (isCallActive) {
      callTimerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
      setCallDuration(0);
    }
    return () => {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    };
  }, [isCallActive]);

  const setIsCallActive = useCallback((value: boolean) => {
    isCallActiveRef.current = value;
    setIsCallActiveState(value);
  }, []);

  const setIsHandsFree = useCallback((value: boolean) => {
    isHandsFreeRef.current = value;
    setIsHandsFreeState(value);
  }, []);

  // ---- Audio helpers ----

  /** Frees the current <audio> element and its object URL. */
  const releaseAudio = useCallback(() => {
    const audio = currentAudioRef.current;
    if (audio) {
      audio.onended = null;
      audio.onerror = null;
      try {
        audio.pause();
        audio.removeAttribute('src');
        audio.load();
      } catch {
        // ignore teardown errors
      }
    }
    currentAudioRef.current = null;
    if (currentAudioUrlRef.current) {
      URL.revokeObjectURL(currentAudioUrlRef.current);
      currentAudioUrlRef.current = null;
    }
  }, []);

  /** Stops playback AND invalidates any Cartesia request still in flight. */
  const stopAudio = useCallback(() => {
    speechTokenRef.current += 1;
    releaseAudio();
  }, [releaseAudio]);

  /** Stops microphone recognition. */
  const stopListening = useCallback(() => {
    const rec = recognitionRef.current;
    if (rec && isRecognizingRef.current) {
      try {
        rec.stop();
      } catch {
        // already stopped
      }
    }
    isRecognizingRef.current = false;
    setUserSpeechInterim('');
  }, []);

  /** After Marvy finishes talking, reopen the mic in hands-free mode. */
  const finishSpeaking = useCallback(() => {
    setState('idle');
    if (isHandsFreeRef.current && isCallActiveRef.current && !isMutedRef.current) {
      setTimeout(() => {
        if (stateRef.current === 'idle' && isHandsFreeRef.current && isCallActiveRef.current) {
          startListeningRef.current();
        }
      }, 600);
    }
  }, []);

  /**
   * Speaks text with Cartesia Sonic. Newer calls supersede older ones: a late response
   * from an earlier request is discarded, so two replies never play on top of each other.
   */
  const speakText = useCallback(
    (text: string, options: { force?: boolean } = {}) => {
      stopAudio();
      const token = speechTokenRef.current;

      const clean = sanitizeTextForSpeech(text);
      if (!clean) {
        setState('idle');
        return;
      }
      if (isMutedRef.current && !options.force) {
        setState('idle');
        return;
      }

      setState('thinking');

      (async () => {
        try {
          const audioBlob = await requestCartesiaTts({
            text: clean,
            voiceId: voiceIdRef.current,
            clientApiKey: cartesiaClientKeyRef.current,
          });
          if (token !== speechTokenRef.current) return;

          const url = URL.createObjectURL(audioBlob);
          const audio = new Audio(url);
          currentAudioRef.current = audio;
          currentAudioUrlRef.current = url;

          audio.onplay = () => {
            if (token === speechTokenRef.current) setState('speaking');
          };
          audio.onended = () => {
            if (token !== speechTokenRef.current) return;
            releaseAudio();
            finishSpeaking();
          };
          audio.onerror = () => {
            if (token !== speechTokenRef.current) return;
            releaseAudio();
            setErrorMessage('Hindi napatugtog ang boses ni Marvy. Subukan muli.');
            setState('idle');
          };

          await audio.play();
        } catch (err: any) {
          if (token !== speechTokenRef.current) return;
          releaseAudio();
          const message =
            err?.name === 'NotAllowedError'
              ? 'I-tap ang robot para marinig si Marvy (kailangan ng interaksyon sa browser).'
              : err?.message || 'Nagka-problema sa boses ni Marvy.';
          setErrorMessage(message);
          setState('idle');
        }
      })();
    },
    [stopAudio, releaseAudio, finishSpeaking]
  );

  // ---- Microphone ----

  const startListening = useCallback(() => {
    const win = window as unknown as IWindow;
    const SpeechRecognitionCtor = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (!SpeechRecognitionCtor) {
      setErrorMessage('Hindi suportado ang voice input sa browser na ito. Gamitin ang Usapan tab para mag-type.');
      setState('idle');
      return;
    }

    stopAudio();
    stopListening();

    try {
      const recognition = new SpeechRecognitionCtor();
      recognitionRef.current = recognition;

      recognition.lang = 'fil-PH';
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      let finalTranscript = '';

      recognition.onstart = () => {
        if (recognitionRef.current !== recognition) return;
        isRecognizingRef.current = true;
        setState('listening');
        setEmotion('listening');
        sfx.playListeningPing();
        setErrorMessage(null);
        setUserSpeechInterim('');
      };

      recognition.onresult = (event: any) => {
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const result = event.results[i];
          if (result.isFinal) {
            finalTranscript += result[0].transcript;
          } else {
            interim += result[0].transcript;
          }
        }
        setUserSpeechInterim(interim || finalTranscript);
      };

      recognition.onerror = (event: any) => {
        if (recognitionRef.current !== recognition) return;
        isRecognizingRef.current = false;
        setUserSpeechInterim('');
        switch (event?.error) {
          case 'no-speech':
          case 'aborted':
            setState('idle');
            break;
          case 'not-allowed':
          case 'service-not-allowed':
            setErrorMessage('Kailangan ng microphone permission para makapagsalita kay Marvy.');
            setState('error');
            break;
          case 'network':
            setErrorMessage('Walang koneksyon para sa voice recognition. Subukan muli.');
            setState('error');
            break;
          default:
            console.warn('Speech recognition notice:', event?.error);
            setState('idle');
        }
      };

      recognition.onend = () => {
        const isCurrent = recognitionRef.current === recognition;
        if (isCurrent) {
          isRecognizingRef.current = false;
          setUserSpeechInterim('');
        }
        const text = finalTranscript.trim();
        if (text) {
          handleSendMessageRef.current(text);
        } else if (isCurrent && stateRef.current === 'listening') {
          setState('idle');
        }
      };

      recognition.start();
    } catch (err) {
      console.error('Failed to start speech recognition:', err);
      setErrorMessage('Hindi masimulan ang mikropono. Pakisubukan muli.');
      setState('error');
    }
  }, [stopAudio, stopListening]);

  startListeningRef.current = startListening;

  const stopAll = useCallback(() => {
    stopAudio();
    stopListening();
    setState('idle');
    setEmotion('neutral');
    setErrorMessage(null);
    setUserSpeechInterim('');
    sfx.playCallEnd();
  }, [stopAudio, stopListening]);

  // ---- Chat ----

  const handleSendMessage = useCallback(
    async (userText: string) => {
      const trimmed = userText.trim();
      if (!trimmed) return;

      if (!isCallActiveRef.current) {
        setIsCallActive(true);
        sfx.playCallConnect();
      }

      stopAudio();
      stopListening();
      setErrorMessage(null);
      setUserSpeechInterim('');

      const userMessage: ChatMessage = {
        id: `user-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        role: 'user',
        text: trimmed,
        timestamp: Date.now(),
      };

      const history = messagesRef.current.map((m) => ({ role: m.role, text: m.text }));
      setMessages((prev) => [...prev, userMessage]);
      setState('thinking');
      setEmotion('thinking');

      try {
        const chatData = await sendChatMessage({
          message: trimmed,
          history,
          voiceGender: genderRef.current,
          userCallsign: callsignRef.current,
          memoriesContext: MemoryStore.getFormattedContext(),
          aiModel: aiModelRef.current,
          activeAvatarForm: avatarFormRef.current,
          customGeminiKey: customGeminiKeyRef.current || undefined,
        });

        const aiReplyText: string = chatData.reply || '';
        const sentiment: SentimentAnalysis | undefined = chatData.sentiment;
        const robotEmotion: RobotEmotion = chatData.robotEmotion || 'happy';

        setEmotion(robotEmotion);
        if (sentiment) {
          setLastSentiment(sentiment);
          MemoryStore.logMood(sentiment.primaryMood, sentiment.moodLabel, trimmed);
        }

        if (chatData.newMemory && chatData.newMemory.key && chatData.newMemory.value) {
          MemoryStore.addMemory(
            chatData.newMemory.key,
            chatData.newMemory.value,
            chatData.newMemory.category || 'personal'
          );
          setMemories(MemoryStore.getMemories());
        }

        const assistantMessage: ChatMessage = {
          id: `asst-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          role: 'assistant',
          text: aiReplyText,
          emotion: robotEmotion,
          sentiment,
          timestamp: Date.now(),
        };

        setMessages((prev) => [...prev, assistantMessage]);
        setLastAssistantMessage(assistantMessage);
        speakText(aiReplyText);
      } catch (chatErr: any) {
        console.error('Chat error:', chatErr);
        setErrorMessage(chatErr?.message || 'Nagkaroon ng problema sa pakikipag-usap kay Marvy.');
        setState('error');
        setEmotion('confused');
      }
    },
    [setIsCallActive, stopAudio, stopListening, speakText]
  );

  handleSendMessageRef.current = handleSendMessage;

  const repeatLastAnswer = useCallback(() => {
    if (stateRef.current === 'speaking') {
      stopAudio();
      setState('idle');
      return;
    }
    if (!lastAssistantMessage) return;
    speakText(lastAssistantMessage.text, { force: true });
  }, [lastAssistantMessage, stopAudio, speakText]);

  const speakMessage = useCallback(
    (msg: ChatMessage) => {
      speakText(msg.text, { force: true });
    },
    [speakText]
  );

  // ---- Settings ----

  const switchGender = useCallback((gender: 'female' | 'male') => {
    genderRef.current = gender;
    setSelectedGenderState(gender);
    writeLocal(GENDER_KEY, gender);
  }, []);

  /** Saves a Cartesia voice ID. Returns false (and changes nothing) if the ID is not valid. */
  const setVoiceId = useCallback((id: string): boolean => {
    if (!isValidCartesiaVoiceId(id)) return false;
    const clean = id.trim();
    voiceIdRef.current = clean;
    setVoiceIdState(clean);
    saveCartesiaVoiceId(clean);
    return true;
  }, []);

  const resetVoiceId = useCallback(() => {
    voiceIdRef.current = DEFAULT_CARTESIA_VOICE_ID;
    setVoiceIdState(DEFAULT_CARTESIA_VOICE_ID);
    saveCartesiaVoiceId(DEFAULT_CARTESIA_VOICE_ID);
  }, []);

  const setAiModel = useCallback((modelId: string) => {
    aiModelRef.current = modelId;
    setAiModelState(modelId);
    writeLocal(MODEL_KEY, modelId);
  }, []);

  const setAvatarForm = useCallback((form: AvatarFormId) => {
    avatarFormRef.current = form;
    setAvatarFormState(form);
    writeLocal(AVATAR_KEY, form);
  }, []);

  const updateGeminiKey = useCallback((key: string) => {
    customGeminiKeyRef.current = key;
    setCustomGeminiKeyState(key);
    writeLocal(GEMINI_KEY_KEY, key);
  }, []);

  const updateCartesiaClientKey = useCallback((key: string) => {
    cartesiaClientKeyRef.current = key;
    setCartesiaClientKeyState(key);
    writeLocal(CARTESIA_KEY_KEY, key);
  }, []);

  const updateBackendUrl = useCallback((url: string) => {
    setBackendUrlState(url);
    setCustomBackendUrl(url);
  }, []);

  const updateCallsign = useCallback((newCallsign: string) => {
    const clean = newCallsign.trim() || 'Boss';
    callsignRef.current = clean;
    setCallsign(clean);
    MemoryStore.setCallsign(clean);
  }, []);

  const toggleMute = useCallback(() => {
    const next = !isMutedRef.current;
    isMutedRef.current = next;
    setIsMutedState(next);
    if (next) {
      stopAudio();
      if (stateRef.current === 'speaking') setState('idle');
    }
  }, [stopAudio]);

  // ---- Memory ----

  const addMemory = useCallback((key: string, value: string, category: UserMemory['category']) => {
    MemoryStore.addMemory(key, value, category);
    setMemories(MemoryStore.getMemories());
  }, []);

  const removeMemory = useCallback((id: string) => {
    MemoryStore.removeMemory(id);
    setMemories(MemoryStore.getMemories());
  }, []);

  const clearAllMemories = useCallback(() => {
    MemoryStore.clearAll();
    setMemories([]);
  }, []);

  // ---- Vision ----

  const handleVisionResponse = useCallback(
    (payload: VisionResponsePayload) => {
      const userMsg: ChatMessage = {
        id: `user-vision-${Date.now()}`,
        role: 'user',
        text: '📸 [Nagpakita ng imahe sa Neural Optical Eyes ni Marvy]',
        timestamp: Date.now(),
      };
      const assistantMsg: ChatMessage = {
        id: `assistant-vision-${Date.now()}`,
        role: 'assistant',
        text: payload.reply,
        timestamp: Date.now(),
        emotion: payload.robotEmotion || 'happy',
        sentiment: payload.sentiment,
      };

      setMessages((prev) => [...prev, userMsg, assistantMsg]);
      setLastAssistantMessage(assistantMsg);
      setEmotion(payload.robotEmotion || 'happy');
      if (payload.sentiment) setLastSentiment(payload.sentiment);

      speakText(payload.cleanSpeechText || payload.reply);
    },
    [speakText]
  );

  // ---- Unmount cleanup ----
  useEffect(() => {
    return () => {
      stopAudio();
      stopListening();
    };
  }, [stopAudio, stopListening]);

  return {
    state,
    messages,
    lastAssistantMessage,
    errorMessage,
    userSpeechInterim,
    isHandsFree,
    isMuted,
    isCallActive,
    callDuration,
    emotion,
    selectedGender,
    voiceId,
    avatarForm,
    aiModel,
    lastSentiment,
    customGeminiKey,
    cartesiaClientKey,
    updateCartesiaClientKey,
    backendUrl,
    isApk,
    callsign,
    memories,
    setEmotion,
    setIsCallActive,
    setIsHandsFree,
    setAvatarForm,
    setAiModel,
    switchGender,
    setVoiceId,
    resetVoiceId,
    startListening,
    stopListening,
    stopAll,
    handleSendMessage,
    repeatLastAnswer,
    speakMessage,
    toggleMute,
    handleVisionResponse,
    clearError: () => setErrorMessage(null),
    updateCallsign,
    addMemory,
    removeMemory,
    clearAllMemories,
    updateBackendUrl,
    updateGeminiKey,
  };
}
