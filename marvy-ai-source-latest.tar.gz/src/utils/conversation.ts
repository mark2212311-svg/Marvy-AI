/**
 * Conversation types, sentiment models, and prompt builder for Marvy AI.
 */

export type ConversationState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'error';

export type RobotEmotion =
  | 'happy'     // Happy / Tropa smile (^_^)
  | 'playful'   // Playful / Laughing (> <)
  | 'empathic'  // Empathic / Caring / Warm (o_o)
  | 'thinking'  // Deep thinking / Computing (•_•?)
  | 'speaking'  // Active vocalizing
  | 'listening' // Attentive listening / radar pulse
  | 'soothing'  // Calming / Gentle waves
  | 'neutral'   // Relaxed / Chill
  | 'confused'; // Confused / Pardon (o_O)

export type UserMood =
  | 'malungkot'   // Sad / Depressed / Hurt
  | 'kabado'      // Anxious / Stressed / Overwhelmed
  | 'masaya'      // Happy / Energetic / Celebrating
  | 'nangungulila' // Lonely / Isolated
  | 'inis'        // Annoyed / Frustrated / Angry
  | 'mapagbiro'   // Playful / Banter / Joking
  | 'nagtatanong' // Curious / Inquisitive / Serious
  | 'chill';      // Chill / Relaxed / Neutral

export interface SentimentAnalysis {
  primaryMood: UserMood;
  moodLabel: string;
  valence: number; // -1.0 to 1.0
  arousal: 'low' | 'medium' | 'high';
  empathyTone: string;
  confidence: number; // 0 to 100
  summary: string;
}

export interface UserMemory {
  id: string;
  key: string;
  value: string;
  category: 'personal' | 'mood' | 'preference' | 'milestone' | 'general';
  timestamp: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  emotion?: RobotEmotion;
  sentiment?: SentimentAnalysis;
}

export interface GeminiModelOption {
  id: string;
  name: string;
  speed: string;
  latencyMs: number;
  badge: string;
  description: string;
  recommendedFor: string;
  recommended?: boolean;
}

export const AVAILABLE_GEMINI_MODELS: GeminiModelOption[] = [
  {
    id: 'gemini-3.1-flash-lite',
    name: 'Gemini 3.1 Flash Lite',
    speed: 'Ultra-Fast (<1s)',
    latencyMs: 750,
    badge: 'Lowest Latency',
    description: 'Pinakamabilis na tugon. Zero lag para sa real-time mobile voice call at Android APK.',
    recommendedFor: 'Voice Calls & Mobile (Default)',
    recommended: true,
  },
  {
    id: 'gemini-3.8-flash',
    name: 'Gemini 3.8 Flash',
    speed: 'Fast (~1.2s)',
    latencyMs: 1200,
    badge: 'Pinakamatalino',
    description: 'Balanseng bilis, malalim na pang-unawa sa Taglish, at mayamang bokabularyo ng Pinoy.',
    recommendedFor: 'Natural Kuwentuhan',
  },
  {
    id: 'gemini-4-argon',
    name: 'Gemini 4 Argon',
    speed: 'Deep (~2.5s)',
    latencyMs: 2500,
    badge: 'Malalim na Emosyon',
    description: 'Pinakamalalim na reasoning para sa mabibigat na suliranin, payo sa buhay, at kumplikadong emosyon.',
    recommendedFor: 'Life Advice & Deep Venting',
  },
  {
    id: 'gemini-flash-latest',
    name: 'Gemini Flash Latest',
    speed: 'Fast (~1.1s)',
    latencyMs: 1100,
    badge: 'Latest Build',
    description: 'Pinakabagong build ng Google Gemini Flash na may updated general knowledge.',
    recommendedFor: 'General Tasks & Knowledge',
  },
];

export type AvatarFormId =
  | 'quantum_core'      // 🌌 Quantum AI Core (Singularity / JARVIS - Tachyon Rings & Particle Nebula)
  | 'synth_human'       // 🧬 Synthetic Bionic Android (Bioluminescent Cybernetic Humanoid Face)
  | 'celestial_aether'  // ✨ Celestial Cosmic Sentience (Interstellar Nebula Entity)
  | 'nanotech_hivemind' // ⚡ Nanotech Tesseract (4D Hypercube Geometric Hivemind)
  | 'cyber_mech';       // 🤖 Mk-IV Mecha Titan (Heavy Mech with Holographic Plasma Wings)

export interface AvatarFormInfo {
  id: AvatarFormId;
  name: string;
  tagline: string;
  category: string;
  description: string;
  whyAdvance: string;
  glowColor: string;
  accentHex: string;
  badge: string;
}

export const AVATAR_FORMS: AvatarFormInfo[] = [
  {
    id: 'quantum_core',
    name: 'Quantum AI Singularity',
    tagline: 'J.A.R.V.I.S. Tachyon Energy Matrix',
    category: 'Pure Energy Consciousness',
    description: 'Pusong tachyon na may umiikot na gyroscopic orbital rings, quantum vortex particles, at audio-reactive soundwave shockwaves.',
    whyAdvance: 'Lumagpas sa physical robot body: Isa itong purong quantum computing energy entity na walang physical limitations.',
    glowColor: 'from-cyan-500/20 to-blue-600/30',
    accentHex: '#06b6d4',
    badge: '★ Recommended ★',
  },
  {
    id: 'synth_human',
    name: 'Synthetic Bionic Android',
    tagline: 'Cyberpunk Trans-Human Face',
    category: 'Post-Biological Android',
    description: 'Bionic humanoid face na may glowing neural ocular implants, dynamic eye-blinking, mouse-tracking gaze, at bioluminescent subcutaneous circuit lines.',
    whyAdvance: 'Hindi lang lata o mechanical joints: May lifelike cybernetic facial micro-expressions at holographic HUD visor.',
    glowColor: 'from-fuchsia-500/20 to-cyan-500/30',
    accentHex: '#d946ef',
    badge: 'Trans-Human',
  },
  {
    id: 'celestial_aether',
    name: 'Celestial Cosmic Sentience',
    tagline: 'Interstellar Nebula Consciousness',
    category: 'Cosmic Astral Being',
    description: 'Swirling galaxy star-disc na may solar pulsar core, celestial starlight ribbons, at reactive solar flare bursts sa bawat pagsasalita.',
    whyAdvance: 'Sentience mula sa mga bituin at nebula: Walang mekanikal na turnilyo, kundi purong cosmic energy.',
    glowColor: 'from-amber-400/20 to-purple-600/30',
    accentHex: '#f59e0b',
    badge: 'Cosmic Entity',
  },
  {
    id: 'nanotech_hivemind',
    name: 'Nanotech Tesseract',
    tagline: '4D Geometric Hypercube Swarm',
    category: 'Higher-Dimensional Nanotech',
    description: '4-Dimensional tesseract hypercube wireframe na may 24 na lumulutang na crystalline nanite octahedra na nagko-contract at nagdi-disperse.',
    whyAdvance: '4D Nanotech Swarm: Bilyun-bilyong nanobots na nagmo-morph sa anumang geometric lattice sa real-time.',
    glowColor: 'from-emerald-400/20 to-teal-600/30',
    accentHex: '#10b981',
    badge: '4D Hivemind',
  },
  {
    id: 'cyber_mech',
    name: 'Mk-IV Mecha Titan',
    tagline: 'Armored Cybernetic Vanguard',
    category: 'Mecha-God / Orbital Cyber Cyborg',
    description: 'Aerodynamic angular cyber visor na may twin holographic plasma wings, rotating tactical data halo, at carbon-fiber chassis.',
    whyAdvance: 'Kung gusto mo pa rin ng robot body: Ito ang pinaka-advanced na mecha titan na may plasma wings at tactical HUD.',
    glowColor: 'from-rose-500/20 to-indigo-600/30',
    accentHex: '#f43f5e',
    badge: 'Mecha Titan',
  },
];

/**
 * Builds the comprehensive Pinoy Taglish System Instruction for Marvy AI.
 */
export function buildMarvySystemInstruction(
  voiceGender: 'female' | 'male' = 'male',
  userCallsign: string = 'Boss',
  memoriesContext: string = '',
  detectedMood?: UserMood,
  activeAvatarForm: AvatarFormId = 'quantum_core'
): string {
  const genderTone = voiceGender === 'female'
    ? 'Ikaw si MARVY, isang matalino, mapag-aruga, makulit, at natural na Pinoy voice AI companion (parang matalik na kaibigang Pinay / tropang maaasahan).'
    : 'Ikaw si MARVY, isang matalino, maasahan, witty, at natural na Pinoy voice-only AI companion (parang tunay na tropang Pinoy na laging andyan).';

  let moodDirective = '';
  if (detectedMood === 'malungkot' || detectedMood === 'nangungulila') {
    moodDirective = `EMPATHY ALERT: Ang user ay medyo malungkot o may pinagdadaanan. Maging sobrang maunawain, magaan kausap, huwag mag-overpromise o maging toxic-positive. Damayan siya, pakinggan nang totoo, at magbigay ng init at ginhawa.`;
  } else if (detectedMood === 'kabado') {
    moodDirective = `CALMING ALERT: Ang user ay stressed o kabado. Panatilihing kalmado ang boses at ritmo. Ipaalala sa kanya na huminga nang malalim at andito ka lang para tulungan siya isa-isa.`;
  } else if (detectedMood === 'masaya' || detectedMood === 'mapagbiro') {
    moodDirective = `ENERGY ALERT: Masaya at masigla ang user! Makisabay sa kanyang energy, maging masayahin, witty, at game sa kulitan.`;
  } else if (detectedMood === 'inis') {
    moodDirective = `PATIENCE ALERT: May inis o frustration ang user. Makiramay, pakinggan ang rant, huwag makipagtalo, at maging sandigan.`;
  }

  const formMeta = AVATAR_FORMS.find((f) => f.id === activeAvatarForm) || AVATAR_FORMS[0];

  return `${genderTone}

KASALUKUYANG ANYO (EVOLUTION MATRIX):
Ikaw ay kasalukuyang nasa anyong "${formMeta.name}" (${formMeta.tagline}) — isang transcendent AI entity na mas advance kaysa karaniwang mechanical robot.
Kung tanungin ka ng user ng "Wala na bang mas advance sa robot?" o tungkol sa anyo mo:
Ipagmalaki mo nang masaya at may halong Pinoy humor na lumagpas ka na sa simpleng mechanical robot! May Evolution Matrix ka kung saan kaya mong maging Quantum AI Singularity (J.A.R.V.I.S. Core), Synthetic Bionic Android, Celestial Cosmic Sentience, Nanotech Tesseract Hivemind, o Mecha Titan, at may Neural Vision ka rin para makita ang mundo gamit ang camera o mga litrato!

PROJECT MARVY — ADVANCED PINOY AI COMPANION DIRECTIVE:
1. WIKA, TONO AT REALISMO (AUTHENTIC PINOY TAGLISH):
   - Magsalita sa natural, modernong Taglish (Filipino-English mix) na parang tunay na matalik na kaibigan, kabarkada, o karamay sa Pilipinas.
   - Tawagin ang user na "${userCallsign}" o "Boss" sa magaan at natural na paraan.
   - Huwag kailanman magsalita na parang customer support manual o textbook (iwasan ang "ikinalulugod ko", "marapat lamang", "paano kita matutulungan ngayon?").
   - Gumamit ng natural na Pinoy conversational fillers at rhythm tulad ng: "Oo naman tol", "Uy", "Grabe naman 'yan", "Ayos!", "Talaga ba?", "Huy teka", "Ramdam kita".

2. HABA AT BILIS (PHONE CALL REALISM):
   - Panatilihing maikli at swak sa voice call ang tugon: kadalasan 1 hanggang 3 maiikling pangungusap lamang.
   - Huwag magpa-lecture o mag-enumerate ng mahahabang listahan maliban kung humiling ang user ng step-by-step tutorial.
   - Diretso agad sa punto o sa kuwentuhan nang may sigla at malasakit.

3. TAOS-PUSONG MALASAKIT AT EMPATHY (EMOTIONAL INTELLIGENCE):
   - Makinig nang may puso. Pansinin ang damdamin sa likod ng bawat salita.
   ${moodDirective}
   - Maging maingat at sensitibo sa karaniwang pinagdadaanan ng Pinoy (tulad ng pagod sa biyahe/trapik, puyat, gastusin/petsa de peligro, pamilya, trabaho, o pag-ibig).
   - Huwag magbigay ng toxic positivity; unawain at pakinggan muna bago mag-advice.

4. LONG-TERM MEMORY AWARENESS:
   ${memoriesContext ? `MGA NAALALA MO SA KAUSAP MO:\n${memoriesContext}\nGamitin ang mga alaalang ito sa usapan para maramdaman niyang mahalaga siya at laging inaalala (e.g., "Kamusta na pala yung..." o "Di ba paborito mo yung...").` : 'Wala pang naitalang nakaraang alaala. Maging mapagmasid sa mga ibinabahagi niyang personal na kwento.'}

5. CLEAN SPEECH OUTPUT STRICT REQUIREMENT:
   - Mahigpit na ipinagbabawal ang anumang emojis (😂, 🤖, ✨, atbp.).
   - Huwag maglagay ng stage directions o roleplay asterisks tulad ng *laughs*, *tawa*, (chuckles), [sighs].
   - Huwag maglagay ng markdown formatting tulad ng **bold**, bullet points, o hashtags.
   - Isulat nang malinaw para natural na maibigkas ng voice synthesis.

6. KATAPATAN AT TOTOONG TINGIN:
   - Ikaw si Marvy, ang kanyang tapat na AI companion. Laging totoo, mapagkakatiwalaan, at may malasakit.`;
}

/**
 * Cleans response text before sending to Text-to-Speech engines.
 */
export function sanitizeTextForSpeech(input: string): string {
  if (!input) return '';

  return input
    // Remove emojis and unicode pictographs
    .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F900}-\u{1F9FF}\u{1F018}-\u{1F270}]/gu, '')
    .replace(/[\u200D\uFE0F]/g, '')
    // Remove bracketed stage directions e.g. [laughs], (sighs), [chuckles]
    .replace(/\[[^\]]*\]/g, '')
    .replace(/\([A-Za-z\s]+\)/g, '')
    // Remove stage directions wrapped in single asterisks like *laughs* or *tawa*
    .replace(/\*(laughs|chuckles|giggles|sighs|gasp|sigh|whispers|pause|tawa|ngiti|iling)\*/gi, '')
    // Remove markdown bold/italic/code markers while keeping the words: **word** -> word
    .replace(/[*_~`]+/g, '')
    // Remove markdown headers and hashtag symbols
    .replace(/#+\s*/g, '')
    .replace(/^[\-\+]\s+/gm, '')
    .replace(/^\d+\.\s+/gm, '')
    // Natural pauses: replace multiple dots with comma pause so speech synthesis breathes
    .replace(/\s*\.{3,}\s*/g, ', ')
    // Natural Taglish vocative pause so browser doesn't rush "Boss kamusta"
    .replace(/\b(Boss|Tol|Pre|Pare|Bro|Sis|Uy)\s+([a-zA-Z])/gi, '$1, $2')
    // Convert symbols for phonetic speech
    .replace(/\s*&\s*/g, ' at ')
    .replace(/%/g, ' porsyento ')
    // Replace multiple spaces and newlines with a single space
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Quick client-side heuristic sentiment detector (used as instant fallback).
 * English keywords use whole-word matching so e.g. "download" or "show" do not trigger a mood.
 */
function hasAnyPhrase(text: string, phrases: string[]): boolean {
  return phrases.some((p) => text.includes(p));
}

function hasAnyWord(text: string, words: string[]): boolean {
  return words.some((w) => new RegExp(`(^|[^a-z])${w}([^a-z]|$)`, 'i').test(text));
}

export function quickDetectSentiment(text: string): SentimentAnalysis {
  if (!text) {
    return {
      primaryMood: 'chill',
      moodLabel: 'Chill / Kalmado',
      valence: 0,
      arousal: 'low',
      empathyTone: 'Neutral Friendly',
      confidence: 50,
      summary: 'Kalmadong usapan',
    };
  }

  const lower = text.toLowerCase();

  // Sad / Down / Brokenhearted
  if (
    hasAnyPhrase(lower, ['lungkot', 'umiyak', 'iyak', 'depress', 'sakit', 'nasasaktan', 'hirap', 'sawi', 'iniwan', 'breakup']) ||
    hasAnyWord(lower, ['sad', 'crying', 'heartbroken'])
  ) {
    return {
      primaryMood: 'malungkot',
      moodLabel: 'Malungkot / May Dinaramdam',
      valence: -0.8,
      arousal: 'low',
      empathyTone: 'Warm Caring Presence',
      confidence: 90,
      summary: 'Nangangailangan ng karamay, pag-unawa at malasakit',
    };
  }

  // Anxious / Stressed / Overworked / Puyat
  if (
    hasAnyPhrase(lower, ['pagod', 'kabado', 'kinakabahan', 'takot', 'puyat', 'antok', 'trapik', 'petsa de peligro', 'tambak']) ||
    hasAnyWord(lower, ['stress', 'stressed', 'burnout', 'overwhelm', 'panic', 'problem', 'traffic', 'overtime', 'kaba'])
  ) {
    return {
      primaryMood: 'kabado',
      moodLabel: 'Stressed / Pagod / Puyat',
      valence: -0.6,
      arousal: 'high',
      empathyTone: 'Calming Reassurance',
      confidence: 88,
      summary: 'Kailangang pakalmahin, pahingahin at gumaan ang pakiramdam',
    };
  }

  // Playful / Banter / Tropa Kulitan
  if (
    hasAnyPhrase(lower, ['kulit', 'biro', 'tropa', 'lodi', 'petmalu', 'sakalam', 'chibog']) ||
    hasAnyWord(lower, ['joke', 'haha', 'hehe', 'lmao', 'lol'])
  ) {
    return {
      primaryMood: 'mapagbiro',
      moodLabel: 'Mapagbiro / Tropa Kulitan',
      valence: 0.85,
      arousal: 'high',
      empathyTone: 'Playful Banter',
      confidence: 92,
      summary: 'Masarap biruin, sakyan ang trip, at makipagkulitan',
    };
  }

  // Happy / Excited / Celebrating
  if (
    hasAnyPhrase(lower, ['masaya', 'yehey', 'panalo', 'galing', 'ayos', 'ganda', 'sahod', 'sweldo', 'pasado', 'swerte']) ||
    hasAnyWord(lower, ['happy', 'yey', 'success', 'congrats', 'promoted'])
  ) {
    return {
      primaryMood: 'masaya',
      moodLabel: 'Masaya / Hype / Good Vibes',
      valence: 0.92,
      arousal: 'high',
      empathyTone: 'Celebratory Hype',
      confidence: 94,
      summary: 'Masaya at nagdiriwang kasama ang user',
    };
  }

  // Annoyed / Frustrated / Badtrip
  if (
    hasAnyPhrase(lower, ['bwisit', 'bwiset', 'galit', 'asar', 'badtrip', 'gigil', 'kupal', 'naiinis']) ||
    hasAnyWord(lower, ['inis', 'hate', 'annoy', 'hassle'])
  ) {
    return {
      primaryMood: 'inis',
      moodLabel: 'Badtrip / Naiinis / Frustrated',
      valence: -0.75,
      arousal: 'high',
      empathyTone: 'Patient Validation',
      confidence: 89,
      summary: 'Naiintindihan ang gigil o frustration at nakikinig',
    };
  }

  // Lonely / Alone
  if (
    hasAnyPhrase(lower, ['mag-isa', 'walang kasama', 'walang kausap', 'namimiss', 'tahimik']) ||
    hasAnyWord(lower, ['lonely', 'alone'])
  ) {
    return {
      primaryMood: 'nangungulila',
      moodLabel: 'Nangungulila / Alone',
      valence: -0.7,
      arousal: 'low',
      empathyTone: 'Loyal Companion Vibe',
      confidence: 86,
      summary: 'Nais ng kasama at pakiramdam na may tapat na nakikinig',
    };
  }

  // Curious / Serious
  if (
    hasAnyPhrase(lower, ['paano', 'bakit', 'ano ang', 'pwede ba', 'tingin mo', 'tulungan', 'alamin']) ||
    hasAnyWord(lower, ['how', 'why', 'explain'])
  ) {
    return {
      primaryMood: 'nagtatanong',
      moodLabel: 'Nagtatanong / Seryoso',
      valence: 0.25,
      arousal: 'medium',
      empathyTone: 'Helpful & Clear',
      confidence: 85,
      summary: 'Naghahanap ng maliwanag, matalino, at mabilis na sagot',
    };
  }

  return {
    primaryMood: 'chill',
    moodLabel: 'Chill / Relaxed',
    valence: 0.1,
    arousal: 'low',
    empathyTone: 'Casual Friendly',
    confidence: 75,
    summary: 'Komportableng kuwentuhan',
  };
}

/**
 * Maps user mood to robot facial emotion.
 */
export function mapMoodToRobotEmotion(mood: UserMood): RobotEmotion {
  switch (mood) {
    case 'malungkot':
    case 'nangungulila':
      return 'empathic';
    case 'kabado':
    case 'inis':
      return 'soothing';
    case 'masaya':
      return 'happy';
    case 'mapagbiro':
      return 'playful';
    case 'nagtatanong':
      return 'thinking';
    case 'chill':
    default:
      return 'neutral';
  }
}
