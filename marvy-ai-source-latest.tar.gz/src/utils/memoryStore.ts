/**
 * Long-term Memory Tracking and Mood History Store for Marvy AI.
 * Persists in localStorage with auto-extraction and context injection.
 */
import { UserMemory, UserMood } from './conversation';

const MEMORY_STORAGE_KEY = 'marvy_user_memories_v1';
const CALLSIGN_STORAGE_KEY = 'marvy_user_callsign_v1';
const MOOD_HISTORY_KEY = 'marvy_mood_history_v1';

export interface MoodLogEntry {
  id: string;
  mood: UserMood;
  label: string;
  timestamp: number;
  triggerSnippet?: string;
}

export class MemoryStore {
  /**
   * Get user's preferred callsign (default: "Boss")
   */
  static getCallsign(): string {
    if (typeof window === 'undefined') return 'Boss';
    try {
      return localStorage.getItem(CALLSIGN_STORAGE_KEY) || 'Boss';
    } catch {
      return 'Boss';
    }
  }

  /**
   * Set user's preferred callsign (e.g. "Boss", "Boss Samantha", "Pare", etc.)
   */
  static setCallsign(callsign: string): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(CALLSIGN_STORAGE_KEY, callsign.trim() || 'Boss');
    } catch (e) {
      console.warn('Failed to save callsign to localStorage', e);
    }
  }

  /**
   * Get all stored memories
   */
  static getMemories(): UserMemory[] {
    if (typeof window === 'undefined') return [];
    try {
      const data = localStorage.getItem(MEMORY_STORAGE_KEY);
      if (!data) {
        // Seed initial friendly memory
        const defaultMemories: UserMemory[] = [
          {
            id: 'mem-initial-1',
            key: 'Tawag sa User',
            value: 'Tinatawag na "Boss" o tropa na laging bukas sa kuwentuhan.',
            category: 'personal',
            timestamp: Date.now() - 3600000,
          },
        ];
        localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(defaultMemories));
        return defaultMemories;
      }
      return JSON.parse(data);
    } catch (e) {
      console.warn('Failed to load memories', e);
      return [];
    }
  }

  /**
   * Add a new memory item
   */
  static addMemory(key: string, value: string, category: UserMemory['category'] = 'general'): UserMemory {
    const memories = this.getMemories();
    
    // Check if key already exists, update instead of duplicating
    const existingIndex = memories.findIndex(
      (m) => m.key.toLowerCase().trim() === key.toLowerCase().trim()
    );

    const newMemory: UserMemory = {
      id: `mem-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      key: key.trim(),
      value: value.trim(),
      category,
      timestamp: Date.now(),
    };

    if (existingIndex >= 0) {
      memories[existingIndex] = newMemory;
    } else {
      memories.unshift(newMemory);
    }

    // Keep up to 50 key memories
    const trimmed = memories.slice(0, 50);

    try {
      localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(trimmed));
    } catch (e) {
      console.warn('Failed to save memory', e);
    }

    return newMemory;
  }

  /**
   * Remove a memory item by ID
   */
  static removeMemory(id: string): void {
    const memories = this.getMemories().filter((m) => m.id !== id);
    try {
      localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(memories));
    } catch (e) {
      console.warn('Failed to delete memory', e);
    }
  }

  /**
   * Clear all memories
   */
  static clearAll(): void {
    try {
      localStorage.removeItem(MEMORY_STORAGE_KEY);
      localStorage.removeItem(MOOD_HISTORY_KEY);
    } catch (e) {
      console.warn('Failed to clear memory', e);
    }
  }

  /**
   * Format memories into a concise text block for the AI prompt
   */
  static getFormattedContext(): string {
    const memories = this.getMemories();
    if (!memories.length) return '';

    return memories
      .slice(0, 15) // Top 15 most recent/relevant
      .map((m) => `• [${m.key}]: ${m.value}`)
      .join('\n');
  }

  /**
   * Get mood history
   */
  static getMoodHistory(): MoodLogEntry[] {
    if (typeof window === 'undefined') return [];
    try {
      const data = localStorage.getItem(MOOD_HISTORY_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  /**
   * Record a mood change
   */
  static logMood(mood: UserMood, label: string, triggerSnippet?: string): void {
    const history = this.getMoodHistory();
    const entry: MoodLogEntry = {
      id: `mood-${Date.now()}`,
      mood,
      label,
      timestamp: Date.now(),
      triggerSnippet: triggerSnippet?.slice(0, 100),
    };

    // Avoid duplicate rapid logging
    if (history.length > 0 && history[0].mood === mood && Date.now() - history[0].timestamp < 30000) {
      return;
    }

    history.unshift(entry);
    const trimmed = history.slice(0, 30); // Keep last 30 mood data points

    try {
      localStorage.setItem(MOOD_HISTORY_KEY, JSON.stringify(trimmed));
    } catch (e) {
      console.warn('Failed to save mood history', e);
    }
  }
}
