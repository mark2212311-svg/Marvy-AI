/**
 * API Client with automatic APK, Android WebView, and Cloud Server fallback.
 * Solves "HTTP 404" when the app is converted to an APK (zip-to-apk).
 */
import { GoogleGenAI } from '@google/genai';
import {
  buildMarvySystemInstruction,
  sanitizeTextForSpeech,
  quickDetectSentiment,
  mapMoodToRobotEmotion,
  RobotEmotion,
  SentimentAnalysis,
  UserMemory,
  UserMood,
  AvatarFormId,
} from './conversation';
import { DEFAULT_CARTESIA_VOICE_ID, isValidCartesiaVoiceId, CARTESIA_MODEL_ID, CARTESIA_API_VERSION, CARTESIA_MAX_TEXT_CHARS } from './cartesia';

// Default hosted Cloud Run server for APK & WebView connections
export const DEFAULT_HOSTED_SERVER_URL =
  'https://ais-pre-7wh6u65htx35vxf4maqdmg-790692688261.asia-southeast1.run.app';

const BACKEND_URL_STORAGE_KEY = 'marvy_custom_backend_url';

export function getCustomBackendUrl(): string {
  if (typeof window === 'undefined') return DEFAULT_HOSTED_SERVER_URL;
  try {
    return localStorage.getItem(BACKEND_URL_STORAGE_KEY) || DEFAULT_HOSTED_SERVER_URL;
  } catch {
    return DEFAULT_HOSTED_SERVER_URL;
  }
}

export function setCustomBackendUrl(url: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(BACKEND_URL_STORAGE_KEY, url.trim().replace(/\/+$/, ''));
  } catch (e) {
    console.warn('Failed to save backend URL', e);
  }
}

/**
 * Detects if the app is running in an environment without a local Node.js backend
 * (such as an Android APK, Capacitor, Cordova, or file:// protocol).
 */
export function isApkOrStandaloneEnvironment(): boolean {
  if (typeof window === 'undefined') return false;

  const protocol = window.location.protocol;
  const origin = window.location.origin;

  // file:///android_asset/ or file://
  if (protocol === 'file:') return true;
  if (origin === 'null' || !origin) return true;

  // Standard webview local domains with no backend port
  if (
    (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') &&
    window.location.port !== '3000' &&
    window.location.port !== '5173'
  ) {
    return true;
  }

  return false;
}

/**
 * Returns candidate API base URLs to try in order of priority.
 */
function getApiCandidates(): string[] {
  const isApk = isApkOrStandaloneEnvironment();
  const customUrl = getCustomBackendUrl();
  const candidates: string[] = [];

  if (isApk) {
    // In APK mode, prioritize the live Cloud Server first
    if (customUrl) candidates.push(customUrl);
    candidates.push(DEFAULT_HOSTED_SERVER_URL);
    candidates.push('');
  } else {
    // In regular web mode, prioritize relative /api only
    candidates.push('');
    if (customUrl && customUrl !== DEFAULT_HOSTED_SERVER_URL) {
      candidates.push(customUrl);
    }
  }

  // De-duplicate
  return Array.from(new Set(candidates));
}

export interface ChatResponsePayload {
  reply: string;
  cleanSpeechText: string;
  sentiment: SentimentAnalysis;
  robotEmotion: RobotEmotion;
  newMemory: UserMemory | null;
}

/**
 * Performs client-side direct Gemini generation as a reliable fallback
 * if no backend server is reachable (e.g. offline APK with personal key).
 */
async function callClientSideGemini(
  apiKey: string,
  message: string,
  history: Array<{ role: 'user' | 'assistant'; text: string }>,
  voiceGender: 'female' | 'male',
  userCallsign: string,
  memoriesContext: string,
  aiModel: string
): Promise<ChatResponsePayload> {
  const ai = new GoogleGenAI({ apiKey });
  const fallbackSentiment = quickDetectSentiment(message);

  const systemInstruction = `${buildMarvySystemInstruction(
    voiceGender,
    userCallsign,
    memoriesContext,
    fallbackSentiment.primaryMood
  )}

OUTPUT FORMAT INSTRUCTION:
You MUST respond with valid JSON containing the spoken response, emotional sentiment analysis, and any key memory:
{
  "reply": "Your natural Pinoy Taglish speech response. Strictly NO emojis, NO markdown formatting, 1-3 spoken phone sentences.",
  "sentiment": {
    "primaryMood": "malungkot" | "kabado" | "masaya" | "nangungulila" | "inis" | "mapagbiro" | "nagtatanong" | "chill",
    "moodLabel": "Mood in Tagalog/English",
    "valence": -1.0 to 1.0,
    "arousal": "low" | "medium" | "high",
    "empathyTone": "Tone description",
    "confidence": 0 to 100,
    "summary": "Short explanation"
  },
  "robotEmotion": "happy" | "playful" | "empathic" | "listening" | "thinking" | "soothing" | "neutral" | "confused",
  "newMemory": null
}`;

  const formattedContents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];
  const recentHistory = (history || []).slice(-4);
  for (const turn of recentHistory) {
    if (turn.text && turn.role) {
      formattedContents.push({
        role: turn.role === 'user' ? 'user' : 'model',
        parts: [{ text: turn.text }],
      });
    }
  }
  formattedContents.push({
    role: 'user',
    parts: [{ text: message }],
  });

  const response = await ai.models.generateContent({
    model: aiModel || 'gemini-3.1-flash-lite',
    contents: formattedContents,
    config: {
      systemInstruction,
      temperature: 0.78,
      topP: 0.95,
      responseMimeType: 'application/json',
      thinkingConfig: {
        thinkingBudget: 0,
      },
    },
  });

  const rawJson = response.text?.trim() || '{}';
  let parsed: any = {};
  try {
    parsed = JSON.parse(rawJson);
  } catch {
    parsed = {
      reply: rawJson.replace(/```json/g, '').replace(/```/g, '').trim(),
      sentiment: fallbackSentiment,
      robotEmotion: mapMoodToRobotEmotion(fallbackSentiment.primaryMood),
      newMemory: null,
    };
  }

  const reply = parsed.reply || 'Pasensya na Boss, medyo naputol ako saglit. Pwede mo bang ulitin?';
  return {
    reply,
    cleanSpeechText: sanitizeTextForSpeech(reply),
    sentiment: parsed.sentiment || fallbackSentiment,
    robotEmotion: parsed.robotEmotion || mapMoodToRobotEmotion(fallbackSentiment.primaryMood),
    newMemory: parsed.newMemory || null,
  };
}

/**
 * Sends a chat message with multi-endpoint fallback:
 * 1. Tries candidate servers (relative /api, then Hosted Cloud URL)
 * 2. Catches 404 errors (typical in APKs) and automatically falls back to Cloud Run
 * 3. If server is unreachable and client API key is provided, calls Gemini directly in browser!
 */
export async function sendChatMessage(params: {
  message: string;
  history: Array<{ role: 'user' | 'assistant'; text: string }>;
  voiceGender: 'female' | 'male';
  userCallsign: string;
  memoriesContext: string;
  aiModel: string;
  activeAvatarForm?: AvatarFormId;
  customGeminiKey?: string;
}): Promise<ChatResponsePayload> {
  const candidates = getApiCandidates();
  let lastError: any = null;

  for (const base of candidates) {
    const endpoint = `${base}/api/chat`.replace(/([^:]\/)\/+/g, '$1');

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(params.customGeminiKey ? { 'x-gemini-api-key': params.customGeminiKey } : {}),
        },
        body: JSON.stringify({
          message: params.message,
          history: params.history,
          voiceGender: params.voiceGender,
          userCallsign: params.userCallsign,
          memoriesContext: params.memoriesContext,
          aiModel: params.aiModel,
          activeAvatarForm: params.activeAvatarForm || 'quantum_core',
          customApiKey: params.customGeminiKey,
        }),
      });

      if (res.status === 404) {
        // 404 means this endpoint has no /api/chat (e.g. running inside local APK without backend)
        console.warn(`[Marvy API] ${endpoint} returned 404, trying next candidate...`);
        lastError = new Error(`HTTP 404 on ${endpoint}`);
        continue;
      }

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `Server error (HTTP ${res.status})`);
      }

      const data = await res.json();
      return data;
    } catch (err: any) {
      console.warn(`[Marvy API] Failed on candidate ${endpoint}:`, err.message);
      lastError = err;
    }
  }

  // If all servers failed and user has provided a custom Gemini key, run directly in browser
  if (params.customGeminiKey) {
    try {
      console.info('[Marvy API] Falling back to direct in-browser Gemini generation...');
      return await callClientSideGemini(
        params.customGeminiKey,
        params.message,
        params.history,
        params.voiceGender,
        params.userCallsign,
        params.memoriesContext,
        params.aiModel
      );
    } catch (directErr: any) {
      throw new Error(`Direct AI error: ${directErr.message}`);
    }
  }

  throw (
    lastError ||
    new Error(
      'Hindi makakonekta sa Marvy AI server. Kung nasa APK ka, tiyaking may internet connection ka para ma-access ang cloud server.'
    )
  );
}

/** Error returned by the server itself (not a network failure). */
class ServerAnswerError extends Error {}

/**
 * Cartesia Sonic TTS. The API key stays on the backend server; this client sends
 * only the text and the selected voice ID. Throws a readable Error on failure
 * (no silent fallback to another voice engine).
 */
async function requestCartesiaTtsViaServer(params: {
  text: string;
  voiceId?: string;
}): Promise<Blob> {
  const candidates = getApiCandidates();
  let lastError: any = null;

  const cleanText = sanitizeTextForSpeech(params.text);
  if (!cleanText) {
    throw new Error('Walang tekstong babasahin.');
  }

  const voiceId = params.voiceId && isValidCartesiaVoiceId(params.voiceId)
    ? params.voiceId.trim()
    : DEFAULT_CARTESIA_VOICE_ID;

  const payload = { text: cleanText, voice_id: voiceId };

  let notFoundCount = 0;
  const attempts: string[] = [];
  for (const base of candidates) {
    const endpoint = `${base}/api/cartesia/tts`.replace(/([^:]\/)\/+/g, '$1');
    console.info(`[Marvy TTS] trying ${endpoint || '(same origin)'}`);
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      // 404 = this host has no backend; try the next candidate.
      attempts.push(`${endpoint || '/api/cartesia/tts'} -> HTTP ${res.status}`);
      console.info(`[Marvy TTS] ${endpoint || '(same origin)'} answered HTTP ${res.status}`);
      if (res.status === 404) {
        notFoundCount += 1;
        lastError = new Error(`HTTP 404 on ${endpoint}`);
        continue;
      }
      // Any other non-OK answer is a real server reply (e.g. missing key): show it, don't retry elsewhere.
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new ServerAnswerError(errData.error || `Cartesia error (HTTP ${res.status})`);
      }
      const blob = await res.blob();
      console.info(`[Marvy TTS] audio ok from ${endpoint || '(same origin)'}, ${blob.size} bytes`);
      if (!blob.size) {
        throw new ServerAnswerError('Walang audio na natanggap mula sa Cartesia.');
      }
      return blob;
    } catch (err: any) {
      if (err instanceof ServerAnswerError) {
        throw new ServerAnswerError(`${err.message} [debug: ${endpoint} answered]`);
      }
      // Network failure on this candidate: remember it and try the next one.
      attempts.push(`${endpoint || '/api/cartesia/tts'} -> network error: ${err?.message}`);
      lastError = err;
      console.warn(`[Marvy Cartesia TTS] Failed on ${endpoint}:`, err?.message);
    }
  }

  const debugTrail = attempts.length ? ` [debug: ${attempts.join(' | ')}]` : '';
  if (notFoundCount > 0) {
    throw new Error(
      'Hindi makita ng app ang voice route sa server (404). Luma ang naka-deploy na server o hindi ito ang server na may CARTESIA_API_KEY. I-redeploy ang bagong code at ilagay ang key sa server na iyon mismo.' + debugTrail
    );
  }
  throw new Error((lastError?.message || 'Hindi makakonekta sa Cartesia voice server.') + debugTrail);
}

/** Human-readable list of the server URLs this app will try, in order. */
export function describeServerCandidates(): string[] {
  return getApiCandidates().map((base) => (base || '(same origin)'));
}

/**
 * Calls Cartesia straight from the device using the user's own key (Settings > Keys).
 * Used when no Marvy server is reachable, e.g. the APK without a hosted backend.
 */
async function requestCartesiaTtsDirect(text: string, voiceId: string, apiKey: string): Promise<Blob> {
  const res = await fetch('https://api.cartesia.ai/tts/bytes', {
    method: 'POST',
    headers: {
      'X-API-Key': apiKey,
      'Cartesia-Version': CARTESIA_API_VERSION,
      'Content-Type': 'application/json',
      'Accept': 'audio/mpeg',
    },
    body: JSON.stringify({
      model_id: CARTESIA_MODEL_ID,
      transcript: text.slice(0, CARTESIA_MAX_TEXT_CHARS),
      voice: { mode: 'id', id: voiceId },
      output_format: { container: 'mp3', sample_rate: 44100, bit_rate: 128000 },
    }),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    console.warn(`[Marvy TTS direct] Cartesia HTTP ${res.status}: ${detail.slice(0, 300)}`);
    if (res.status === 401 || res.status === 403) throw new ServerAnswerError('Mali ang Cartesia key na nilagay mo sa Settings.');
    if (res.status === 402) throw new ServerAnswerError('Naubos na ang credits ng Cartesia account mo.');
    if (res.status === 429) throw new ServerAnswerError('Naabot na ang rate limit ng Cartesia. Subukan ulit maya-maya.');
    throw new ServerAnswerError(`Cartesia error (HTTP ${res.status}).`);
  }
  const blob = await res.blob();
  if (!blob.size) throw new ServerAnswerError('Walang audio na natanggap mula sa Cartesia.');
  console.info(`[Marvy TTS direct] audio ok, ${blob.size} bytes`);
  return blob;
}

/**
 * Cartesia TTS. Tries the Marvy server first. If no server works and the user saved
 * their own Cartesia key in Settings, calls Cartesia directly from the device.
 */
export async function requestCartesiaTts(params: {
  text: string;
  voiceId?: string;
  clientApiKey?: string;
}): Promise<Blob> {
  const voiceId = params.voiceId && isValidCartesiaVoiceId(params.voiceId) ? params.voiceId.trim() : DEFAULT_CARTESIA_VOICE_ID;
  const clean = sanitizeTextForSpeech(params.text);
  try {
    return await requestCartesiaTtsViaServer({ text: clean, voiceId });
  } catch (serverErr: any) {
    const key = (params.clientApiKey || '').trim();
    if (!key) {
      throw new Error(
        `${serverErr?.message || 'Hindi maabot ang server.'} O ilagay ang Personal Cartesia Key sa Settings > Keys & Gabay para gumana nang walang server.`
      );
    }
    console.info('[Marvy TTS] server unavailable, using the Cartesia key from Settings', serverErr?.message);
    return await requestCartesiaTtsDirect(clean, voiceId, key);
  }
}

/**
 * Reads /api/status from the first server that answers with the Marvy status JSON.
 * Returns null if no candidate does. Every attempt is logged to the console.
 */
export async function fetchServerStatus(): Promise<{
  buildVersion?: string;
  geminiConfigured?: boolean;
  cartesiaConfigured?: boolean;
  cartesiaModel?: string;
  defaultVoiceId?: string;
} | null> {
  for (const base of getApiCandidates()) {
    const endpoint = `${base}/api/status`.replace(/([^:]\/)\/+/g, '$1');
    try {
      const res = await fetch(endpoint);
      console.info(`[Marvy Status] ${endpoint || '(same origin)'} -> HTTP ${res.status}`);
      if (!res.ok) continue;
      const data = await res.json();
      // Only accept JSON that really comes from the Marvy server (has the "models" list).
      if (data && typeof data === 'object' && Array.isArray((data as any).models)) return data;
      console.warn(`[Marvy Status] ${endpoint} answered, but not with Marvy status JSON`);
    } catch (err: any) {
      console.warn(`[Marvy Status] ${endpoint || '(same origin)'} failed: ${err?.message}`);
    }
  }
  return null;
}

/**
 * Downloads the complete, full source code of Marvy AI as a ZIP archive.
 */
export function downloadSourceCodeArchive(): void {
  if (typeof window === 'undefined') return;

  // Create an anchor pointing to the pre-bundled source zip in public/ or /api/download/source
  const link = document.createElement('a');
  link.href = '/marvy-ai-source-latest.zip';
  link.download = 'marvy-ai-source-latest.zip';
  link.target = '_blank';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export interface VisionResponsePayload {
  reply: string;
  cleanSpeechText: string;
  opticalBreakdown: string;
  sentiment?: SentimentAnalysis;
  robotEmotion?: RobotEmotion;
  isQuotaLimit?: boolean;
}

/**
 * Sends image snapshot or uploaded photo to /api/vision/analyze for multimodal perception.
 */
export async function sendVisionAnalysis(params: {
  imageBase64: string;
  mimeType?: string;
  prompt?: string;
  voiceGender?: 'female' | 'male';
  userCallsign?: string;
  customGeminiKey?: string;
}): Promise<VisionResponsePayload> {
  const candidates = getApiCandidates();
  let lastError: any = null;

  for (const base of candidates) {
    const endpoint = `${base}/api/vision/analyze`.replace(/([^:]\/)\/+/g, '$1');

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(params.customGeminiKey ? { 'x-gemini-api-key': params.customGeminiKey } : {}),
        },
        body: JSON.stringify({
          imageBase64: params.imageBase64,
          mimeType: params.mimeType || 'image/jpeg',
          prompt: params.prompt || 'Ano ang nakikita mo, Boss?',
          voiceGender: params.voiceGender || 'male',
          userCallsign: params.userCallsign || 'Boss',
          customApiKey: params.customGeminiKey,
        }),
      });

      if (res.status === 404) {
        lastError = new Error(`HTTP 404 on ${endpoint}`);
        continue;
      }

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        const errMsg = errJson.error || `Server error (HTTP ${res.status})`;

        if (res.status === 429 || errMsg.includes('429') || errMsg.includes('quota') || errMsg.includes('RESOURCE_EXHAUSTED')) {
          const quotaMsg = 'Boss, saglit lang ha! Naabot na ang Free Tier quota limit ng Gemini para sa Vision scan. Maaari kang maglagay ng sariling libreng Gemini API Key sa Settings (⚙️) para tuloy-tuloy ang pag-scan natin!';
          return {
            reply: quotaMsg,
            cleanSpeechText: sanitizeTextForSpeech(quotaMsg),
            opticalBreakdown: '⚠️ Quota limit reached sa Free Tier. Maglagay ng sariling Gemini API Key sa Settings (⚙️).',
            sentiment: {
              primaryMood: 'chill',
              moodLabel: 'Quota Notice',
              valence: 0,
              arousal: 'low',
              empathyTone: 'Friendly Guidance',
              confidence: 100,
              summary: 'Free tier quota exhausted',
            },
            robotEmotion: 'thinking',
            isQuotaLimit: true,
          };
        }

        throw new Error(errMsg);
      }

      const data = await res.json();
      return data;
    } catch (err: any) {
      console.warn(`[Marvy Vision API] Failed on candidate ${endpoint}:`, err.message);
      lastError = err;
    }
  }

  // Graceful fallback response instead of unhandled promise rejection
  const friendlyFallback = 'Pasensya na Boss, medyo nagkaroon ng koneksyon aberya ang camera sensor. Pakisubukan muli o maglagay ng sariling Gemini API key sa Settings.';
  return {
    reply: friendlyFallback,
    cleanSpeechText: sanitizeTextForSpeech(friendlyFallback),
    opticalBreakdown: `Notice: ${lastError?.message || 'Nagkaroon ng koneksyon aberya.'}`,
    sentiment: {
      primaryMood: 'chill',
      moodLabel: 'Connection Notice',
      valence: -0.2,
      arousal: 'low',
      empathyTone: 'Apologetic',
      confidence: 70,
      summary: 'Connection error during scan',
    },
    robotEmotion: 'thinking',
    isQuotaLimit: false,
  };
}

