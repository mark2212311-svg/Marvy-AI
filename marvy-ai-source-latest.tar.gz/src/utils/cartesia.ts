/**
 * Cartesia Sonic TTS configuration for Marvy AI.
 * Cartesia is the ONLY voice engine in this app. The API key lives on the server
 * (CARTESIA_API_KEY env var) and is never sent to the browser.
 */

/** Default Marvy voice (Cartesia voice ID). Used everywhere unless the user picks another one. */
export const DEFAULT_CARTESIA_VOICE_ID = '2e488ee5-a721-4466-b0b7-7e586e943ed3';

/** Cartesia TTS model used by the server. */
export const CARTESIA_MODEL_ID = 'sonic-3.6';

/** Cartesia REST API version header. */
export const CARTESIA_API_VERSION = '2025-04-16';

/** localStorage key for the selected voice. New key so old ElevenLabs / browser voice settings are ignored. */
export const CARTESIA_VOICE_STORAGE_KEY = 'marvy_cartesia_voice_id_v2';

/** Max characters sent to Cartesia in one request (longer text is trimmed server-side). */
export const CARTESIA_MAX_TEXT_CHARS = 2000;

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Cartesia voice IDs are UUIDs. */
export function isValidCartesiaVoiceId(id: string | null | undefined): boolean {
  return typeof id === 'string' && UUID_PATTERN.test(id.trim());
}

/** Reads the saved voice ID, falling back to the default when nothing valid is stored. */
export function loadSavedCartesiaVoiceId(): string {
  try {
    const saved = localStorage.getItem(CARTESIA_VOICE_STORAGE_KEY);
    if (isValidCartesiaVoiceId(saved)) return saved!.trim();
  } catch {
    // localStorage unavailable (private mode / webview) — use default
  }
  return DEFAULT_CARTESIA_VOICE_ID;
}

export function saveCartesiaVoiceId(id: string): void {
  try {
    localStorage.setItem(CARTESIA_VOICE_STORAGE_KEY, id.trim());
  } catch {
    // ignore storage errors
  }
}
