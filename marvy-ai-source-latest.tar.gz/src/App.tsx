// src/App.tsx
import { useState } from 'react';
import { useVoiceConversation } from './hooks/useVoiceConversation';
import { VoiceVisualizer } from './components/VoiceVisualizer';
import { FeaturesHubView } from './components/FeaturesHubView';
import { TranscriptView } from './components/TranscriptView';
import { NavigationDrawer } from './components/NavigationDrawer';
import { VoiceSettingsModal } from './components/VoiceSettingsModal';
import { MemoryModal } from './components/MemoryModal';
import { EvolutionMatrixModal } from './components/EvolutionMatrixModal';
import { NeuralVisionModal } from './components/NeuralVisionModal';
import { NeuralMindstreamModal } from './components/NeuralMindstreamModal';
import { ArrowLeft, Menu } from 'lucide-react';
import { sfx } from './utils/soundEffects';
import { DEFAULT_CARTESIA_VOICE_ID } from './utils/cartesia';

type TabView = 'robot' | 'features' | 'transcript';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabView>('robot');
  const [showDrawer, setShowDrawer] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showMemories, setShowMemories] = useState(false);
  const [showEvolution, setShowEvolution] = useState(false);
  const [showVision, setShowVision] = useState(false);
  const [showMindstream, setShowMindstream] = useState(false);

  const {
    state,
    messages,
    lastAssistantMessage,
    errorMessage,
    userSpeechInterim,
    isHandsFree,
    isMuted,
    isCallActive,
    callDuration,
    selectedGender,
    voiceId,
    avatarForm,
    aiModel,
    lastSentiment,
    customGeminiKey,
    cartesiaClientKey,
    updateCartesiaClientKey,
    callsign,
    memories,
    emotion,
    backendUrl,
    isApk,
    setEmotion,
    setIsCallActive,
    setIsHandsFree,
    setAvatarForm,
    setAiModel,
    switchGender,
    setVoiceId,
    resetVoiceId,
    startListening,
    stopListening,
    stopAll,
    handleSendMessage,
    repeatLastAnswer,
    speakMessage,
    toggleMute,
    handleVisionResponse,
    clearError,
    updateCallsign,
    addMemory,
    removeMemory,
    clearAllMemories,
    updateBackendUrl,
    updateGeminiKey,
  } = useVoiceConversation();

  const voiceName = voiceId === DEFAULT_CARTESIA_VOICE_ID ? 'Marvy Voice' : 'Custom Voice';

  const handleToggleListening = () => {
    if (state === 'listening') {
      stopListening();
    } else {
      if (!isCallActive) setIsCallActive(true);
      startListening();
    }
  };

  const handleToggleCall = () => {
    if (isCallActive) {
      stopAll();
      setIsCallActive(false);
    } else {
      setIsCallActive(true);
      startListening();
    }
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col justify-between overflow-x-hidden selection:bg-cyan-500/30 selection:text-cyan-200 font-sans">
      {/* Non-Robot View Top Navigation Bar */}
      {activeTab !== 'robot' && (
        <header className="sticky top-0 z-30 w-full border-b border-slate-800/80 bg-[#07090e]/95 backdrop-blur-md px-4 py-3 flex items-center justify-between">
          <button
            type="button"
            onClick={() => {
              sfx.playClick();
              setActiveTab('robot');
            }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-xs font-bold text-cyan-300 hover:text-white transition active:scale-95"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Bumalik sa 3D Robot</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-300">
              {activeTab === 'features' ? '⚡ Mga Feature & AI' : '💬 Usapan'}
            </span>
            <button
              type="button"
              onClick={() => setShowDrawer(true)}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 transition active:scale-95"
              title="Menu"
              aria-label="Buksan ang Menu"
            >
              <Menu className="w-4 h-4" />
            </button>
          </div>
        </header>
      )}

      {/* Main Experience Surface */}
      <main className="flex-1 w-full flex flex-col items-stretch justify-center relative overflow-hidden">
        {/* VIEW 1: 3D ROBOT VIEW */}
        {activeTab === 'robot' && (
          <VoiceVisualizer
            state={state}
            emotion={emotion}
            selectedGender={selectedGender}
            voiceName={voiceName}
            activeAvatarForm={avatarForm}
            lastReplyText={lastAssistantMessage?.text}
            userSpeechInterim={userSpeechInterim}
            lastSentiment={lastSentiment}
            errorMessage={errorMessage}
            onClearError={clearError}
            onStartListening={handleToggleListening}
            onSelectEmotion={setEmotion}
            onQuickMoodTest={(text) => handleSendMessage(text)}
            onOpenMenu={() => setShowDrawer(true)}
          />
        )}

        {/* VIEW 2: MGA FEATURE TAB */}
        {activeTab === 'features' && (
          <section aria-label="Marvy Features and Sensory Modules Hub" className="flex-1 w-full overflow-y-auto">
            <FeaturesHubView
              emotion={emotion}
              lastSentiment={lastSentiment}
              activeAvatarForm={avatarForm}
              memoryCount={memories.length}
              voiceName={voiceName}
              onSelectEmotion={setEmotion}
              onQuickPrompt={(text) => {
                handleSendMessage(text);
                setActiveTab('robot');
              }}
              onOpenEvolution={() => setShowEvolution(true)}
              onOpenVision={() => setShowVision(true)}
              onOpenMindstream={() => setShowMindstream(true)}
              onOpenMemories={() => setShowMemories(true)}
              onOpenSettings={() => setShowSettings(true)}
            />
          </section>
        )}

        {/* VIEW 3: USAPAN / TRANSCRIPT VIEW */}
        {activeTab === 'transcript' && (
          <section
            aria-label="Conversation Transcript and Chat"
            className="flex-1 w-full max-w-3xl mx-auto h-full min-h-[calc(100vh-70px)] flex flex-col"
          >
            <TranscriptView
              messages={messages}
              onSendMessage={handleSendMessage}
              onPlayMessageAudio={(msg) => speakMessage(msg)}
              onClose={() => setActiveTab('robot')}
              isThinking={state === 'thinking'}
            />
          </section>
        )}
      </main>

      {/* Slide-out Navigation Drawer */}
      <NavigationDrawer
        isOpen={showDrawer}
        onClose={() => setShowDrawer(false)}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        isCallActive={isCallActive}
        callDuration={callDuration}
        onToggleCall={handleToggleCall}
        isHandsFree={isHandsFree}
        onToggleHandsFree={() => setIsHandsFree(!isHandsFree)}
        hasLastAnswer={Boolean(lastAssistantMessage)}
        onRepeatLastAnswer={repeatLastAnswer}
        isMuted={isMuted}
        onToggleMute={toggleMute}
        memoryCount={memories.length}
        activeAvatarForm={avatarForm}
        lastSentiment={lastSentiment}
        onOpenMemories={() => setShowMemories(true)}
        onOpenSettings={() => setShowSettings(true)}
        onOpenVision={() => setShowVision(true)}
        onOpenMindstream={() => setShowMindstream(true)}
        onOpenEvolution={() => setShowEvolution(true)}
        voiceName={voiceName}
      />

      {/* Modals */}
      <EvolutionMatrixModal
        isOpen={showEvolution}
        activeForm={avatarForm}
        onSelectForm={(f) => setAvatarForm(f)}
        onClose={() => setShowEvolution(false)}
      />

      <NeuralVisionModal
        isOpen={showVision}
        userCallsign={callsign}
        selectedGender={selectedGender}
        customGeminiKey={customGeminiKey}
        onClose={() => setShowVision(false)}
        onVisionResponse={(res) => {
          handleVisionResponse(res);
          setShowVision(false);
          setActiveTab('robot');
        }}
        onOpenSettings={() => setShowSettings(true)}
      />

      <NeuralMindstreamModal
        isOpen={showMindstream}
        activeForm={avatarForm}
        lastSentiment={lastSentiment}
        emotion={emotion}
        memoryCount={memories.length}
        onClose={() => setShowMindstream(false)}
      />

      <VoiceSettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        selectedGender={selectedGender}
        onSelectGender={switchGender}
        voiceId={voiceId}
        onSaveVoiceId={setVoiceId}
        onResetVoiceId={resetVoiceId}
        aiModel={aiModel}
        onSelectAiModel={setAiModel}
        customGeminiKey={customGeminiKey}
        onUpdateGeminiKey={updateGeminiKey}
        cartesiaClientKey={cartesiaClientKey}
        onUpdateCartesiaClientKey={updateCartesiaClientKey}
        backendUrl={backendUrl}
        onUpdateBackendUrl={updateBackendUrl}
        isApk={isApk}
      />

      <MemoryModal
        isOpen={showMemories}
        onClose={() => setShowMemories(false)}
        memories={memories}
        callsign={callsign}
        onUpdateCallsign={updateCallsign}
        onAddMemory={addMemory}
        onRemoveMemory={removeMemory}
        onClearAllMemories={clearAllMemories}
      />
    </div>
  );
}
