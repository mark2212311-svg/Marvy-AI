import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { ConversationState, RobotEmotion, AvatarFormId } from '../utils/conversation';
import { sfx } from '../utils/soundEffects';

interface EvolutionAvatar3DProps {
  form?: AvatarFormId;
  state: ConversationState;
  emotion: RobotEmotion;
  onTapSphere?: () => void;
}

export const EvolutionAvatar3D: React.FC<EvolutionAvatar3DProps> = ({
  form = 'quantum_core',
  state,
  emotion,
  onTapSphere,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // Mutable refs for render loop
  const formRef = useRef<AvatarFormId>(form);
  const stateRef = useRef<ConversationState>(state);
  const emotionRef = useRef<RobotEmotion>(emotion);
  const targetRotationRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const isPointerDownRef = useRef<boolean>(false);
  const bounceYRef = useRef<number>(0);
  const bounceVelocityRef = useRef<number>(0);

  useEffect(() => {
    formRef.current = form;
  }, [form]);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    emotionRef.current = emotion;
  }, [emotion]);

  useEffect(() => {
    if (!mountRef.current) return;

    const container = mountRef.current;
    const width = container.clientWidth || 340;
    const height = container.clientHeight || 340;

    // Detect software WebGL for performance optimization
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    // 1. Initialize Three.js Scene, Camera & Renderer
    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0.05, 4.4);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      alpha: true,
      powerPreference: 'high-performance',
      precision: 'mediump',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.35));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;

    container.appendChild(renderer.domElement);

    // 2. Studio Environment Reflection
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 3. Cybernetic Lighting Rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0x06b6d4, 2.8);
    keyLight.position.set(3, 4, 3);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xa855f7, 2.0);
    fillLight.position.set(-3, -1, 2);
    scene.add(fillLight);

    const pointLight = new THREE.PointLight(0x38bdf8, 3.0, 10);
    pointLight.position.set(0, 0, 1.5);
    scene.add(pointLight);

    // Root avatar group (handles overall tilt & bounce)
    const avatarRoot = new THREE.Group();
    scene.add(avatarRoot);

    // ----------------------------------------------------
    // FORM 1: QUANTUM NEURAL SINGULARITY (J.A.R.V.I.S. Core)
    // ----------------------------------------------------
    const quantumGroup = new THREE.Group();
    avatarRoot.add(quantumGroup);

    // Inner pulsating core
    const coreGeo = new THREE.IcosahedronGeometry(0.72, 2);
    const coreMat = new THREE.MeshPhysicalMaterial({
      color: 0x06b6d4,
      emissive: 0x0891b2,
      emissiveIntensity: 0.8,
      roughness: 0.1,
      metalness: 0.9,
      transmission: 0.4,
      transparent: true,
      opacity: 0.95,
      wireframe: false,
    });
    const quantumCore = new THREE.Mesh(coreGeo, coreMat);
    quantumGroup.add(quantumCore);

    // Outer crystalline wireframe lattice
    const cageGeo = new THREE.IcosahedronGeometry(0.92, 1);
    const cageMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: true,
      transparent: true,
      opacity: 0.75,
    });
    const quantumCage = new THREE.Mesh(cageGeo, cageMat);
    quantumGroup.add(quantumCage);

    // 3 Gyroscopic Tachyon Rings (X, Y, Z orientations)
    const createTachyonRing = (radius: number, tube: number, colorHex: number) => {
      const ringGeo = new THREE.TorusGeometry(radius, tube, 16, 64);
      const ringMat = new THREE.MeshStandardMaterial({
        color: colorHex,
        emissive: colorHex,
        emissiveIntensity: 0.9,
        roughness: 0.2,
        metalness: 0.8,
      });
      return new THREE.Mesh(ringGeo, ringMat);
    };

    const ringX = createTachyonRing(1.3, 0.022, 0x06b6d4);
    const ringY = createTachyonRing(1.48, 0.02, 0xa855f7);
    const ringZ = createTachyonRing(1.65, 0.018, 0x38bdf8);
    quantumGroup.add(ringX);
    quantumGroup.add(ringY);
    quantumGroup.add(ringZ);

    // Quantum Vortex Particles (350 floating stars)
    const particleCount = 350;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleSpeeds = new Float32Array(particleCount);
    for (let i = 0; i < particleCount; i++) {
      const radius = 0.9 + Math.random() * 1.4;
      const theta = Math.random() * Math.PI * 2;
      const phi = (Math.random() - 0.5) * Math.PI;
      particlePositions[i * 3] = radius * Math.cos(phi) * Math.cos(theta);
      particlePositions[i * 3 + 1] = radius * Math.sin(phi);
      particlePositions[i * 3 + 2] = radius * Math.cos(phi) * Math.sin(theta);
      particleSpeeds[i] = 0.005 + Math.random() * 0.015;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x67e8f9,
      size: 0.045,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
    });
    const quantumParticles = new THREE.Points(particleGeo, particleMat);
    quantumGroup.add(quantumParticles);

    // ----------------------------------------------------
    // FORM 2: SYNTHETIC BIONIC ANDROID (Cyberpunk Humanoid Face)
    // ----------------------------------------------------
    const synthGroup = new THREE.Group();
    avatarRoot.add(synthGroup);

    // Head Base (Sculpted Stylized Cyber Humanoid)
    const headGeo = new THREE.SphereGeometry(0.85, 32, 32);
    headGeo.scale(0.88, 1.15, 0.95);
    const headMat = new THREE.MeshStandardMaterial({
      color: 0x111827,
      roughness: 0.25,
      metalness: 0.85,
    });
    const synthHead = new THREE.Mesh(headGeo, headMat);
    synthGroup.add(synthHead);

    // Cyber Forehead Visor (HUD Bar)
    const visorGeo = new THREE.CylinderGeometry(0.72, 0.72, 0.16, 32, 1, false, -1.2, 2.4);
    visorGeo.rotateZ(Math.PI / 2);
    const visorMat = new THREE.MeshBasicMaterial({
      color: 0x06b6d4,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
    });
    const synthVisor = new THREE.Mesh(visorGeo, visorMat);
    synthVisor.position.set(0, 0.18, 0.42);
    synthGroup.add(synthVisor);

    // Bionic Eyes (Glowing Ocular Lenses that blink and look around)
    const eyeGeo = new THREE.SphereGeometry(0.12, 16, 16);
    const eyeMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      emissive: 0x0891b2,
      emissiveIntensity: 1.5,
      roughness: 0.1,
    });
    const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
    leftEye.position.set(-0.25, 0.08, 0.72);
    const rightEye = new THREE.Mesh(eyeGeo, eyeMat.clone());
    rightEye.position.set(0.25, 0.08, 0.72);
    synthGroup.add(leftEye);
    synthGroup.add(rightEye);

    // Subcutaneous Neon Jaw & Temple Circuit Accents
    const jawRingGeo = new THREE.TorusGeometry(0.68, 0.018, 16, 48, Math.PI * 0.9);
    jawRingGeo.rotateX(Math.PI / 2);
    const jawRingMat = new THREE.MeshBasicMaterial({
      color: 0xd946ef,
      transparent: true,
      opacity: 0.8,
    });
    const jawRing = new THREE.Mesh(jawRingGeo, jawRingMat);
    jawRing.position.set(0, -0.4, 0.1);
    synthGroup.add(jawRing);

    // Mouth Aperture Glow Bar (Reacts to speech)
    const mouthGeo = new THREE.BoxGeometry(0.22, 0.03, 0.05);
    const mouthMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.85,
    });
    const synthMouth = new THREE.Mesh(mouthGeo, mouthMat);
    synthMouth.position.set(0, -0.42, 0.75);
    synthGroup.add(synthMouth);

    // Floating Halo Ring
    const synthHaloGeo = new THREE.TorusGeometry(0.9, 0.015, 16, 48);
    synthHaloGeo.rotateX(Math.PI / 2.2);
    const synthHaloMat = new THREE.MeshBasicMaterial({
      color: 0xa855f7,
      transparent: true,
      opacity: 0.7,
    });
    const synthHalo = new THREE.Mesh(synthHaloGeo, synthHaloMat);
    synthHalo.position.set(0, 0.9, -0.05);
    synthGroup.add(synthHalo);

    // ----------------------------------------------------
    // FORM 3: CELESTIAL COSMIC AETHER (Cosmic Sentience)
    // ----------------------------------------------------
    const celestialGroup = new THREE.Group();
    avatarRoot.add(celestialGroup);

    // Central Cosmic Pulsar Star
    const pulsarGeo = new THREE.SphereGeometry(0.65, 32, 32);
    const pulsarMat = new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      transparent: true,
      opacity: 0.9,
    });
    const pulsar = new THREE.Mesh(pulsarGeo, pulsarMat);
    celestialGroup.add(pulsar);

    // Corona Spike Envelope
    const coronaGeo = new THREE.IcosahedronGeometry(0.85, 2);
    const coronaMat = new THREE.MeshBasicMaterial({
      color: 0xfbbf24,
      wireframe: true,
      transparent: true,
      opacity: 0.5,
    });
    const corona = new THREE.Mesh(coronaGeo, coronaMat);
    celestialGroup.add(corona);

    // Celestial Nebula Star Discs
    const galaxyStarsCount = 450;
    const galaxyGeo = new THREE.BufferGeometry();
    const galaxyPositions = new Float32Array(galaxyStarsCount * 3);
    for (let i = 0; i < galaxyStarsCount; i++) {
      const radius = 0.8 + Math.pow(Math.random(), 0.7) * 1.5;
      const angle = Math.random() * Math.PI * 4;
      const spiralDist = angle * 0.15;
      const yOffset = (Math.random() - 0.5) * 0.45;
      galaxyPositions[i * 3] = (radius + spiralDist * 0.1) * Math.cos(angle);
      galaxyPositions[i * 3 + 1] = yOffset;
      galaxyPositions[i * 3 + 2] = (radius + spiralDist * 0.1) * Math.sin(angle);
    }
    galaxyGeo.setAttribute('position', new THREE.BufferAttribute(galaxyPositions, 3));
    const galaxyMat = new THREE.PointsMaterial({
      color: 0xfcd34d,
      size: 0.05,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });
    const galaxyPoints = new THREE.Points(galaxyGeo, galaxyMat);
    galaxyPoints.rotation.x = Math.PI / 5;
    celestialGroup.add(galaxyPoints);

    // Orbiting Starlight Halo
    const celestialRingGeo = new THREE.TorusGeometry(1.5, 0.02, 16, 64);
    celestialRingGeo.rotateX(Math.PI / 3);
    const celestialRingMat = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      emissive: 0x9333ea,
      emissiveIntensity: 0.9,
    });
    const celestialRing = new THREE.Mesh(celestialRingGeo, celestialRingMat);
    celestialGroup.add(celestialRing);

    // ----------------------------------------------------
    // FORM 4: NANOTECH TESSERACT (4D Hypercube Geometric Hivemind)
    // ----------------------------------------------------
    const tesseractGroup = new THREE.Group();
    avatarRoot.add(tesseractGroup);

    // Outer Cube Wireframe
    const outerCubeGeo = new THREE.BoxGeometry(1.4, 1.4, 1.4);
    const outerCubeMat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      wireframe: true,
      transparent: true,
      opacity: 0.85,
    });
    const outerCube = new THREE.Mesh(outerCubeGeo, outerCubeMat);
    tesseractGroup.add(outerCube);

    // Inner Inverted Cube
    const innerCubeGeo = new THREE.BoxGeometry(0.75, 0.75, 0.75);
    const innerCubeMat = new THREE.MeshPhysicalMaterial({
      color: 0x34d399,
      emissive: 0x059669,
      emissiveIntensity: 0.8,
      roughness: 0.1,
      metalness: 0.9,
      transmission: 0.5,
      transparent: true,
      opacity: 0.9,
    });
    const innerCube = new THREE.Mesh(innerCubeGeo, innerCubeMat);
    tesseractGroup.add(innerCube);

    // 24 Floating Nanite Octahedra Swarm
    const naniteGroup = new THREE.Group();
    tesseractGroup.add(naniteGroup);
    const nanites: THREE.Mesh[] = [];
    const naniteGeo = new THREE.OctahedronGeometry(0.12);
    const naniteMat = new THREE.MeshStandardMaterial({
      color: 0x6ee7b7,
      emissive: 0x10b981,
      emissiveIntensity: 0.8,
      metalness: 0.9,
      roughness: 0.2,
    });

    for (let i = 0; i < 20; i++) {
      const nMesh = new THREE.Mesh(naniteGeo, naniteMat);
      const angle = (i / 20) * Math.PI * 2;
      const rad = 1.35;
      nMesh.position.set(rad * Math.cos(angle), (Math.sin(angle * 3) * 0.4), rad * Math.sin(angle));
      naniteGroup.add(nMesh);
      nanites.push(nMesh);
    }

    // ----------------------------------------------------
    // FORM 5: MK-IV MECHA TITAN (Vanguard Cyber Droid)
    // ----------------------------------------------------
    const mechaGroup = new THREE.Group();
    avatarRoot.add(mechaGroup);

    // Armored Head Chassis
    const mechaHeadGeo = new THREE.DodecahedronGeometry(0.85, 1);
    const mechaHeadMat = new THREE.MeshStandardMaterial({
      color: 0x1f2937,
      roughness: 0.3,
      metalness: 0.85,
    });
    const mechaHead = new THREE.Mesh(mechaHeadGeo, mechaHeadMat);
    mechaGroup.add(mechaHead);

    // Angular Cyber Visor
    const mechaVisorGeo = new THREE.BoxGeometry(0.85, 0.26, 0.4);
    const mechaVisorMat = new THREE.MeshBasicMaterial({
      color: 0xf43f5e,
      transparent: true,
      opacity: 0.9,
    });
    const mechaVisor = new THREE.Mesh(mechaVisorGeo, mechaVisorMat);
    mechaVisor.position.set(0, 0.1, 0.72);
    mechaGroup.add(mechaVisor);

    // Plasma Energy Wings (Left & Right)
    const wingGeo = new THREE.ConeGeometry(0.35, 1.2, 4);
    wingGeo.rotateZ(Math.PI / 2);
    const wingMat = new THREE.MeshBasicMaterial({
      color: 0xf43f5e,
      wireframe: true,
      transparent: true,
      opacity: 0.8,
    });
    const leftWing = new THREE.Mesh(wingGeo, wingMat);
    leftWing.position.set(-1.15, 0.4, -0.2);
    leftWing.rotation.z = -0.5;
    const rightWing = new THREE.Mesh(wingGeo, wingMat);
    rightWing.position.set(1.15, 0.4, -0.2);
    rightWing.rotation.z = 0.5;
    mechaGroup.add(leftWing);
    mechaGroup.add(rightWing);

    // Tactical Target Reticle Halo
    const mechaHaloGeo = new THREE.TorusGeometry(1.2, 0.02, 8, 32);
    mechaHaloGeo.rotateX(Math.PI / 2.5);
    const mechaHaloMat = new THREE.MeshBasicMaterial({
      color: 0xfb7185,
      transparent: true,
      opacity: 0.7,
    });
    const mechaHalo = new THREE.Mesh(mechaHaloGeo, mechaHaloMat);
    mechaHalo.position.set(0, 0.6, -0.1);
    mechaGroup.add(mechaHalo);

    // ----------------------------------------------------
    // Pointer & Spring Interaction
    // ----------------------------------------------------
    const handlePointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;
      const normX = (clientX / rect.width) * 2 - 1;
      const normY = -(clientY / rect.height) * 2 + 1;

      targetRotationRef.current = {
        x: normY * 0.45,
        y: normX * 0.65,
      };
    };

    const handlePointerDown = () => {
      isPointerDownRef.current = true;
      bounceVelocityRef.current = 0.16;
      sfx.playQuantumPulse();
      if (onTapSphere) onTapSphere();
    };

    const handlePointerUp = () => {
      isPointerDownRef.current = false;
    };

    container.addEventListener('pointermove', handlePointerMove);
    container.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointerup', handlePointerUp);

    // ----------------------------------------------------
    // Animation Render Loop
    // ----------------------------------------------------
    let animationFrameId: number;
    let clock = new THREE.Clock();
    let blinkTimer = 0;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const delta = clock.getDelta();
      const elapsed = clock.getElapsedTime();
      const currentForm = formRef.current;
      const currentState = stateRef.current;
      const currentEmotion = emotionRef.current;

      // 1. Manage Form Visibility with Smooth Fade
      quantumGroup.visible = currentForm === 'quantum_core';
      synthGroup.visible = currentForm === 'synth_human';
      celestialGroup.visible = currentForm === 'celestial_aether';
      tesseractGroup.visible = currentForm === 'nanotech_hivemind';
      mechaGroup.visible = currentForm === 'cyber_mech';

      // 2. Physics Spring Bounce on Tap
      bounceVelocityRef.current -= bounceYRef.current * 28 * delta;
      bounceVelocityRef.current *= 0.88;
      bounceYRef.current += bounceVelocityRef.current;

      // Idle levitation sine wave
      const floatY = Math.sin(elapsed * 2.2) * 0.06;
      avatarRoot.position.y = floatY + bounceYRef.current;

      // Smooth pointer rotation interpolation
      avatarRoot.rotation.x += (targetRotationRef.current.x - avatarRoot.rotation.x) * 0.08;
      avatarRoot.rotation.y += (targetRotationRef.current.y - avatarRoot.rotation.y) * 0.08;

      // 3. Audio / State reactivity speed multiplier
      let speedMult = 1.0;
      if (currentState === 'speaking') speedMult = 2.4;
      else if (currentState === 'listening') speedMult = 1.6;
      else if (currentState === 'thinking') speedMult = 2.0;

      // Form 1 Animation: Quantum Core
      if (quantumGroup.visible) {
        ringX.rotation.x = elapsed * 0.8 * speedMult;
        ringX.rotation.y = elapsed * 0.4 * speedMult;

        ringY.rotation.y = -elapsed * 0.9 * speedMult;
        ringY.rotation.z = elapsed * 0.5 * speedMult;

        ringZ.rotation.z = elapsed * 1.1 * speedMult;
        ringZ.rotation.x = -elapsed * 0.6 * speedMult;

        quantumCore.rotation.y = elapsed * 0.5;
        quantumCage.rotation.y = -elapsed * 0.7;

        // Core scale breathing
        const coreScale = 1.0 + Math.sin(elapsed * 4 * speedMult) * 0.08;
        quantumCore.scale.set(coreScale, coreScale, coreScale);

        // Swirl particles
        quantumParticles.rotation.y = elapsed * 0.35 * speedMult;
        quantumParticles.rotation.x = Math.sin(elapsed * 0.2) * 0.2;
      }

      // Form 2 Animation: Synth-Human
      if (synthGroup.visible) {
        synthHalo.rotation.z = elapsed * 0.6;
        synthHalo.position.y = 0.9 + Math.sin(elapsed * 3) * 0.04;

        // Eye Blinking simulation
        blinkTimer += delta;
        if (blinkTimer > 3.8) {
          leftEye.scale.y = 0.1;
          rightEye.scale.y = 0.1;
          if (blinkTimer > 3.98) {
            leftEye.scale.y = 1.0;
            rightEye.scale.y = 1.0;
            blinkTimer = 0;
          }
        }

        // Mouth glow breathing when speaking
        if (currentState === 'speaking') {
          synthMouth.scale.x = 1.0 + Math.sin(elapsed * 16) * 0.4;
          synthMouth.scale.y = 1.0 + Math.sin(elapsed * 20) * 0.5;
        } else {
          synthMouth.scale.set(1, 1, 1);
        }
      }

      // Form 3 Animation: Celestial Aether
      if (celestialGroup.visible) {
        pulsar.rotation.y = elapsed * 0.8;
        corona.rotation.y = -elapsed * 1.2;
        corona.rotation.x = elapsed * 0.6;

        galaxyPoints.rotation.z = elapsed * 0.45 * speedMult;
        celestialRing.rotation.z = -elapsed * 0.7 * speedMult;

        const starPulse = 1.0 + (currentState === 'speaking' ? Math.sin(elapsed * 12) * 0.15 : Math.sin(elapsed * 2) * 0.05);
        pulsar.scale.set(starPulse, starPulse, starPulse);
      }

      // Form 4 Animation: Nanotech Tesseract
      if (tesseractGroup.visible) {
        outerCube.rotation.x = elapsed * 0.5 * speedMult;
        outerCube.rotation.y = elapsed * 0.7 * speedMult;

        innerCube.rotation.x = -elapsed * 0.9 * speedMult;
        innerCube.rotation.y = -elapsed * 0.6 * speedMult;

        naniteGroup.rotation.y = elapsed * 0.8 * speedMult;
        nanites.forEach((n, idx) => {
          n.rotation.x = elapsed * 2 + idx;
          n.rotation.y = elapsed * 3 + idx;
        });
      }

      // Form 5 Animation: Mecha Titan
      if (mechaGroup.visible) {
        mechaHalo.rotation.z = elapsed * 0.9 * speedMult;
        const wingFlap = Math.sin(elapsed * 6 * speedMult) * 0.12;
        leftWing.rotation.z = -0.5 + wingFlap;
        rightWing.rotation.z = 0.5 - wingFlap;
      }

      // Emotion Color Shifting
      let emotionHex = 0x06b6d4; // Default cyan
      if (currentEmotion === 'soothing') emotionHex = 0x10b981;
      else if (currentEmotion === 'happy') emotionHex = 0x06b6d4;
      else if (currentEmotion === 'playful') emotionHex = 0xec4899;
      else if (currentEmotion === 'empathic') emotionHex = 0xf59e0b;
      else if (currentEmotion === 'thinking') emotionHex = 0xa855f7;
      else if (currentEmotion === 'confused') emotionHex = 0xf43f5e;

      pointLight.color.setHex(emotionHex);

      renderer.render(scene, camera);
    };

    animate();

    // ----------------------------------------------------
    // Resize Observer
    // ----------------------------------------------------
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const newWidth = entry.contentRect.width;
        const newHeight = entry.contentRect.height;
        if (newWidth > 0 && newHeight > 0) {
          camera.aspect = newWidth / newHeight;
          camera.updateProjectionMatrix();
          renderer.setSize(newWidth, newHeight);
        }
      }
    });

    resizeObserver.observe(container);

    // ----------------------------------------------------
    // Cleanup
    // ----------------------------------------------------
    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      container.removeEventListener('pointermove', handlePointerMove);
      container.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointerup', handlePointerUp);

      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="w-full h-full relative cursor-pointer touch-none select-none flex items-center justify-center overflow-hidden"
      title="Tap to interact / activate Quantum Pulse"
    />
  );
};
