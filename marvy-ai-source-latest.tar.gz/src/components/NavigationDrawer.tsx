// src/components/NavigationDrawer.tsx
import React from 'react';
import {
  X,
  Bot,
  Zap,
  MessageSquare,
  RotateCcw,
  Radio,
  Volume2,
  VolumeX,
  Settings,
  Brain,
  Eye,
  Sparkles,
  PhoneCall,
  PhoneOff,
  HeartHandshake,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { SentimentAnalysis, AvatarFormId, AVATAR_FORMS } from '../utils/conversation';
import { sfx } from '../utils/soundEffects';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: 'robot' | 'features' | 'transcript';
  onSelectTab: (tab: 'robot' | 'features' | 'transcript') => void;
  isCallActive: boolean;
  callDuration: number;
  onToggleCall: () => void;
  isHandsFree: boolean;
  onToggleHandsFree: () => void;
  hasLastAnswer: boolean;
  onRepeatLastAnswer: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  memoryCount: number;
  activeAvatarForm: AvatarFormId;
  lastSentiment?: SentimentAnalysis;
  onOpenMemories: () => void;
  onOpenSettings: () => void;
  onOpenVision: () => void;
  onOpenMindstream: () => void;
  onOpenEvolution: () => void;
  voiceName: string;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  activeTab,
  onSelectTab,
  isCallActive,
  callDuration,
  onToggleCall,
  isHandsFree,
  onToggleHandsFree,
  hasLastAnswer,
  onRepeatLastAnswer,
  isMuted,
  onToggleMute,
  memoryCount,
  activeAvatarForm,
  lastSentiment,
  onOpenMemories,
  onOpenSettings,
  onOpenVision,
  onOpenMindstream,
  onOpenEvolution,
  voiceName,
}) => {
  if (!isOpen) return null;

  const formMeta = AVATAR_FORMS.find((f) => f.id === activeAvatarForm) || AVATAR_FORMS[0];

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end animate-in fade-in duration-200">
      {/* Backdrop overlay */}
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Slide-out Panel */}
      <div className="relative w-full max-w-sm sm:max-w-md bg-[#0a0e17] border-l border-slate-800/80 shadow-2xl h-full flex flex-col justify-between overflow-y-auto z-10 animate-in slide-in-from-right duration-300">
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 z-10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-500/20 via-slate-900 to-cyan-600/30 border border-cyan-500/40 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-base font-bold text-white tracking-tight">MARVY AI</h3>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  MENU
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                {isCallActive ? `Tawag: ${formatTime(callDuration)}` : 'Nakahandang Makipag-usap'}
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition active:scale-95"
            title="Isara ang Menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content Body */}
        <div className="p-4 sm:p-5 space-y-5 flex-1">
          {/* Main Navigation Views */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block px-1">
              Pangunahing Screen
            </span>

            <div className="grid grid-cols-1 gap-2">
              <button
                onClick={() => {
                  sfx.playClick();
                  onSelectTab('robot');
                  onClose();
                }}
                className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all active:scale-95 ${
                  activeTab === 'robot'
                    ? 'bg-gradient-to-r from-cyan-950/80 to-blue-950/80 border-cyan-500/50 shadow-md shadow-cyan-950/40 text-cyan-200'
                    : 'bg-slate-900/60 hover:bg-slate-850 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">3D Robot (Main View)</div>
                    <div className="text-[10px] text-slate-400">Malinis na full-screen robot companion</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500" />
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  onSelectTab('features');
                  onClose();
                }}
                className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all active:scale-95 ${
                  activeTab === 'features'
                    ? 'bg-gradient-to-r from-purple-950/80 to-pink-950/80 border-purple-500/50 shadow-md shadow-purple-950/40 text-purple-200'
                    : 'bg-slate-900/60 hover:bg-slate-850 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                    <Zap className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>Mga Feature & Emosyon</span>
                      {lastSentiment && (
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400">Empathy radar, vibes, 1-tap prompts</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500" />
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  onSelectTab('transcript');
                  onClose();
                }}
                className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition-all active:scale-95 ${
                  activeTab === 'transcript'
                    ? 'bg-gradient-to-r from-emerald-950/80 to-teal-950/80 border-emerald-500/50 shadow-md shadow-emerald-950/40 text-emerald-200'
                    : 'bg-slate-900/60 hover:bg-slate-850 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">Usapan & Transcript</div>
                    <div className="text-[10px] text-slate-400">Mensahe, chat history, at text input</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500" />
              </button>
            </div>
          </div>

          {/* Quick Call Actions */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block px-1">
              Aksyon sa Boses at Tawag
            </span>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  sfx.playClick();
                  onRepeatLastAnswer();
                }}
                disabled={!hasLastAnswer}
                className={`p-3 rounded-2xl border text-left transition active:scale-95 flex flex-col justify-between gap-2 ${
                  hasLastAnswer
                    ? 'bg-slate-900/80 hover:bg-slate-800 border-slate-700/80 text-slate-200'
                    : 'bg-slate-950/40 border-slate-900 text-slate-600 opacity-50 cursor-not-allowed'
                }`}
              >
                <RotateCcw className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold">Ulitin ang Sagot</span>
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  onToggleHandsFree();
                }}
                className={`p-3 rounded-2xl border text-left transition active:scale-95 flex flex-col justify-between gap-2 ${
                  isHandsFree
                    ? 'bg-cyan-950/80 border-cyan-500/50 text-cyan-200 shadow-sm'
                    : 'bg-slate-900/80 hover:bg-slate-800 border-slate-700/80 text-slate-200'
                }`}
              >
                <Radio className={`w-4 h-4 ${isHandsFree ? 'text-cyan-400 animate-pulse' : 'text-slate-400'}`} />
                <div>
                  <span className="text-xs font-bold block">Hands-Free</span>
                  <span className="text-[10px] text-slate-400 block">{isHandsFree ? 'Bukas' : 'Sarado'}</span>
                </div>
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  onToggleMute();
                }}
                className={`p-3 rounded-2xl border text-left transition active:scale-95 flex flex-col justify-between gap-2 ${
                  isMuted
                    ? 'bg-amber-950/80 border-amber-500/50 text-amber-200'
                    : 'bg-slate-900/80 hover:bg-slate-800 border-slate-700/80 text-slate-200'
                }`}
              >
                {isMuted ? <VolumeX className="w-4 h-4 text-amber-400" /> : <Volume2 className="w-4 h-4 text-slate-400" />}
                <div>
                  <span className="text-xs font-bold block">Audio Speaker</span>
                  <span className="text-[10px] text-slate-400 block">{isMuted ? 'Naka-mute' : 'Aktibo'}</span>
                </div>
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  onOpenVision();
                  onClose();
                }}
                className="p-3 rounded-2xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 text-left transition active:scale-95 flex flex-col justify-between gap-2 text-slate-200"
              >
                <Eye className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold">Neural Camera</span>
              </button>
            </div>
          </div>

          {/* AI Tools & Management */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block px-1">
              Pamamahala at Settings
            </span>

            <div className="space-y-1.5">
              <button
                onClick={() => {
                  sfx.playClick();
                  onOpenMemories();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 text-left flex items-center justify-between text-xs text-slate-200 transition active:scale-95"
              >
                <div className="flex items-center gap-2.5">
                  <Brain className="w-4 h-4 text-purple-400" />
                  <span>Memory Vault ni Marvy</span>
                </div>
                <span className="font-mono text-purple-300 text-xs px-2 py-0.5 rounded-full bg-purple-950 border border-purple-500/30">
                  {memoryCount} Alaala
                </span>
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  onOpenMindstream();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 text-left flex items-center justify-between text-xs text-slate-200 transition active:scale-95"
              >
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-fuchsia-400" />
                  <span>Subconscious Mindstream</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  onOpenEvolution();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 text-left flex items-center justify-between text-xs text-slate-200 transition active:scale-95"
              >
                <div className="flex items-center gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span>Anyo: {formMeta.name}</span>
                </div>
                <span className="text-[10px] text-cyan-300 px-1.5 py-0.5 rounded bg-slate-800">
                  Palitan
                </span>
              </button>

              <button
                onClick={() => {
                  sfx.playClick();
                  onOpenSettings();
                  onClose();
                }}
                className="w-full p-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800/80 text-left flex items-center justify-between text-xs text-slate-200 transition active:scale-95"
              >
                <div className="flex items-center gap-2.5">
                  <Settings className="w-4 h-4 text-slate-400" />
                  <div>
                    <span className="block">Boses & AI Settings</span>
                    <span className="text-[10px] text-slate-400">{voiceName} • Cartesia Sonic 3.6</span>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
              </button>
            </div>
          </div>
        </div>

        {/* Drawer Footer: Call / End Call Action */}
        <div className="p-4 sm:p-5 border-t border-slate-800/80 bg-slate-950/80 backdrop-blur-md">
          <button
            onClick={() => {
              onToggleCall();
              onClose();
            }}
            className={`w-full py-3.5 px-4 rounded-2xl text-sm font-bold flex items-center justify-center gap-2 shadow-2xl transition active:scale-95 ${
              isCallActive
                ? 'bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white shadow-rose-950/80'
                : 'bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-cyan-950/80'
            }`}
          >
            {isCallActive ? (
              <>
                <PhoneOff className="w-4 h-4" />
                <span>Tapusin ang Tawag kay Marvy</span>
              </>
            ) : (
              <>
                <PhoneCall className="w-4 h-4" />
                <span>Tawagan si Marvy</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
