// src/components/VoiceVisualizer.tsx
import React, { useState } from 'react';
import { RobotAvatar3D } from './RobotAvatar3D';
import { EvolutionAvatar3D } from './EvolutionAvatar3D';
import {
  ConversationState,
  RobotEmotion,
  SentimentAnalysis,
  AvatarFormId,
} from '../utils/conversation';
import {
  AlertCircle,
  MessageSquare,
  ChevronDown,
  ChevronUp,
  Menu,
  Mic,
  Sparkles,
} from 'lucide-react';

interface VoiceVisualizerProps {
  state: ConversationState;
  emotion: RobotEmotion;
  selectedGender: 'female' | 'male';
  voiceName: string;
  activeAvatarForm: AvatarFormId;
  lastReplyText?: string;
  userSpeechInterim?: string;
  lastSentiment?: SentimentAnalysis;
  errorMessage: string | null;
  onClearError: () => void;
  onStartListening: () => void;
  onSelectEmotion: (emotion: RobotEmotion) => void;
  onQuickMoodTest: (moodText: string) => void;
  onOpenMenu: () => void;
}

export const VoiceVisualizer: React.FC<VoiceVisualizerProps> = ({
  state,
  emotion,
  selectedGender,
  activeAvatarForm,
  lastReplyText,
  userSpeechInterim,
  errorMessage,
  onClearError,
  onStartListening,
  onOpenMenu,
}) => {
  const [showSubtitle, setShowSubtitle] = useState(true);

  const isListening = state === 'listening';
  const isSpeaking = state === 'speaking';
  const isThinking = state === 'thinking';

  // Ambient cybernetic glow
  const getGlowAnimationClass = () => {
    switch (emotion) {
      case 'soothing':
        return 'anim-emotion-calm-pulse bg-emerald-500/20';
      case 'happy':
        return 'anim-emotion-happy-pulse bg-cyan-400/25';
      case 'playful':
        return 'anim-emotion-playful-shimmer bg-pink-500/20';
      case 'empathic':
        return 'anim-emotion-empathy-heartbeat bg-amber-500/20';
      case 'thinking':
        return 'anim-emotion-thinking-ripple bg-purple-600/20';
      default:
        return 'anim-emotion-calm-pulse bg-cyan-500/15';
    }
  };

  const getMoodBorderColor = () => {
    switch (emotion) {
      case 'soothing':
        return 'border-emerald-500/40 shadow-emerald-950/30';
      case 'happy':
        return 'border-cyan-500/40 shadow-cyan-950/30';
      case 'playful':
        return 'border-pink-500/40 shadow-pink-950/30';
      case 'empathic':
        return 'border-amber-500/40 shadow-amber-950/30';
      case 'thinking':
        return 'border-purple-500/40 shadow-purple-950/30';
      default:
        return 'border-slate-700/80 shadow-slate-950/30';
    }
  };

  return (
    <div className="relative w-full h-full min-h-screen flex flex-col items-center justify-between overflow-hidden select-none bg-[#07090e]">
      {/* 1. Deep Cybernetic Ambient Glow */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
        <div
          className={`w-[450px] sm:w-[700px] h-[450px] sm:h-[700px] rounded-full blur-[130px] sm:blur-[190px] transition-all duration-700 pointer-events-none ${getGlowAnimationClass()}`}
        />
      </div>

      {/* 2. Top Minimalist Floating Action Area: 3-Lines Hamburger Menu Button */}
      <div className="fixed top-4 right-4 z-40">
        <button
          onClick={onOpenMenu}
          aria-label="Buksan ang Menu"
          className="group relative flex items-center justify-center w-12 h-12 rounded-2xl bg-slate-900/85 hover:bg-slate-800 border border-slate-700/70 hover:border-cyan-400 text-cyan-300 shadow-2xl backdrop-blur-md transition-all active:scale-95"
          title="Buksan ang Menu (Features, Usapan, Settings)"
        >
          {/* Subtle glowing ring indicator */}
          <span className="absolute -inset-0.5 rounded-2xl bg-cyan-400/20 opacity-0 group-hover:opacity-100 transition-opacity blur-sm" />
          <Menu className="w-6 h-6 text-cyan-400 group-hover:scale-110 transition-transform" />
        </button>
      </div>

      {/* Floating Dynamic Status Chip (Non-intrusive) */}
      <div className="fixed top-5 left-4 z-30 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 shadow-lg backdrop-blur-md">
          <span
            className={`w-2 h-2 rounded-full ${
              isSpeaking
                ? 'bg-emerald-400 animate-pulse'
                : isListening
                ? 'bg-cyan-400 animate-ping'
                : isThinking
                ? 'bg-purple-400 animate-pulse'
                : 'bg-cyan-400/60'
            }`}
          />
          <span className="text-[11px] font-medium text-slate-300">
            {isSpeaking
              ? 'Nagsasalita si Marvy'
              : isListening
              ? 'Nakikinig sa boses mo...'
              : isThinking
              ? 'Nag-iisip si Marvy...'
              : 'Tap si Marvy para magsalita'}
          </span>
        </div>
      </div>

      {/* 3. Error Toast */}
      {errorMessage && (
        <div className="fixed top-16 inset-x-4 max-w-md mx-auto z-40 animate-in fade-in slide-in-from-top duration-200">
          <div className="p-3 rounded-2xl bg-rose-950/90 border border-rose-500/50 text-rose-200 text-xs sm:text-sm flex items-center justify-between gap-2 shadow-2xl backdrop-blur-md">
            <div className="flex items-center gap-2 min-w-0">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span className="truncate">{errorMessage}</span>
            </div>
            <button
              onClick={onClearError}
              className="text-xs font-semibold px-2 py-0.5 rounded-lg bg-rose-900/80 hover:bg-rose-800 text-rose-100 transition shrink-0"
            >
              OK
            </button>
          </div>
        </div>
      )}

      {/* 4. Full-Bleed Interactive 3D Robot - Tapping directly toggles Microphone! */}
      <div className="absolute inset-0 w-full h-full flex items-center justify-center">
        {/* Default form = the classic face robot. Other Evolution Matrix forms render their own model,
            so picking one in the Evolution Matrix actually changes the avatar. */}
        {activeAvatarForm === 'quantum_core' ? (
          <RobotAvatar3D
            form={activeAvatarForm}
            state={state}
            emotion={emotion}
            onTapRobot={onStartListening}
          />
        ) : (
          <EvolutionAvatar3D
            form={activeAvatarForm}
            state={state}
            emotion={emotion}
            onTapSphere={onStartListening}
          />
        )}
      </div>

      {/* Spacer to push subtitle to bottom */}
      <div className="flex-1 pointer-events-none" />

      {/* 5. Minimalist Bottom Subtitle Bubble */}
      <div className="w-full max-w-lg z-20 pb-6 px-4 flex flex-col items-center">
        {/* User Interim speech during talking */}
        {userSpeechInterim && (
          <div className="w-full px-4 py-2.5 rounded-2xl bg-cyan-950/80 border border-cyan-500/60 text-cyan-200 text-xs sm:text-sm font-medium text-center shadow-2xl backdrop-blur-md animate-pulse mb-2">
            "{userSpeechInterim}"
          </div>
        )}

        {/* Marvy's Subtitle Capsule with collapse/expand */}
        {lastReplyText && !userSpeechInterim && showSubtitle && (
          <div
            className={`w-full px-4 py-3 rounded-2xl bg-slate-950/85 border shadow-2xl backdrop-blur-md transition-all duration-300 animate-in fade-in slide-in-from-bottom-2 ${getMoodBorderColor()}`}
          >
            <div className="flex items-center justify-between gap-2 mb-1">
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-cyan-400 uppercase tracking-wider">
                <MessageSquare className="w-3 h-3" />
                <span>
                  Marvy ({selectedGender === 'female' ? 'Sis' : 'Bro'})
                </span>
                {isSpeaking && (
                  <span className="text-[10px] text-emerald-400 font-mono animate-pulse">
                    • Nagsasalita...
                  </span>
                )}
              </div>
              <button
                onClick={() => setShowSubtitle(false)}
                className="text-slate-500 hover:text-slate-300 p-0.5 rounded transition"
                title="Itago ang subtitle"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-slate-200 text-xs sm:text-sm leading-relaxed max-h-24 overflow-y-auto">
              "{lastReplyText}"
            </p>
          </div>
        )}

        {/* Small restore button if subtitle was collapsed */}
        {lastReplyText && !userSpeechInterim && !showSubtitle && (
          <button
            onClick={() => setShowSubtitle(true)}
            className="flex items-center gap-1 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700/60 text-[10px] text-slate-400 hover:text-cyan-300 backdrop-blur-md transition shadow-md"
            title="Ipakita ang huling sinabi ni Marvy"
          >
            <MessageSquare className="w-3 h-3 text-cyan-400" />
            <span>Ipakita ang Subtitle</span>
            <ChevronUp className="w-3 h-3" />
          </button>
        )}
      </div>
    </div>
  );
};
