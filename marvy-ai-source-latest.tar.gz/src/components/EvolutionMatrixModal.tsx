import React from 'react';
import { X, Sparkles, Check, Zap, Cpu, Atom, Orbit, Shield } from 'lucide-react';
import { AvatarFormId, AVATAR_FORMS, AvatarFormInfo } from '../utils/conversation';
import { sfx } from '../utils/soundEffects';

interface EvolutionMatrixModalProps {
  isOpen: boolean;
  activeForm: AvatarFormId;
  onSelectForm: (formId: AvatarFormId) => void;
  onClose: () => void;
}

export const EvolutionMatrixModal: React.FC<EvolutionMatrixModalProps> = ({
  isOpen,
  activeForm,
  onSelectForm,
  onClose,
}) => {
  if (!isOpen) return null;

  const getFormIcon = (id: AvatarFormId) => {
    switch (id) {
      case 'quantum_core':
        return <Atom className="w-6 h-6 text-cyan-400" />;
      case 'synth_human':
        return <Cpu className="w-6 h-6 text-fuchsia-400" />;
      case 'celestial_aether':
        return <Sparkles className="w-6 h-6 text-amber-400" />;
      case 'nanotech_hivemind':
        return <Orbit className="w-6 h-6 text-emerald-400" />;
      case 'cyber_mech':
        return <Shield className="w-6 h-6 text-rose-400" />;
      default:
        return <Zap className="w-6 h-6 text-cyan-400" />;
    }
  };

  const handleChoose = (formId: AvatarFormId) => {
    sfx.playFormMorph();
    onSelectForm(formId);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border border-cyan-500/30 rounded-2xl shadow-2xl shadow-cyan-950/50 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-cyan-500/20 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500/20 to-fuchsia-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-400 shadow-inner">
              <Zap className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-bold tracking-tight text-white">
                  Evolution Matrix
                </h2>
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-mono">
                  Mas Advance sa Robot
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Pumili ng anyo ni Marvy lampas sa tradisyunal na mechanical robot.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
            aria-label="Isara"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-3 sm:space-y-4">
          <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-500/30 text-xs text-cyan-200/90 leading-relaxed flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <span>
              <strong>Bakit mas advance sa robot?</strong> Ang mga tradisyunal na robot ay may metal na joints at physical parts. Dito sa Marvy AI, kaya mong pumili ng <em>Quantum Singularity</em>, <em>Bionic Trans-Human</em>, o <em>Cosmic Aether</em> na may real-time 3D particle physics at audio-reactivity!
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {AVATAR_FORMS.map((form: AvatarFormInfo) => {
              const isActive = activeForm === form.id;
              return (
                <div
                  key={form.id}
                  onClick={() => handleChoose(form.id)}
                  className={`group relative p-4 rounded-xl border transition-all duration-200 cursor-pointer text-left flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                    isActive
                      ? 'bg-slate-800/90 border-cyan-400 shadow-lg shadow-cyan-900/30 ring-1 ring-cyan-400/50'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-start gap-3.5">
                    <div
                      className={`w-12 h-12 rounded-xl border flex items-center justify-center shrink-0 ${
                        isActive
                          ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                          : 'bg-slate-800/80 border-slate-700 text-slate-400 group-hover:text-cyan-300'
                      }`}
                    >
                      {getFormIcon(form.id)}
                    </div>
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-semibold text-white text-sm sm:text-base">
                          {form.name}
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                          {form.badge}
                        </span>
                        {isActive && (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-cyan-500 text-slate-950 flex items-center gap-1">
                            <Check className="w-3 h-3 stroke-[3]" /> Gamit Ngayon
                          </span>
                        )}
                      </div>
                      <p className="text-xs font-medium text-slate-300">
                        {form.tagline} • <span className="text-slate-400">{form.category}</span>
                      </p>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        {form.description}
                      </p>
                      <p className="text-[11px] text-cyan-400/90 font-mono pt-1">
                        ⚡ {form.whyAdvance}
                      </p>
                    </div>
                  </div>

                  <div className="shrink-0 self-end sm:self-center">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleChoose(form.id);
                      }}
                      className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        isActive
                          ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/30'
                          : 'bg-slate-800 text-slate-300 hover:bg-cyan-500/20 hover:text-cyan-200 border border-slate-700'
                      }`}
                    >
                      {isActive ? 'Aktibo' : 'Mag-transform'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800/80 bg-slate-950/80 flex items-center justify-between text-xs text-slate-400">
          <span>Real-time 3D Three.js Procedural Engine</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold transition-colors"
          >
            I-apply at Isara
          </button>
        </div>
      </div>
    </div>
  );
};
