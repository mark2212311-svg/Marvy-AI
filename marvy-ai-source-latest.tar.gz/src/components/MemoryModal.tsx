import React, { useState } from 'react';
import {
  X,
  Brain,
  Sparkles,
  Trash2,
  Plus,
  Heart,
  TrendingUp,
  Tag,
  Clock,
  UserCheck,
  Smile,
  ShieldCheck,
} from 'lucide-react';
import { UserMemory, UserMood } from '../utils/conversation';
import { MemoryStore, MoodLogEntry } from '../utils/memoryStore';
import { sfx } from '../utils/soundEffects';

interface MemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  memories: UserMemory[];
  callsign: string;
  onUpdateCallsign: (newCallsign: string) => void;
  onAddMemory: (key: string, value: string, category: UserMemory['category']) => void;
  onRemoveMemory: (id: string) => void;
  onClearAllMemories: () => void;
}

export const MemoryModal: React.FC<MemoryModalProps> = ({
  isOpen,
  onClose,
  memories,
  callsign,
  onUpdateCallsign,
  onAddMemory,
  onRemoveMemory,
  onClearAllMemories,
}) => {
  const [activeTab, setActiveTab] = useState<'memories' | 'moods' | 'profile'>('memories');
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newCategory, setNewCategory] = useState<UserMemory['category']>('personal');
  const [callsignInput, setCallsignInput] = useState(callsign);
  const [isSavedCallsign, setIsSavedCallsign] = useState(false);

  const moodHistory = MemoryStore.getMoodHistory();

  if (!isOpen) return null;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;
    sfx.playClick();
    onAddMemory(newKey, newValue, newCategory);
    setNewKey('');
    setNewValue('');
  };

  const handleSaveCallsign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!callsignInput.trim()) return;
    sfx.playClick();
    onUpdateCallsign(callsignInput.trim());
    setIsSavedCallsign(true);
    setTimeout(() => setIsSavedCallsign(false), 2000);
  };

  const formatTimestamp = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' • ' + d.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-2xl max-h-[90vh] bg-[#0c101a] border border-slate-700/80 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-800 bg-[#090d16]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-950/80 border border-purple-500/40 flex items-center justify-center shadow-lg shadow-purple-950/50">
              <Brain className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Kaisipan & Emosyon ni Marvy
              </h2>
              <p className="text-xs text-slate-400">
                Memory Tracking & Real-Time Emotional Intelligence Bank
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sfx.playClick();
              onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-5 sm:px-6 pt-3 border-b border-slate-800/80 bg-[#080b12]">
          <button
            onClick={() => {
              sfx.playClick();
              setActiveTab('memories');
            }}
            className={`pb-3 text-xs sm:text-sm font-semibold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'memories'
                ? 'border-purple-400 text-purple-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Brain className="w-4 h-4" />
            <span>Naalala sa Iyo ({memories.length})</span>
          </button>

          <button
            onClick={() => {
              sfx.playClick();
              setActiveTab('moods');
            }}
            className={`pb-3 text-xs sm:text-sm font-semibold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'moods'
                ? 'border-amber-400 text-amber-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Mood History ({moodHistory.length})</span>
          </button>

          <button
            onClick={() => {
              sfx.playClick();
              setActiveTab('profile');
            }}
            className={`pb-3 text-xs sm:text-sm font-semibold border-b-2 transition flex items-center gap-2 ${
              activeTab === 'profile'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Tawagan / Callsign</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {activeTab === 'memories' && (
            <div className="space-y-5">
              {/* Add Memory Form */}
              <form onSubmit={handleAdd} className="p-3.5 sm:p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-300 uppercase tracking-wider">
                  <Plus className="w-4 h-4 text-purple-400" />
                  <span>Magturo ng bagong alaala kay Marvy</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <input
                    type="text"
                    value={newKey}
                    onChange={(e) => setNewKey(e.target.value)}
                    placeholder="Paksa (e.g. Trabaho / Paborito)"
                    className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-700/80 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
                  />
                  <input
                    type="text"
                    value={newValue}
                    onChange={(e) => setNewValue(e.target.value)}
                    placeholder="Detalye (e.g. Software dev sa QC)"
                    className="sm:col-span-2 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700/80 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">Kategorya:</span>
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value as any)}
                      className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none"
                    >
                      <option value="personal">Personal</option>
                      <option value="preference">Paborito / Hilig</option>
                      <option value="mood">Emosyon / Kalagayan</option>
                      <option value="milestone">Tagumpay / Goal</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    className="px-3.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md shadow-purple-950 transition active:scale-95 flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Idagdag</span>
                  </button>
                </div>
              </form>

              {/* Memory List */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Kasalukuyang Naalala ({memories.length})
                  </h3>
                  {memories.length > 0 && (
                    <button
                      onClick={() => {
                        if (confirm('Sigurado ka bang nais mong burahin ang lahat ng alaala ni Marvy tungkol sa iyo?')) {
                          onClearAllMemories();
                        }
                      }}
                      className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 transition"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Burahin Lahat</span>
                    </button>
                  )}
                </div>

                {memories.length === 0 ? (
                  <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800 text-slate-500 text-sm">
                    Wala pang naiipong alaala. Kausapin si Marvy tungkol sa iyong araw, trabaho, o paboritong bagay at kusang itatala ito!
                  </div>
                ) : (
                  memories.map((mem) => (
                    <div
                      key={mem.id}
                      className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800/80 hover:border-purple-500/30 flex items-start justify-between gap-3 transition group"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-purple-300">
                            {mem.key}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700/60 capitalize">
                            {mem.category}
                          </span>
                        </div>
                        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                          {mem.value}
                        </p>
                        <span className="text-[10px] text-slate-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatTimestamp(mem.timestamp)}
                        </span>
                      </div>

                      <button
                        onClick={() => onRemoveMemory(mem.id)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition opacity-0 group-hover:opacity-100"
                        title="Burahin ang alaalang ito"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeTab === 'moods' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-950/30 via-slate-900 to-cyan-950/30 border border-amber-500/20">
                <h3 className="text-sm font-bold text-amber-300 flex items-center gap-2">
                  <Heart className="w-4 h-4 text-amber-400" />
                  <span>Empathy & Mood Tracker</span>
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Gamit ang deep-learning sentiment analysis ng Gemini, awtomatikong sinusuri ni Marvy ang tono ng iyong boses at mensahe upang mag-adjust ang kanyang empatiya, pacing, at sagot.
                </p>
              </div>

              {moodHistory.length === 0 ? (
                <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800 text-slate-500 text-sm">
                  Wala pang naitalang mood logs. Magsalita o mag-type para masimulan ang real-time emotional analysis!
                </div>
              ) : (
                <div className="space-y-2.5">
                  {moodHistory.map((entry) => (
                    <div
                      key={entry.id}
                      className="p-3 rounded-2xl bg-slate-900/70 border border-slate-800 flex items-center justify-between gap-3"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold text-slate-100">
                            {entry.label}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded font-mono bg-slate-800 text-slate-400">
                            {entry.mood}
                          </span>
                        </div>
                        {entry.triggerSnippet && (
                          <p className="text-xs text-slate-400 italic">
                            "{entry.triggerSnippet}"
                          </p>
                        )}
                      </div>

                      <span className="text-[10px] text-slate-500 whitespace-nowrap">
                        {formatTimestamp(entry.timestamp)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="space-y-5">
              <form onSubmit={handleSaveCallsign} className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-1">
                    Ano ang itatawag ni Marvy sa iyo?
                  </label>
                  <p className="text-xs text-slate-400 mb-3">
                    Maaari mong baguhin ang default na "Boss" sa iyong pangalan (e.g. "Boss Samantha", "Pare", "Tol", "Doc").
                  </p>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={callsignInput}
                      onChange={(e) => setCallsignInput(e.target.value)}
                      placeholder="e.g. Boss Samantha / Pare / Tol"
                      className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition active:scale-95"
                    >
                      I-save
                    </button>
                  </div>
                  {isSavedCallsign && (
                    <span className="text-xs text-emerald-400 flex items-center gap-1 mt-2">
                      <ShieldCheck className="w-3.5 h-3.5" /> Na-save na! Tatawagin ka na ngayong "{callsignInput}" ni Marvy.
                    </span>
                  )}
                </div>
              </form>

              <div className="p-4 rounded-2xl bg-slate-900/40 border border-slate-800/80 space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Privacy at Local Storage
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Lahat ng iyong alaala at kaisipan ni Marvy ay nananatiling nakatabi sa iyong browser via localStorage. Hindi ito ibinabahagi sa iba at maaari mong burahin anumang oras.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
