import React, { useEffect, useRef, useState } from 'react';
import {
  X,
  Volume2,
  Cpu,
  Key,
  Eye,
  EyeOff,
  ExternalLink,
  Info,
  Sliders,
  Play,
  Loader2,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Server,
} from 'lucide-react';
import { AVAILABLE_GEMINI_MODELS } from '../utils/conversation';
import {
  DEFAULT_CARTESIA_VOICE_ID,
  CARTESIA_MODEL_ID,
  isValidCartesiaVoiceId,
} from '../utils/cartesia';
import { requestCartesiaTts, fetchServerStatus, describeServerCandidates } from '../utils/apiClient';
import { sfx } from '../utils/soundEffects';

interface VoiceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedGender: 'female' | 'male';
  onSelectGender: (gender: 'female' | 'male') => void;
  voiceId: string;
  onSaveVoiceId: (id: string) => boolean;
  onResetVoiceId: () => void;
  aiModel: string;
  onSelectAiModel: (model: string) => void;
  customGeminiKey: string;
  onUpdateGeminiKey: (key: string) => void;
  cartesiaClientKey: string;
  onUpdateCartesiaClientKey: (key: string) => void;
  backendUrl: string;
  onUpdateBackendUrl: (url: string) => void;
  isApk: boolean;
}

type TabId = 'voice' | 'ai' | 'keys';

const SAMPLE_TEXT = 'Kumusta Boss! Ako si Marvy. Handa na akong makipagkuwentuhan sa iyo anumang oras.';

export const VoiceSettingsModal: React.FC<VoiceSettingsModalProps> = ({
  isOpen,
  onClose,
  selectedGender,
  onSelectGender,
  voiceId,
  onSaveVoiceId,
  onResetVoiceId,
  aiModel,
  onSelectAiModel,
  customGeminiKey,
  onUpdateGeminiKey,
  cartesiaClientKey,
  onUpdateCartesiaClientKey,
  backendUrl,
  onUpdateBackendUrl,
  isApk,
}) => {
  const [activeTab, setActiveTab] = useState<TabId>('voice');
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [customVoiceInput, setCustomVoiceInput] = useState('');
  const [voiceFeedback, setVoiceFeedback] = useState<{ ok: boolean; text: string } | null>(null);
  const [previewState, setPreviewState] = useState<'idle' | 'loading' | 'playing'>('idle');
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [serverState, setServerState] = useState<'checking' | 'ok' | 'nokey' | 'old' | 'unreachable'>('checking');
  const [backendDraft, setBackendDraft] = useState(backendUrl);
  const [serverBuild, setServerBuild] = useState<string>('');
  const [serverTried, setServerTried] = useState<string[]>([]);

  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const previewUrlRef = useRef<string | null>(null);
  const previewTokenRef = useRef(0);

  const isDefaultVoice = voiceId === DEFAULT_CARTESIA_VOICE_ID;

  /** Stops preview playback and frees its object URL. */
  const stopPreview = () => {
    previewTokenRef.current += 1;
    const audio = previewAudioRef.current;
    if (audio) {
      audio.onended = null;
      audio.onerror = null;
      try {
        audio.pause();
        audio.removeAttribute('src');
        audio.load();
      } catch {
        // ignore teardown errors
      }
    }
    previewAudioRef.current = null;
    if (previewUrlRef.current) {
      URL.revokeObjectURL(previewUrlRef.current);
      previewUrlRef.current = null;
    }
    setPreviewState('idle');
  };

  // Check whether the server has a Cartesia key each time the modal opens; stop preview on close.
  useEffect(() => {
    if (!isOpen) {
      stopPreview();
      return;
    }
    let cancelled = false;
    fetchServerStatus().then((status) => {
      if (cancelled) return;
      console.info('[Marvy Settings] server status:', status);
      if (!status) {
        setServerState('unreachable');
        setServerBuild('');
        setServerTried(describeServerCandidates());
        return;
      }
      setServerTried([]);
      setServerBuild(status.buildVersion ?? '(walang buildVersion: luma ang server)');
      if (status.cartesiaConfigured === undefined) setServerState('old');
      else setServerState(status.cartesiaConfigured ? 'ok' : 'nokey');
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  useEffect(() => {
    setBackendDraft(backendUrl);
  }, [backendUrl]);

  // Free preview audio if the modal unmounts while playing.
  useEffect(() => {
    return () => stopPreview();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!isOpen) return null;

  const handleClose = () => {
    stopPreview();
    sfx.playClick();
    onClose();
  };

  const handlePreview = async () => {
    stopPreview();
    sfx.playClick();
    setPreviewError(null);
    const token = previewTokenRef.current;
    setPreviewState('loading');
    try {
      const blob = await requestCartesiaTts({ text: SAMPLE_TEXT, voiceId });
      if (token !== previewTokenRef.current) return;
      const url = URL.createObjectURL(blob);
      previewUrlRef.current = url;
      const audio = new Audio(url);
      previewAudioRef.current = audio;
      audio.onplay = () => {
        if (token === previewTokenRef.current) setPreviewState('playing');
      };
      audio.onended = () => {
        if (token === previewTokenRef.current) stopPreview();
      };
      audio.onerror = () => {
        if (token === previewTokenRef.current) {
          stopPreview();
          setPreviewError('Hindi napatugtog ang sample audio.');
        }
      };
      await audio.play();
    } catch (err: any) {
      if (token !== previewTokenRef.current) return;
      stopPreview();
      setPreviewError(err?.message || 'Hindi makakuha ng audio mula sa Cartesia.');
    }
  };

  const handleSaveCustomVoice = () => {
    const trimmed = customVoiceInput.trim();
    if (!trimmed) return;
    if (!isValidCartesiaVoiceId(trimmed)) {
      setVoiceFeedback({
        ok: false,
        text: 'Mali ang format. Dapat UUID ito, halimbawa: 2e488ee5-a721-4466-b0b7-7e586e943ed3',
      });
      return;
    }
    if (onSaveVoiceId(trimmed)) {
      sfx.playRobotChirp();
      setCustomVoiceInput('');
      setVoiceFeedback({ ok: true, text: 'Na-save ang bagong boses. Pindutin ang "Pakinggan" para i-test.' });
    } else {
      setVoiceFeedback({ ok: false, text: 'Hindi na-save ang Voice ID.' });
    }
  };

  const handleResetVoice = () => {
    stopPreview();
    onResetVoiceId();
    setVoiceFeedback({ ok: true, text: 'Bumalik sa default na boses ni Marvy.' });
  };

  const handleSaveBackend = () => {
    onUpdateBackendUrl(backendDraft.trim());
    setVoiceFeedback({ ok: true, text: 'Na-save ang server URL.' });
  };

  const tabClass = (tab: TabId, accent: string) =>
    `pb-3 text-xs sm:text-sm font-semibold border-b-2 whitespace-nowrap transition flex items-center gap-2 ${
      activeTab === tab ? accent : 'border-transparent text-slate-400 hover:text-slate-200'
    }`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-2xl max-h-[92vh] bg-[#0c101a] border border-slate-700/80 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-800 bg-[#090d16]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center">
              <Sliders className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">Settings</h2>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="Isara"
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 px-5 sm:px-6 pt-3 border-b border-slate-800/80 bg-[#080b12] overflow-x-auto">
          <button
            type="button"
            onClick={() => {
              sfx.playClick();
              setActiveTab('voice');
            }}
            className={tabClass('voice', 'border-cyan-400 text-cyan-300')}
          >
            <Volume2 className="w-4 h-4" />
            <span>Voice</span>
          </button>
          <button
            type="button"
            onClick={() => {
              sfx.playClick();
              setActiveTab('ai');
            }}
            className={tabClass('ai', 'border-purple-400 text-purple-300')}
          >
            <Cpu className="w-4 h-4" />
            <span>AI Model</span>
          </button>
          <button
            type="button"
            onClick={() => {
              sfx.playClick();
              setActiveTab('keys');
            }}
            className={tabClass('keys', 'border-amber-400 text-amber-300')}
          >
            <Key className="w-4 h-4" />
            <span>API Keys</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {voiceFeedback && (
            <div
              className={`p-3 rounded-2xl text-xs flex items-center justify-between gap-2 border ${
                voiceFeedback.ok
                  ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                  : 'bg-amber-950/40 border-amber-500/40 text-amber-300'
              }`}
            >
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 flex-shrink-0" />
                <span>{voiceFeedback.text}</span>
              </div>
              <button type="button" onClick={() => setVoiceFeedback(null)} className="underline font-medium">
                Okay
              </button>
            </div>
          )}

          {/* ===== TAB: BOSES ===== */}
          {activeTab === 'voice' && (
            <div className="space-y-5">
              {/* Server key status */}
              <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center gap-3">
                <Server className="w-4 h-4 text-slate-400 flex-shrink-0" />
                <div className="text-xs">
                  {serverState === 'checking' && <span className="text-slate-400">Checking server...</span>}
                  {serverState === 'ok' && (
                    <span className="text-emerald-300 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Cartesia key active on server
                    </span>
                  )}
                  {serverState === 'nokey' && (
                    <span className="text-rose-300 flex items-center gap-1.5">
                      <XCircle className="w-3.5 h-3.5" /> No CARTESIA_API_KEY on server.
                    </span>
                  )}
                  {serverState === 'old' && (
                    <span className="text-rose-300 flex items-center gap-1.5">
                      <XCircle className="w-3.5 h-3.5" /> Server version outdated. Redeploy.
                    </span>
                  )}
                  {serverBuild && <div className="text-[10px] text-slate-500 mt-1 font-mono">Build: {serverBuild}</div>}
                  {serverState === 'unreachable' && (
                    <span className="text-rose-300 flex items-center gap-1.5">
                      <XCircle className="w-3.5 h-3.5" /> Server unreachable.
                    </span>
                  )}
                  {serverState === 'unreachable' && serverTried.length > 0 && (
                    <div className="text-[10px] text-slate-500 mt-1 font-mono break-all">
                      Tried: {serverTried.join(' , ')}
                    </div>
                  )}
                </div>
              </div>

              {/* Active voice */}
              <div className="p-4 rounded-2xl bg-slate-900/70 border border-cyan-500/30 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-2">
                      Active Voice
                      {isDefaultVoice && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                          Default
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400">Model: {CARTESIA_MODEL_ID}</div>
                  </div>
                  <button
                    type="button"
                    onClick={handlePreview}
                    disabled={previewState === 'loading'}
                    className="px-3.5 py-2 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 text-xs font-semibold hover:bg-cyan-500/30 transition inline-flex items-center gap-1.5 disabled:opacity-60"
                  >
                    {previewState === 'loading' && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    {previewState === 'playing' && <Volume2 className="w-3.5 h-3.5 animate-pulse" />}
                    {previewState === 'idle' && <Play className="w-3.5 h-3.5" />}
                    <span>
                      {previewState === 'loading'
                        ? 'Loading...'
                        : previewState === 'playing'
                        ? 'Playing...'
                        : 'Preview'}
                    </span>
                  </button>
                </div>
                <div className="text-[11px] font-mono text-slate-400 break-all bg-slate-950/70 border border-slate-800 rounded-lg px-2.5 py-2">
                  {voiceId}
                </div>
                {previewError && <p className="text-xs text-rose-300">{previewError}</p>}
                {!isDefaultVoice && (
                  <button
                    type="button"
                    onClick={handleResetVoice}
                    className="text-xs text-cyan-300 hover:text-white underline inline-flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" /> Reset to default voice
                  </button>
                )}
              </div>

              {/* Custom voice ID */}
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
                <div>
                  <div className="text-sm font-bold text-white">Custom Cartesia Voice ID</div>
                  <p className="text-[11px] text-slate-400">
                    Paste a Cartesia Voice ID.
                  </p>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customVoiceInput}
                    onChange={(e) => setCustomVoiceInput(e.target.value)}
                    placeholder="Voice ID (UUID)"
                    spellCheck={false}
                    autoComplete="off"
                    className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono text-slate-100 focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    type="button"
                    onClick={handleSaveCustomVoice}
                    disabled={!customVoiceInput.trim()}
                    className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition disabled:opacity-40"
                  >
                    Save
                  </button>
                </div>
              </div>

              {/* Persona Removed */}
            </div>
          )}

          {/* ===== TAB: AI MODEL ===== */}
          {activeTab === 'ai' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400">Pumili ng Gemini model para sa mga sagot ni Marvy.</p>
              {AVAILABLE_GEMINI_MODELS.map((model) => {
                const isSelected = aiModel === model.id;
                return (
                  <button
                    key={model.id}
                    type="button"
                    onClick={() => {
                      sfx.playClick();
                      onSelectAiModel(model.id);
                    }}
                    className={`w-full text-left p-3.5 rounded-2xl border transition ${
                      isSelected
                        ? 'bg-purple-950/50 border-purple-400 ring-1 ring-purple-400/40'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-bold text-white">{model.name}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">{model.speed}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">{model.description}</p>
                    {isSelected && <p className="text-[10px] text-purple-300 mt-1.5">✓ Kasalukuyang model</p>}
                  </button>
                );
              })}
            </div>
          )}

          {/* ===== TAB: KEYS & GABAY ===== */}
          {activeTab === 'keys' && (
            <div className="space-y-5">
              {/* Cartesia guide */}
              <div className="p-4 rounded-2xl bg-slate-900/70 border border-amber-500/30 space-y-2.5 text-xs text-slate-300 leading-relaxed">
                <div className="text-sm font-bold text-amber-300 flex items-center gap-2">
                  <Key className="w-4 h-4" /> Cartesia API Key (para sa boses)
                </div>
                <ol className="list-decimal pl-5 space-y-1.5">
                  <li>
                    Kunin ang key sa{' '}
                    <a href="https://play.cartesia.ai" target="_blank" rel="noreferrer" className="text-cyan-400 underline">
                      play.cartesia.ai
                    </a>{' '}
                    (API Keys).
                  </li>
                  <li>
                    Ilagay ito sa <code className="text-amber-200">CARTESIA_API_KEY</code> sa server environment (file na{' '}
                    <code>.env</code> o Secrets panel).
                  </li>
                  <li>I-restart ang server pagkatapos. Nananatili ang key sa server at hindi napupunta sa browser.</li>
                </ol>
                <p className="text-[11px] text-slate-400">
                  Kung naka-deploy sa Cloud Run o APK, ilagay ang key sa mismong server na iyon.
                </p>
              </div>

              {/* Personal Cartesia key (no-server option) */}
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
                <div>
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <Key className="w-4 h-4 text-amber-400" /> Personal Cartesia Key (kung walang server)
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Kapag hindi maabot ang server, ang app na mismo ang tatawag sa Cartesia gamit ang key na ito. Naka-save lang sa device mo.
                  </p>
                </div>
                <input
                  type="password"
                  value={cartesiaClientKey}
                  onChange={(e) => onUpdateCartesiaClientKey(e.target.value.trim())}
                  placeholder="Cartesia API key"
                  autoComplete="off"
                  spellCheck={false}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono text-slate-100 focus:outline-none focus:border-cyan-500"
                />
                {!cartesiaClientKey && (
                  <p className="text-[11px] text-amber-300">Walang naka-save na Cartesia API key. Ilagay ito sa itaas.</p>
                )}
                {cartesiaClientKey && isValidCartesiaVoiceId(cartesiaClientKey) && (
                  <p className="text-[11px] text-rose-300">
                    Mukhang Voice ID ang nailagay dito, hindi API key. Ang Voice ID ay para sa boses; kopyahin ang API key mula sa play.cartesia.ai.
                  </p>
                )}
                {cartesiaClientKey && !isValidCartesiaVoiceId(cartesiaClientKey) && (
                  <p className="text-[11px] text-emerald-300">May naka-save na Cartesia key sa device na ito.</p>
                )}
              </div>

              {/* Gemini key */}
              <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
                <div>
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <Key className="w-4 h-4 text-cyan-400" /> Personal Gemini API Key (opsyonal)
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Gamitin kung naubos ang libreng quota ng server. Naka-save lang ito sa device mo.
                  </p>
                </div>
                <div className="flex gap-2">
                  <input
                    type={showGeminiKey ? 'text' : 'password'}
                    value={customGeminiKey}
                    onChange={(e) => onUpdateGeminiKey(e.target.value)}
                    placeholder="AIza..."
                    autoComplete="off"
                    spellCheck={false}
                    className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono text-slate-100 focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowGeminiKey((v) => !v)}
                    aria-label={showGeminiKey ? 'Itago ang key' : 'Ipakita ang key'}
                    className="px-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white"
                  >
                    {showGeminiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <a
                  href="https://aistudio.google.com/app/apikey"
                  target="_blank"
                  rel="noreferrer"
                  className="text-[11px] text-cyan-400 underline inline-flex items-center gap-1"
                >
                  Kunin ang Gemini key <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Server URL (APK / separate backend) */}
              {/* Server URL is always editable, so it can be set even when the app is not detected as an APK */}
              {true && (
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
                  <div className="text-sm font-bold text-white">Server URL</div>
                  <p className="text-[11px] text-slate-400">Ilagay ang URL ng Marvy server kung naka-APK ka.</p>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={backendDraft}
                      onChange={(e) => setBackendDraft(e.target.value)}
                      placeholder="https://your-server.example.com"
                      className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
                    />
                    <button
                      type="button"
                      onClick={handleSaveBackend}
                      className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition"
                    >
                      I-save
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
