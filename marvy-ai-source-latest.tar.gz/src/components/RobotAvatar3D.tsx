// src/components/RobotAvatar3D.tsx
import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { ConversationState, RobotEmotion, AvatarFormId } from '../utils/conversation';
import { sfx } from '../utils/soundEffects';

interface RobotAvatar3DProps {
  form?: AvatarFormId;
  state: ConversationState;
  emotion: RobotEmotion;
  onTapRobot?: () => void;
}

export const RobotAvatar3D: React.FC<RobotAvatar3DProps> = ({
  state,
  emotion,
  onTapRobot,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const faceCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const faceTextureRef = useRef<THREE.CanvasTexture | null>(null);

  // Stable callback ref so Three.js lifecycle never re-mounts on parent state updates
  const onTapRobotRef = useRef(onTapRobot);
  useEffect(() => {
    onTapRobotRef.current = onTapRobot;
  }, [onTapRobot]);

  // Mutable refs for smooth animation loop
  const stateRef = useRef<ConversationState>(state);
  const emotionRef = useRef<RobotEmotion>(emotion);
  const targetRotationRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const isPointerDownRef = useRef<boolean>(false);
  const tapWinkTimerRef = useRef<number>(0);

  // Smooth interaction transitions (replaces abrupt bouncing)
  const smoothNodRef = useRef<number>(0);
  const smoothColorRef = useRef<THREE.Color>(new THREE.Color(0x06b6d4));
  const targetColorRef = useRef<THREE.Color>(new THREE.Color(0x06b6d4));

  // Saccadic eye tracking state
  const saccadeOffsetRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const nextSaccadeTimeRef = useRef<number>(0);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    emotionRef.current = emotion;
    switch (emotion) {
      case 'happy':
        targetColorRef.current.setHex(0x22d3ee);
        break;
      case 'playful':
        targetColorRef.current.setHex(0xf472b6);
        break;
      case 'empathic':
        targetColorRef.current.setHex(0xfbbf24);
        break;
      case 'soothing':
        targetColorRef.current.setHex(0x34d399);
        break;
      case 'thinking':
        targetColorRef.current.setHex(0xc084fc);
        break;
      default:
        targetColorRef.current.setHex(0x06b6d4);
    }
  }, [emotion]);

  useEffect(() => {
    if (!mountRef.current) return;

    const container = mountRef.current;
    const width = container.clientWidth || 360;
    const height = container.clientHeight || 640;

    // Detect software WebGL for performance optimization
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    // 1. Scene, Camera & Renderer
    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);

    const updateCameraDistance = (w: number, h: number) => {
      const aspect = w / h;
      camera.aspect = aspect;

      // Robot bounds:
      // Width: 3.50 units (ears to ears)
      // Height: 2.84 units (collar to antenna tip)
      const targetSpan = 3.8;
      const tanHalfFov = Math.tan((40 * Math.PI) / 360); // ~0.364

      if (aspect < 0.95) {
        // Portrait mobile screen: accommodate full robot safely with clean margins
        const zDist = targetSpan / (2 * tanHalfFov * Math.max(0.40, aspect));
        camera.position.set(0, 0.12, Math.max(5.8, Math.min(8.6, zDist)));
        camera.fov = 40;
      } else {
        // Landscape / Tablet / Desktop
        camera.position.set(0, 0.08, 4.6);
        camera.fov = 36;
      }
      camera.updateProjectionMatrix();
    };

    updateCameraDistance(width, height);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      alpha: true,
      powerPreference: 'high-performance',
      precision: 'highp',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.75));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;

    container.appendChild(renderer.domElement);

    // 2. Studio Lighting Environment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.05).texture;
    pmremGenerator.dispose();

    // Lighting Rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0x06b6d4, 3.4);
    keyLight.position.set(3.5, 4.5, 3.5);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xa855f7, 2.4);
    fillLight.position.set(-3.5, -0.5, 2.5);
    scene.add(fillLight);

    const rimLight = new THREE.PointLight(0x38bdf8, 3.2, 12);
    rimLight.position.set(0, 3.5, -2.5);
    scene.add(rimLight);

    const warmEmpathyLight = new THREE.PointLight(0xfbbf24, 0, 6);
    warmEmpathyLight.position.set(0, 0.2, 2.2);
    scene.add(warmEmpathyLight);

    // Dynamic Ground Contact Shadow Disc
    const shadowGeo = new THREE.PlaneGeometry(2.6, 2.6);
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const sCtx = shadowCanvas.getContext('2d')!;
    const sGrad = sCtx.createRadialGradient(64, 64, 8, 64, 64, 64);
    sGrad.addColorStop(0, 'rgba(0, 0, 0, 0.7)');
    sGrad.addColorStop(0.45, 'rgba(6, 182, 212, 0.12)');
    sGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    sCtx.fillStyle = sGrad;
    sCtx.fillRect(0, 0, 128, 128);

    const shadowTex = new THREE.CanvasTexture(shadowCanvas);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTex,
      transparent: true,
      opacity: 0.7,
      depthWrite: false,
    });
    const shadowMesh = new THREE.Mesh(shadowGeo, shadowMat);
    shadowMesh.rotation.x = -Math.PI / 2;
    shadowMesh.position.set(0, -1.5, 0);
    scene.add(shadowMesh);

    // 3. High-Performance Lightweight OLED Face Canvas (512x512)
    // 512x512 uses 4x less memory and texture bus bandwidth than 1024x1024, running buttery-smooth on mobile!
    const faceCanvas = document.createElement('canvas');
    faceCanvas.width = 512;
    faceCanvas.height = 512;
    faceCanvasRef.current = faceCanvas;
    const ctx = faceCanvas.getContext('2d', { willReadFrequently: false })!;

    const faceTexture = new THREE.CanvasTexture(faceCanvas);
    faceTexture.colorSpace = THREE.SRGBColorSpace;
    faceTexture.minFilter = THREE.LinearFilter;
    faceTexture.magFilter = THREE.LinearFilter;
    faceTextureRef.current = faceTexture;

    // 4. Hierarchical 3D Robot Assembly
    const robotGroup = new THREE.Group();
    scene.add(robotGroup);

    // Part A: Main Outer Spherical Shell (Glossy obsidian clearcoat)
    const headGeo = new THREE.SphereGeometry(1.2, 54, 54);
    const headMat = new THREE.MeshPhysicalMaterial({
      color: 0x070b12,
      metalness: 0.8,
      roughness: 0.12,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
      reflectivity: 0.95,
    });
    const headMesh = new THREE.Mesh(headGeo, headMat);
    robotGroup.add(headMesh);

    // Part B: Seamless Curved Front Digital Visor Screen
    const visorGeo = new THREE.PlaneGeometry(1.42, 1.18, 36, 36);
    const vPos = visorGeo.attributes.position;
    for (let i = 0; i < vPos.count; i++) {
      const vx = vPos.getX(i);
      const vy = vPos.getY(i);
      const rSq = 1.208 * 1.208;
      const distSq = vx * vx + vy * vy;
      const z = Math.sqrt(Math.max(0.01, rSq - Math.min(rSq - 0.01, distSq)));
      vPos.setZ(i, z);
    }
    visorGeo.computeVertexNormals();

    const visorMat = new THREE.MeshBasicMaterial({
      map: faceTexture,
      transparent: true,
      opacity: 1.0,
      side: THREE.FrontSide,
      depthTest: true,
      depthWrite: false,
    });
    const visorMesh = new THREE.Mesh(visorGeo, visorMat);
    visorMesh.position.set(0, 0.02, 0);
    robotGroup.add(visorMesh);

    // Part C: Titanium Acoustic Ear Pods
    const earGeo = new THREE.CylinderGeometry(0.26, 0.35, 0.45, 28);
    const earMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      metalness: 0.92,
      roughness: 0.18,
    });

    const leftEar = new THREE.Mesh(earGeo, earMat);
    leftEar.position.set(-1.26, 0.08, 0);
    leftEar.rotation.z = Math.PI / 2;
    robotGroup.add(leftEar);

    const rightEar = new THREE.Mesh(earGeo, earMat);
    rightEar.position.set(1.26, 0.08, 0);
    rightEar.rotation.z = -Math.PI / 2;
    robotGroup.add(rightEar);

    // Glowing Neon Ear Rings
    const ringGeo = new THREE.TorusGeometry(0.33, 0.04, 16, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });

    const leftRing = new THREE.Mesh(ringGeo, ringMat);
    leftRing.position.set(-1.42, 0.08, 0);
    leftRing.rotation.y = Math.PI / 2;
    robotGroup.add(leftRing);

    const rightRing = new THREE.Mesh(ringGeo, ringMat);
    rightRing.position.set(1.42, 0.08, 0);
    rightRing.rotation.y = Math.PI / 2;
    robotGroup.add(rightRing);

    // Part D: Top Fin & Floating Plasma Antenna Tip
    const finGeo = new THREE.ConeGeometry(0.18, 0.52, 20);
    const finMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      metalness: 0.8,
      roughness: 0.15,
    });
    const topFin = new THREE.Mesh(finGeo, finMat);
    topFin.position.set(0, 1.4, 0);
    robotGroup.add(topFin);

    const antennaTipGeo = new THREE.SphereGeometry(0.09, 20, 20);
    const antennaTipMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const antennaTip = new THREE.Mesh(antennaTipGeo, antennaTipMat);
    antennaTip.position.set(0, 1.7, 0);
    robotGroup.add(antennaTip);

    const antennaLight = new THREE.PointLight(0x06b6d4, 1.8, 4.5);
    antennaLight.position.set(0, 1.72, 0);
    robotGroup.add(antennaLight);

    // Part E: Dual Counter-Rotating Gyroscopic Levitation Rings
    const outerCollarGeo = new THREE.TorusGeometry(1.42, 0.045, 14, 48);
    const outerCollarMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      metalness: 0.95,
      roughness: 0.12,
      emissive: 0x0369a1,
      emissiveIntensity: 0.5,
    });
    const outerCollar = new THREE.Mesh(outerCollarGeo, outerCollarMat);
    outerCollar.position.set(0, -0.92, 0);
    outerCollar.rotation.x = Math.PI / 2.3;
    robotGroup.add(outerCollar);

    const innerCollarGeo = new THREE.TorusGeometry(1.22, 0.025, 14, 40);
    const innerCollarMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      metalness: 0.98,
      roughness: 0.1,
      emissive: 0x0891b2,
      emissiveIntensity: 0.6,
    });
    const innerCollar = new THREE.Mesh(innerCollarGeo, innerCollarMat);
    innerCollar.position.set(0, -0.98, 0);
    innerCollar.rotation.x = Math.PI / 2.3;
    robotGroup.add(innerCollar);

    // Part F: Ambient Micro Cyber Particles
    const particleCount = 35;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const r = 1.6 + Math.random() * 0.9;
      particlePositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      particlePositions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      particlePositions[i * 3 + 2] = r * Math.cos(phi);
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 0.035,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending,
    });
    const particleSystem = new THREE.Points(particleGeo, particleMat);
    robotGroup.add(particleSystem);

    // 5. Procedural Dynamic Face Drawer (Ultra-Fast 512x512, zero CPU shadowBlur lag)
    const drawFace = (time: number) => {
      ctx.clearRect(0, 0, 512, 512);

      const curEmotion = emotionRef.current;
      const curState = stateRef.current;

      let primaryGlow = '#06b6d4';
      let pupilColor = '#e0f2fe';

      if (curEmotion === 'happy') {
        primaryGlow = '#22d3ee';
        pupilColor = '#ffffff';
      } else if (curEmotion === 'playful') {
        primaryGlow = '#f472b6';
        pupilColor = '#fff1f2';
      } else if (curEmotion === 'empathic') {
        primaryGlow = '#fbbf24';
        pupilColor = '#fffbeb';
      } else if (curEmotion === 'soothing') {
        primaryGlow = '#34d399';
        pupilColor = '#ecfdf5';
      } else if (curEmotion === 'thinking') {
        primaryGlow = '#c084fc';
        pupilColor = '#faf5ff';
      }

      // Smooth circular visor screen background
      const grad = ctx.createRadialGradient(256, 256, 190, 256, 256, 225);
      grad.addColorStop(0, '#020408');
      grad.addColorStop(0.92, '#020408');
      grad.addColorStop(1, 'rgba(2, 4, 8, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(256, 256, 225, 0, Math.PI * 2);
      ctx.fill();

      // Ambient Floating Data Bits
      ctx.fillStyle = primaryGlow + '77';
      const dust1Y = 120 + Math.sin(time * 0.002) * 8;
      const dust2Y = 180 + Math.cos(time * 0.0025) * 10;
      const dust3Y = 145 + Math.sin(time * 0.003) * 6;
      ctx.fillRect(247, dust1Y, 6, 6);
      ctx.fillRect(270, dust2Y, 5, 5);
      ctx.fillRect(400, dust3Y, 5, 5);

      // Micro-Saccades
      if (time > nextSaccadeTimeRef.current) {
        saccadeOffsetRef.current = {
          x: (Math.random() - 0.5) * 6,
          y: (Math.random() - 0.5) * 4,
        };
        nextSaccadeTimeRef.current = time + 1400 + Math.random() * 1400;
      }

      const gazeX = targetRotationRef.current.y * 14 + saccadeOffsetRef.current.x;
      const gazeY = -targetRotationRef.current.x * 12 + saccadeOffsetRef.current.y;

      const leftEyeX = 185 + gazeX;
      const rightEyeX = 327 + gazeX;
      const eyeY = 230 + gazeY;

      // Blinking
      const blinkCycle = (time * 0.0018) % 6;
      const isNaturalBlink = blinkCycle < 0.16 || (blinkCycle > 0.35 && blinkCycle < 0.48);
      const isTapWink = tapWinkTimerRef.current > 0;

      ctx.save();
      // Use bright double-pass strokes instead of expensive software shadowBlur for silky 60fps
      ctx.strokeStyle = primaryGlow;
      ctx.fillStyle = pupilColor;
      ctx.lineWidth = 13;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      // Expressive Eyebrows
      ctx.save();
      ctx.lineWidth = 5;
      ctx.strokeStyle = primaryGlow;
      ctx.beginPath();
      if (curEmotion === 'happy') {
        ctx.arc(leftEyeX, eyeY - 42, 28, Math.PI * 1.25, Math.PI * 1.75, false);
        ctx.moveTo(rightEyeX - 20, eyeY - 50);
        ctx.arc(rightEyeX, eyeY - 42, 28, Math.PI * 1.25, Math.PI * 1.75, false);
      } else if (curEmotion === 'playful') {
        ctx.moveTo(leftEyeX - 22, eyeY - 55);
        ctx.lineTo(leftEyeX + 22, eyeY - 47);
        ctx.moveTo(rightEyeX - 22, eyeY - 40);
        ctx.lineTo(rightEyeX + 22, eyeY - 45);
      } else if (curEmotion === 'empathic') {
        ctx.moveTo(leftEyeX - 20, eyeY - 37);
        ctx.lineTo(leftEyeX + 20, eyeY - 47);
        ctx.moveTo(rightEyeX - 20, eyeY - 47);
        ctx.lineTo(rightEyeX + 20, eyeY - 37);
      } else if (curEmotion === 'thinking') {
        ctx.moveTo(leftEyeX - 22, eyeY - 42);
        ctx.lineTo(leftEyeX + 22, eyeY - 42);
        ctx.moveTo(rightEyeX - 22, eyeY - 55);
        ctx.lineTo(rightEyeX + 22, eyeY - 47);
      } else {
        ctx.moveTo(leftEyeX - 18, eyeY - 44);
        ctx.lineTo(leftEyeX + 18, eyeY - 44);
        ctx.moveTo(rightEyeX - 18, eyeY - 44);
        ctx.lineTo(rightEyeX + 18, eyeY - 44);
      }
      ctx.stroke();
      ctx.restore();

      // Render Eyes
      if (isNaturalBlink && !isTapWink && curEmotion !== 'playful') {
        ctx.beginPath();
        ctx.moveTo(leftEyeX - 32, eyeY);
        ctx.lineTo(leftEyeX + 32, eyeY);
        ctx.moveTo(rightEyeX - 32, eyeY);
        ctx.lineTo(rightEyeX + 32, eyeY);
        ctx.stroke();
      } else if (isTapWink) {
        ctx.beginPath();
        ctx.arc(leftEyeX, eyeY + 10, 35, Math.PI * 1.15, Math.PI * 1.85, false);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(rightEyeX - 32, eyeY);
        ctx.lineTo(rightEyeX + 32, eyeY);
        ctx.stroke();
      } else {
        switch (curEmotion) {
          case 'happy': {
            ctx.beginPath();
            ctx.arc(leftEyeX, eyeY + 11, 37, Math.PI * 1.15, Math.PI * 1.85, false);
            ctx.stroke();
            ctx.beginPath();
            ctx.arc(rightEyeX, eyeY + 11, 37, Math.PI * 1.15, Math.PI * 1.85, false);
            ctx.stroke();

            // Rosy cheeks
            ctx.fillStyle = 'rgba(244, 114, 182, 0.35)';
            ctx.beginPath();
            ctx.arc(leftEyeX - 12, eyeY + 48, 16, 0, Math.PI * 2);
            ctx.arc(rightEyeX + 12, eyeY + 48, 16, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          case 'playful': {
            ctx.beginPath();
            ctx.moveTo(leftEyeX - 30, eyeY - 25);
            ctx.lineTo(leftEyeX + 18, eyeY);
            ctx.lineTo(leftEyeX - 30, eyeY + 25);
            ctx.stroke();

            ctx.beginPath();
            ctx.moveTo(rightEyeX + 30, eyeY - 25);
            ctx.lineTo(rightEyeX - 18, eyeY);
            ctx.lineTo(rightEyeX + 30, eyeY + 25);
            ctx.stroke();
            break;
          }
          case 'empathic': {
            ctx.beginPath();
            ctx.arc(leftEyeX, eyeY + 6, 32, Math.PI * 1.1, Math.PI * 1.9, false);
            ctx.stroke();
            ctx.beginPath();
            ctx.arc(rightEyeX, eyeY + 6, 32, Math.PI * 1.1, Math.PI * 1.9, false);
            ctx.stroke();

            // Heart icon
            ctx.fillStyle = '#fbbf24';
            const heartPulse = 13 + Math.sin(time * 0.006) * 3;
            ctx.beginPath();
            ctx.arc(256 - heartPulse * 0.5, 300, heartPulse * 0.5, Math.PI, 0, false);
            ctx.arc(256 + heartPulse * 0.5, 300, heartPulse * 0.5, Math.PI, 0, false);
            ctx.lineTo(256, 300 + heartPulse * 1.25);
            ctx.closePath();
            ctx.fill();
            break;
          }
          case 'soothing': {
            const breath = Math.sin(time * 0.003) * 6;
            ctx.beginPath();
            ctx.ellipse(leftEyeX, eyeY, 32, 22 + breath, 0, 0, Math.PI * 2);
            ctx.ellipse(rightEyeX, eyeY, 32, 22 + breath, 0, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
          case 'thinking': {
            ctx.beginPath();
            ctx.ellipse(leftEyeX, eyeY - 8, 28, 36, -0.1, 0, Math.PI * 2);
            ctx.ellipse(rightEyeX, eyeY + 4, 34, 26, 0.15, 0, Math.PI * 2);
            ctx.fill();

            ctx.save();
            ctx.lineWidth = 2;
            const rot = time * 0.003;
            ctx.translate(256, eyeY);
            ctx.rotate(rot);
            ctx.strokeRect(-45, -45, 90, 90);
            ctx.restore();
            break;
          }
          default: {
            ctx.beginPath();
            ctx.arc(leftEyeX - 5, eyeY + 6, 20, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.arc(rightEyeX + 5, eyeY - 6, 36, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#ffffff';
            ctx.beginPath();
            ctx.arc(leftEyeX - 9, eyeY + 2, 4, 0, Math.PI * 2);
            ctx.arc(rightEyeX + 1, eyeY - 12, 7, 0, Math.PI * 2);
            ctx.fill();
            break;
          }
        }
      }

      // Listening mode pulsating sonar rings
      if (curState === 'listening') {
        const pingR = 38 + (time * 0.04) % 25;
        ctx.lineWidth = 3;
        ctx.strokeStyle = primaryGlow + 'aa';
        ctx.beginPath();
        ctx.arc(leftEyeX, eyeY, pingR, 0, Math.PI * 2);
        ctx.arc(rightEyeX, eyeY, pingR, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Dynamic Animated Mouth
      ctx.lineWidth = 5;
      ctx.strokeStyle = primaryGlow;
      const mouthY = 330;

      if (curState === 'speaking') {
        ctx.beginPath();
        for (let x = 180; x <= 332; x += 6) {
          const wave =
            Math.sin(x * 0.08 + time * 0.025) *
            Math.cos(x * 0.04) *
            (14 + Math.sin(time * 0.015) * 7);
          if (x === 180) ctx.moveTo(x, mouthY + wave);
          else ctx.lineTo(x, mouthY + wave);
        }
        ctx.stroke();
      } else if (curEmotion === 'happy' || curEmotion === 'playful') {
        ctx.beginPath();
        ctx.arc(256, mouthY - 9, 28, Math.PI * 0.18, Math.PI * 0.82, false);
        ctx.stroke();
      } else if (curEmotion === 'empathic' || curEmotion === 'soothing') {
        ctx.beginPath();
        ctx.arc(256, mouthY - 5, 20, Math.PI * 0.2, Math.PI * 0.8, false);
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.moveTo(240, mouthY);
        ctx.lineTo(272, mouthY);
        ctx.stroke();
      }

      ctx.restore();
      faceTexture.needsUpdate = true;
    };

    // 6. Smooth Pointer & Tap Handler (Direct Mic / Push-To-Talk)
    const handlePointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      const normX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const normY = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      targetRotationRef.current = {
        x: normY * 0.35,
        y: normX * 0.5,
      };
    };

    const handlePointerDown = () => {
      isPointerDownRef.current = true;
      smoothNodRef.current = 0.06;
      tapWinkTimerRef.current = 0.45;
      sfx.playRobotChirp();

      // Stable ref call avoids re-mounting scene
      if (onTapRobotRef.current) {
        onTapRobotRef.current();
      }
    };

    const handlePointerUp = () => {
      isPointerDownRef.current = false;
    };

    const handlePointerLeave = () => {
      targetRotationRef.current = { x: 0, y: 0 };
    };

    container.addEventListener('pointermove', handlePointerMove);
    container.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointerup', handlePointerUp);
    container.addEventListener('pointerleave', handlePointerLeave);

    // 7. Kinematic & Render Loop (Silky Smooth Continuous 60fps)
    let lastTime = performance.now();
    let lastFaceUpdate = 0;
    const FACE_UPDATE_INTERVAL = 1000 / 30; // 30 FPS face updates

    const animate = (time: number) => {
      animFrame = requestAnimationFrame(animate);

      const delta = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      if (tapWinkTimerRef.current > 0) {
        tapWinkTimerRef.current -= delta;
      }

      smoothNodRef.current += (0 - smoothNodRef.current) * 3.5 * delta;
      smoothColorRef.current.lerp(targetColorRef.current, delta * 3.0);

      if (time - lastFaceUpdate >= FACE_UPDATE_INTERVAL) {
        drawFace(time);
        lastFaceUpdate = time;
      }

      const curEmotion = emotionRef.current;
      const isSpeaking = stateRef.current === 'speaking';
      const isThinking = stateRef.current === 'thinking';

      const breathingRate = curEmotion === 'soothing' ? 0.0016 : 0.0024;
      const breathingBob = Math.sin(time * breathingRate) * 0.065;
      const breathingPitch = Math.cos(time * breathingRate) * 0.012;

      const speakingBob = isSpeaking ? Math.sin(time * 0.018) * 0.03 : 0;

      const hoverY = breathingBob + speakingBob + smoothNodRef.current;
      robotGroup.position.y = hoverY;
      robotGroup.rotation.z = Math.sin(time * 0.0035) * 0.02 + (isThinking ? 0.05 : 0);

      const shadowScale = 1.0 - hoverY * 0.3;
      shadowMesh.scale.set(shadowScale, shadowScale, 1.0);
      shadowMat.opacity = Math.max(0.35, Math.min(0.85, 0.7 - hoverY * 0.4));

      robotGroup.rotation.y +=
        (targetRotationRef.current.y - robotGroup.rotation.y) * 0.085;
      robotGroup.rotation.x +=
        (targetRotationRef.current.x + breathingPitch - smoothNodRef.current - robotGroup.rotation.x) *
        0.085;

      outerCollar.rotation.z += 0.012;
      innerCollar.rotation.z -= 0.018;
      outerCollar.rotation.x = Math.PI / 2.3 + Math.sin(time * 0.003) * 0.05;

      ringMat.color.copy(smoothColorRef.current);
      antennaTipMat.color.copy(smoothColorRef.current);
      antennaLight.color.copy(smoothColorRef.current);
      antennaLight.intensity =
        1.4 +
        (isSpeaking
          ? Math.sin(time * 0.02) * 1.0
          : Math.sin(time * 0.003) * 0.4);

      let empathyPower = 0;
      if (curEmotion === 'empathic') empathyPower = 1.8;
      else if (curEmotion === 'happy') empathyPower = 0.3;
      else if (curEmotion === 'playful') empathyPower = 0.5;
      else if (curEmotion === 'soothing') empathyPower = 0.7;
      else if (curEmotion === 'thinking') empathyPower = 0.4;
      warmEmpathyLight.intensity += (empathyPower - warmEmpathyLight.intensity) * delta * 2.5;

      particleSystem.rotation.y = time * 0.00035;

      renderer.render(scene, camera);
    };

    let animFrame = requestAnimationFrame(animate);

    const resizeObserver = new ResizeObserver(() => {
      const newW = container.clientWidth || 360;
      const newH = container.clientHeight || 640;
      updateCameraDistance(newW, newH);
      renderer.setSize(newW, newH);
    });
    resizeObserver.observe(container);

    return () => {
      cancelAnimationFrame(animFrame);
      resizeObserver.disconnect();
      container.removeEventListener('pointermove', handlePointerMove);
      container.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointerup', handlePointerUp);
      container.removeEventListener('pointerleave', handlePointerLeave);

      headGeo.dispose();
      headMat.dispose();
      visorGeo.dispose();
      visorMat.dispose();
      earGeo.dispose();
      earMat.dispose();
      ringGeo.dispose();
      ringMat.dispose();
      finGeo.dispose();
      finMat.dispose();
      antennaTipGeo.dispose();
      antennaTipMat.dispose();
      outerCollarGeo.dispose();
      outerCollarMat.dispose();
      innerCollarGeo.dispose();
      innerCollarMat.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      shadowTex.dispose();
      faceTexture.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []); // Empty dependency array ensures Three.js mounts once and NEVER re-initializes on timer ticks!

  return (
    <div
      ref={mountRef}
      className="relative w-full h-full min-h-[420px] flex items-center justify-center cursor-pointer select-none touch-none"
      title="I-tap si Marvy para magsalita!"
    />
  );
};
