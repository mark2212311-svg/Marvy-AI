import React from 'react';
import {
  Heart,
  Smile,
  Sparkles,
  Zap,
  Eye,
  Brain,
  Sliders,
  Settings,
  Cpu,
  RefreshCw,
  TrendingUp,
  Activity,
  MessageSquare,
  Flame,
  Coffee,
  Car,
  Gift,
} from 'lucide-react';
import {
  RobotEmotion,
  SentimentAnalysis,
  UserMood,
  AvatarFormId,
  AVATAR_FORMS,
} from '../utils/conversation';
import { sfx } from '../utils/soundEffects';

interface FeaturesHubViewProps {
  emotion: RobotEmotion;
  lastSentiment?: SentimentAnalysis;
  activeAvatarForm: AvatarFormId;
  memoryCount: number;
  voiceName: string;
  onSelectEmotion: (emotion: RobotEmotion) => void;
  onQuickPrompt: (text: string) => void;
  onOpenEvolution: () => void;
  onOpenVision: () => void;
  onOpenMindstream: () => void;
  onOpenMemories: () => void;
  onOpenSettings: () => void;
}

export const FeaturesHubView: React.FC<FeaturesHubViewProps> = ({
  emotion,
  lastSentiment,
  activeAvatarForm,
  memoryCount,
  voiceName,
  onSelectEmotion,
  onQuickPrompt,
  onOpenEvolution,
  onOpenVision,
  onOpenMindstream,
  onOpenMemories,
  onOpenSettings,
}) => {
  const formMeta = AVATAR_FORMS.find((f) => f.id === activeAvatarForm) || AVATAR_FORMS[0];

  const vibeOptions: Array<{
    id: RobotEmotion;
    label: string;
    sublabel: string;
    icon: string;
    color: string;
    borderColor: string;
    bgActive: string;
  }> = [
    {
      id: 'happy',
      label: 'Masaya',
      sublabel: 'Good vibes & energetic cheer',
      icon: '😄',
      color: 'text-cyan-300',
      borderColor: 'border-cyan-500/50',
      bgActive: 'bg-cyan-950/70 border-cyan-400 ring-1 ring-cyan-400/50',
    },
    {
      id: 'empathic',
      label: 'Malasakit',
      sublabel: 'Warm comfort & deep listening',
      icon: '💛',
      color: 'text-amber-300',
      borderColor: 'border-amber-500/50',
      bgActive: 'bg-amber-950/70 border-amber-400 ring-1 ring-amber-400/50',
    },
    {
      id: 'playful',
      label: 'Kulitan',
      sublabel: 'Banter, laughs & witty jokes',
      icon: '✨',
      color: 'text-pink-300',
      borderColor: 'border-pink-500/50',
      bgActive: 'bg-pink-950/70 border-pink-400 ring-1 ring-pink-400/50',
    },
    {
      id: 'soothing',
      label: 'Pampa-kalma',
      sublabel: 'Peaceful, grounding reassurance',
      icon: '🌿',
      color: 'text-emerald-300',
      borderColor: 'border-emerald-500/50',
      bgActive: 'bg-emerald-950/70 border-emerald-400 ring-1 ring-emerald-400/50',
    },
    {
      id: 'thinking',
      label: 'Pagsusuri',
      sublabel: 'Analytical & deep reflection',
      icon: '🧠',
      color: 'text-purple-300',
      borderColor: 'border-purple-500/50',
      bgActive: 'bg-purple-950/70 border-purple-400 ring-1 ring-purple-400/50',
    },
  ];

  const quickPrompts = [
    { text: 'Boss, medyo pagod at stressed ako ngayon sa trabaho...', label: '💛 Pagod sa trabaho', icon: Coffee },
    { text: 'Marvy, magbiro ka nga ng nakakatawang Pinoy joke tol!', label: '😄 Magbiro ka nga!', icon: Sparkles },
    { text: 'Kumusta ang araw mo, Marvy? Kwentuhan mo naman ako.', label: '⚡ Kumusta araw mo?', icon: MessageSquare },
    { text: 'Ano-ano na ba ang mga natatandaan mo tungkol sa akin?', label: '🧠 Mga naalala mo', icon: Brain },
    { text: 'Sobrang traffic at hassle ng biyahe kanina sa EDSA.', label: '🚗 Trapik sa biyahe', icon: Car },
    { text: 'May magandang balita ako sa\'yo Marvy, nakapasa ako!', label: '🎉 May good news ako!', icon: Gift },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto p-4 sm:p-6 space-y-6 pb-24 overflow-y-auto">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-cyan-950/40 via-slate-900 to-purple-950/40 border border-slate-800 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
              Control Hub
            </span>
            <span className="text-xs text-slate-400">• Mga Katangian at AI Sensors</span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
            AI Emosyon, Kuwentuhan at mga Sensor ni Marvy
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Dito nakalipon ang lahat ng advanced features para malinis at hindi masikip ang screen ng 3D robot.
          </p>
        </div>

        <button
          onClick={onOpenSettings}
          className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 hover:text-white flex items-center gap-2 transition active:scale-95 shrink-0"
        >
          <Settings className="w-4 h-4 text-cyan-400" />
          <span>Voice & AI Settings</span>
        </button>
      </div>

      {/* 1. Real-time Empathy AI & Emotion Monitor */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Real-Time Empathy & Sentiment Radar
            </h3>
          </div>
          {lastSentiment && (
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-500/30">
              {lastSentiment.confidence}% Match
            </span>
          )}
        </div>

        {lastSentiment ? (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Kasalukuyang Mood
              </span>
              <div className="text-sm font-bold text-amber-300 flex items-center gap-2">
                <span>💛</span>
                <span>{lastSentiment.moodLabel}</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                {lastSentiment.summary || 'Kasalukuyang sinusuri ang tono ng boses'}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Marvy Empathy Tone
              </span>
              <div className="text-sm font-bold text-cyan-300">
                {lastSentiment.empathyTone}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                Awtomatikong nag-a-adjust ang boses at kislap ng mata.
              </span>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Valence / Enerhiya
              </span>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-cyan-400 transition-all duration-500"
                    style={{
                      width: `${Math.round(((lastSentiment.valence + 1) / 2) * 100)}%`,
                    }}
                  />
                </div>
                <span className="text-xs font-mono text-cyan-300">
                  {Math.round(((lastSentiment.valence + 1) / 2) * 100)}%
                </span>
              </div>
              <span className="text-[10px] text-slate-500 mt-1">
                Arousal: {lastSentiment.arousal.toUpperCase()}
              </span>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-slate-950/50 border border-slate-800/80 text-center text-xs text-slate-400">
            Nakahandang makinig si Marvy. Magsalita o mag-tap ng prompt para simulan ang real-time emotional analysis.
          </div>
        )}
      </div>

      {/* 2. Interactive Robot Vibe & Mood Selector */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              I-set ang Timpla at Emosyon ni Marvy
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            I-tap para agad magbago ang ekspresyon at tono ng boses
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {vibeOptions.map((v) => {
            const isCur = emotion === v.id;
            return (
              <button
                key={v.id}
                onClick={() => {
                  sfx.playClick();
                  onSelectEmotion(v.id);
                }}
                className={`p-3 rounded-2xl border text-left transition-all active:scale-95 flex flex-col justify-between gap-2 ${
                  isCur
                    ? `${v.bgActive} shadow-lg shadow-cyan-950/40`
                    : 'bg-slate-950/60 hover:bg-slate-800/60 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xl">{v.icon}</span>
                  {isCur && (
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  )}
                </div>
                <div>
                  <div className={`text-xs font-bold ${isCur ? v.color : 'text-slate-200'}`}>
                    {v.label}
                  </div>
                  <div className="text-[10px] text-slate-400 leading-tight mt-0.5">
                    {v.sublabel}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Quick Filipino Kuwentuhan Prompts */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Mabilisang Kuwentuhan at Banat
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">1-Tap Voice Test</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {quickPrompts.map((q, idx) => {
            const Icon = q.icon;
            return (
              <button
                key={idx}
                onClick={() => {
                  sfx.playClick();
                  onQuickPrompt(q.text);
                }}
                className="p-3 rounded-2xl bg-slate-950/70 hover:bg-slate-850 hover:border-cyan-500/40 border border-slate-800 text-left transition-all active:scale-95 flex items-center justify-between group shadow-sm"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-slate-900 group-hover:bg-cyan-950/60 border border-slate-700/80 group-hover:border-cyan-500/40 flex items-center justify-center shrink-0 transition">
                    <Icon className="w-4 h-4 text-slate-400 group-hover:text-cyan-300" />
                  </div>
                  <div className="truncate">
                    <div className="text-xs font-bold text-slate-200 group-hover:text-white">
                      {q.label}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      "{q.text}"
                    </div>
                  </div>
                </div>
                <span className="text-[10px] text-cyan-400 font-bold shrink-0 ml-2 opacity-0 group-hover:opacity-100 transition">
                  Sabihin →
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. Neural & Sensory Modules Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Optical Eyes Camera Card */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-lg flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center">
                <Eye className="w-4 h-4 text-cyan-400" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Neural Optical Eyes</h4>
                <p className="text-[10px] text-slate-400">Multimodal Camera & Litrato Scan</p>
              </div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30">
              Live Ready
            </span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            Ipakita ang iyong paligid, pagkain, dokumento, o sarili sa camera ni Marvy para makita at makapagbigay siya ng Pinoy komento.
          </p>
          <button
            onClick={onOpenVision}
            className="w-full py-2 px-3 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/40 text-cyan-300 hover:text-white text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Buksan ang Optical Camera</span>
          </button>
        </div>

        {/* Subconscious Mindstream Card */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-lg flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-fuchsia-950/80 border border-fuchsia-500/40 flex items-center justify-center">
                <Brain className="w-4 h-4 text-fuchsia-400" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Subconscious Mindstream</h4>
                <p className="text-[10px] text-slate-400">Transformer Reasoning Stream</p>
              </div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-fuchsia-950 text-fuchsia-300 border border-fuchsia-500/30">
              Active
            </span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            Silipin ang internal thought process at emotional reasoning layers ni Marvy habang bumubuo siya ng sagot sa iyo.
          </p>
          <button
            onClick={onOpenMindstream}
            className="w-full py-2 px-3 rounded-xl bg-fuchsia-600/20 hover:bg-fuchsia-600/30 border border-fuchsia-500/40 text-fuchsia-300 hover:text-white text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <Brain className="w-3.5 h-3.5" />
            <span>Tingnan ang Kaisipan ni Marvy</span>
          </button>
        </div>

        {/* Memory Vault Card */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-lg flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-950/80 border border-purple-500/40 flex items-center justify-center">
                <Heart className="w-4 h-4 text-purple-400" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Memory Vault (Mga Alaala)</h4>
                <p className="text-[10px] text-slate-400">{memoryCount} natatandaang detalye</p>
              </div>
            </div>
            <span className="font-mono text-xs font-bold px-2 py-0.5 rounded-full bg-purple-950 text-purple-300 border border-purple-500/30">
              {memoryCount} Alaala
            </span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            Awtomatikong natatandaan ni Marvy ang mga paborito, pamilya, trabaho, at hilig mo para mas personal ang usapan.
          </p>
          <button
            onClick={onOpenMemories}
            className="w-full py-2 px-3 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 hover:text-white text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <Brain className="w-3.5 h-3.5" />
            <span>Pamahalaan ang Memory Bank</span>
          </button>
        </div>

        {/* Evolution Matrix Card */}
        <div className="p-4 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-lg flex flex-col justify-between gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center">
                <Zap className="w-4 h-4 text-cyan-400" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Evolution Matrix (Anyo)</h4>
                <p className="text-[10px] text-slate-400">{formMeta.name}</p>
              </div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 border border-slate-700">
              {formMeta.badge}
            </span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            Mula sa Bilog na 3D Cyber Robot hanggang sa Quantum Singularity Core, Bionic Human, at Mecha Titan.
          </p>
          <button
            onClick={onOpenEvolution}
            className="w-full py-2 px-3 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/40 text-cyan-300 hover:text-white text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Baguhin ang Anyo ni Marvy</span>
          </button>
        </div>
      </div>
    </div>
  );
};
