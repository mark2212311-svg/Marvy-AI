import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, Upload, Sparkles, RefreshCw, Eye, AlertCircle, CheckCircle2 } from 'lucide-react';
import { sfx } from '../utils/soundEffects';
import { sendVisionAnalysis, VisionResponsePayload } from '../utils/apiClient';

interface NeuralVisionModalProps {
  isOpen: boolean;
  userCallsign: string;
  selectedGender: 'female' | 'male';
  customGeminiKey?: string;
  onClose: () => void;
  onVisionResponse: (payload: VisionResponsePayload, capturedImage?: string) => void;
  onOpenSettings?: () => void;
}

export const NeuralVisionModal: React.FC<NeuralVisionModalProps> = ({
  isOpen,
  userCallsign,
  selectedGender,
  customGeminiKey,
  onClose,
  onVisionResponse,
  onOpenSettings,
}) => {
  const [streamActive, setStreamActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState<string>('Ano ang nakikita mo, Boss?');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<VisionResponsePayload | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // Quick preset questions
  const quickPrompts = [
    'Ano ang nakikita mo, Marvy?',
    'Kamusta ang porma / suot ko?',
    'Suriin mo kung anong gamit o bagay ito',
    'Basahin mo ang facial expression ko',
  ];

  // Start Camera
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });

      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setStreamActive(true);
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError('Hindi mabuksan ang camera. Maaaring i-upload ang litrato o i-allow ang camera permission.');
      setStreamActive(false);
    }
  };

  // Stop Camera
  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setStreamActive(false);
  };

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
      setSelectedImage(null);
      setScanResult(null);
      setIsScanning(false);
    }
    return () => {
      stopCamera();
    };
  }, [isOpen]);

  // Capture frame from video feed
  const captureFrame = (): string | null => {
    if (!videoRef.current) return null;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
  };

  // Handle image upload from file picker or drag-drop
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setScanResult(null);
      setSelectedImage(result);
      stopCamera();
    };
    reader.readAsDataURL(file);
    // Reset so picking the same file again still fires onChange.
    e.target.value = '';
  };

  // Perform Vision Scan with Gemini
  const handlePerformScan = async () => {
    let imageToAnalyze = selectedImage;
    if (!imageToAnalyze && streamActive) {
      imageToAnalyze = captureFrame();
      if (imageToAnalyze) {
        setSelectedImage(imageToAnalyze);
        stopCamera();
      }
    }

    if (!imageToAnalyze) {
      alert('Magbukas ng camera o mag-upload ng litrato muna.');
      return;
    }

    // Use the real MIME type from the data URL (PNG uploads were being labeled as JPEG).
    const mimeMatch = /^data:(image\/[a-zA-Z0-9.+-]+);base64,/.exec(imageToAnalyze);
    const mimeType = mimeMatch ? mimeMatch[1] : 'image/jpeg';

    setIsScanning(true);
    sfx.playVisionScan();

    try {
      const response = await sendVisionAnalysis({
        imageBase64: imageToAnalyze,
        mimeType,
        prompt: customPrompt,
        voiceGender: selectedGender,
        userCallsign,
        customGeminiKey,
      });

      setScanResult(response);
      onVisionResponse(response, imageToAnalyze);
    } catch (err: any) {
      console.error('Vision scan error:', err);
      alert(`Nabigo ang scan: ${err.message || 'Subukan muli.'}`);
    } finally {
      setIsScanning(false);
    }
  };

  const handleRetake = () => {
    setSelectedImage(null);
    setScanResult(null);
    startCamera();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border border-cyan-500/40 rounded-2xl shadow-2xl shadow-cyan-950/60 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-cyan-500/20 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
              <Eye className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  Neural Optical Eyes
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Multimodal Gemini 3.8
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Panoorin o ipasuri kay Marvy ang nakikita sa camera o litrato.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewport & Camera Feed */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          <div className="relative w-full aspect-video sm:aspect-[4/3] bg-slate-950 rounded-xl overflow-hidden border border-cyan-500/30 flex items-center justify-center shadow-inner group">
            {/* Live Video Feed */}
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover transition-opacity duration-300 ${
                streamActive && !selectedImage ? 'opacity-100' : 'opacity-0 absolute'
              }`}
            />

            {/* Frozen / Uploaded Image View */}
            {selectedImage && (
              <img
                src={selectedImage}
                alt="Captured scan preview"
                className="w-full h-full object-contain bg-black/90"
              />
            )}

            {/* Error or No Camera Message */}
            {!streamActive && !selectedImage && (
              <div className="p-6 text-center space-y-3">
                <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
                <p className="text-xs text-slate-300 max-w-xs mx-auto">
                  {cameraError || 'Naka-off ang camera. Maaari mong simulan ang camera o mag-upload ng litrato.'}
                </p>
                <button
                  type="button"
                  onClick={startCamera}
                  className="px-3.5 py-1.5 rounded-lg bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 text-xs font-medium hover:bg-cyan-500/30 transition-colors inline-flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" /> Subukang buksan muli
                </button>
              </div>
            )}

            {/* Futuristic Optical HUD Overlay */}
            <div className="absolute inset-0 pointer-events-none p-3 flex flex-col justify-between">
              {/* Top HUD stats */}
              <div className="flex items-center justify-between text-[10px] font-mono text-cyan-400/80 bg-slate-950/60 backdrop-blur-xs px-2 py-1 rounded border border-cyan-500/20">
                <span>[OPTICAL_SENSOR: ACTIVE]</span>
                <span>RES: 1080P_QUANTUM</span>
              </div>

              {/* Target Crosshairs */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-24 h-24 border border-cyan-400/40 rounded-lg relative">
                  <div className="absolute -top-1 -left-1 w-2 h-2 border-t-2 border-l-2 border-cyan-400" />
                  <div className="absolute -top-1 -right-1 w-2 h-2 border-t-2 border-r-2 border-cyan-400" />
                  <div className="absolute -bottom-1 -left-1 w-2 h-2 border-b-2 border-l-2 border-cyan-400" />
                  <div className="absolute -bottom-1 -right-1 w-2 h-2 border-b-2 border-r-2 border-cyan-400" />
                </div>
              </div>

              {/* Scanline Animation while Scanning */}
              {isScanning && (
                <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#06b6d4] animate-bounce" />
              )}
            </div>
          </div>

          {/* Quick Prompts */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-medium text-slate-400">Pumili o Magtanong kay Marvy:</span>
            <div className="flex flex-wrap gap-1.5">
              {quickPrompts.map((p, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setCustomPrompt(p)}
                  className={`text-xs px-2.5 py-1 rounded-lg border transition-colors ${
                    customPrompt === p
                      ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                      : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Input */}
          <input
            type="text"
            value={customPrompt}
            onChange={(e) => setCustomPrompt(e.target.value)}
            placeholder="I-type kung ano ang nais mong suriin ni Marvy..."
            className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-400 text-slate-200 text-xs sm:text-sm placeholder-slate-500 focus:outline-none"
          />

          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />

          {/* Scan Results Display */}
          {scanResult && (
            <div
              className={`p-3.5 rounded-xl border space-y-2 animate-fade-in ${
                scanResult.isQuotaLimit
                  ? 'bg-amber-950/40 border-amber-500/50 text-amber-200'
                  : 'bg-cyan-950/40 border-cyan-500/30'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-semibold gap-2">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className={`w-4 h-4 ${scanResult.isQuotaLimit ? 'text-amber-400' : 'text-cyan-400'}`} />
                  <span className={scanResult.isQuotaLimit ? 'text-amber-300' : 'text-cyan-300'}>
                    {scanResult.isQuotaLimit ? 'Paalala sa Quota:' : 'Sagot ni Marvy (Sinasalita na ngayon...):'}
                  </span>
                </div>
                {scanResult.isQuotaLimit && onOpenSettings && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenSettings();
                    }}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition shrink-0"
                  >
                    Buksan ang Settings ⚙️
                  </button>
                )}
              </div>
              <p className="text-sm text-slate-100 italic">"{scanResult.reply}"</p>
              <div className={`text-[11px] font-mono pt-1 border-t ${scanResult.isQuotaLimit ? 'text-amber-300/90 border-amber-500/30' : 'text-cyan-400/80 border-cyan-500/20'}`}>
                🔍 {scanResult.opticalBreakdown}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2">
            {selectedImage ? (
              <button
                type="button"
                onClick={handleRetake}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 inline-flex items-center gap-1.5 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Ulitin / Live Camera
              </button>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 inline-flex items-center gap-1.5 transition-colors"
              >
                <Upload className="w-3.5 h-3.5" /> Mag-upload ng Litrato
              </button>
            )}
          </div>

          <button
            type="button"
            disabled={isScanning}
            onClick={handlePerformScan}
            className={`px-5 py-2.5 rounded-xl font-semibold text-xs sm:text-sm inline-flex items-center gap-2 transition-all ${
              isScanning
                ? 'bg-cyan-500/50 text-slate-950 cursor-not-allowed'
                : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-lg shadow-cyan-500/30'
            }`}
          >
            {isScanning ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" /> Sinusuri ang Optical Data...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" /> I-scan at Ikuwento kay Marvy
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
