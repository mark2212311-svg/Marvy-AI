import React, { useState, useEffect } from 'react';
import { X, Activity, Brain, Radio, Zap, Heart, Database, Gauge } from 'lucide-react';
import { SentimentAnalysis, RobotEmotion, AvatarFormId, AVATAR_FORMS } from '../utils/conversation';

interface NeuralMindstreamModalProps {
  isOpen: boolean;
  activeForm: AvatarFormId;
  lastSentiment?: SentimentAnalysis;
  emotion: RobotEmotion;
  memoryCount: number;
  onClose: () => void;
}

export const NeuralMindstreamModal: React.FC<NeuralMindstreamModalProps> = ({
  isOpen,
  activeForm,
  lastSentiment,
  emotion,
  memoryCount,
  onClose,
}) => {
  const [synapsesHz, setSynapsesHz] = useState<number>(4.82);
  const [resonancePercent, setResonancePercent] = useState<number>(94);
  const [activeThoughts, setActiveThoughts] = useState<string[]>([
    'Subconscious quantum core running nominal at 4.8 GHz',
    'Real-time Filipino colloquial Taglish filter synchronized',
    'Empathy tone calibrated: Warm caring companion',
    'Optical & acoustic sensory buffers cleared',
  ]);

  const activeFormMeta = AVATAR_FORMS.find((f) => f.id === activeForm) || AVATAR_FORMS[0];

  useEffect(() => {
    if (!isOpen) return;

    const interval = setInterval(() => {
      setSynapsesHz(+(4.8 + Math.random() * 0.4).toFixed(2));
      setResonancePercent(Math.floor(92 + Math.random() * 7));

      const possibleThoughts = [
        'Analyzing Boss emotional inflection in real-time...',
        'Matching Pinoy humor & playful banter index...',
        'Retrieving relevant episodic memory nodes...',
        'Quantum coherence steady across tachyon gyroscopes...',
        'Synthesizing procedural audio harmonic overtone...',
        'Micro-expression facial physics rendered at 60 FPS...',
      ];

      const newThought = possibleThoughts[Math.floor(Math.random() * possibleThoughts.length)];
      setActiveThoughts((prev) => [newThought, ...prev.slice(0, 4)]);
    }, 2800);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-xl bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border border-cyan-500/30 rounded-2xl shadow-2xl shadow-cyan-950/50 flex flex-col max-h-[90vh] overflow-hidden font-mono">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-cyan-500/20 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-400">
              <Brain className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-tight font-sans">
                  Kaisipan ni Marvy (Neural HUD)
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Live Telemetry
                </span>
              </div>
              <p className="text-xs text-slate-400 font-sans">
                Real-time stream ng subconscious reasoning at neural synapses.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Telemetry Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs">
          {/* Top Quick Telemetry Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                <Zap className="w-3 h-3 text-cyan-400" /> Clock Speed
              </span>
              <span className="text-sm sm:text-base font-bold text-cyan-400 mt-1">
                {synapsesHz} GHz
              </span>
              <span className="text-[9px] text-slate-500">Quantum Cycle</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                <Heart className="w-3 h-3 text-fuchsia-400" /> Resonance
              </span>
              <span className="text-sm sm:text-base font-bold text-fuchsia-400 mt-1">
                {resonancePercent}%
              </span>
              <span className="text-[9px] text-slate-500">Empathy Index</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                <Database className="w-3 h-3 text-amber-400" /> Memories
              </span>
              <span className="text-sm sm:text-base font-bold text-amber-400 mt-1">
                {memoryCount} Vaults
              </span>
              <span className="text-[9px] text-slate-500">Long-term Nodes</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                <Radio className="w-3 h-3 text-emerald-400" /> Form State
              </span>
              <span className="text-xs sm:text-sm font-bold text-emerald-400 mt-1 truncate">
                {activeFormMeta.name.split(' ')[0]}
              </span>
              <span className="text-[9px] text-slate-500">{activeFormMeta.category.split(' ')[0]}</span>
            </div>
          </div>

          {/* Subconscious Stream */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-cyan-500/30 space-y-2">
            <div className="flex items-center justify-between text-cyan-400 text-[11px] font-semibold border-b border-cyan-500/20 pb-1.5">
              <span className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 animate-pulse" /> Live Subconscious Mindstream:
              </span>
              <span className="text-[9px] text-slate-400">FPS: 60 | LATENCY: &lt;1s</span>
            </div>
            <div className="space-y-1.5 pt-1">
              {activeThoughts.map((t, idx) => (
                <div key={idx} className="flex items-start gap-2 text-[11px] text-slate-300">
                  <span className="text-cyan-500">&gt;</span>
                  <span className="leading-relaxed">{t}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Sentiment & Empathy Status */}
          <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 font-sans">
            <h3 className="text-xs font-semibold text-slate-300 font-mono flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-cyan-400" /> Empathy Resonance Vectors
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-mono uppercase">Detected User Mood</span>
                <p className="font-semibold text-cyan-300">
                  {lastSentiment?.moodLabel || 'Chill / Kalmado'}
                </p>
                <p className="text-[11px] text-slate-400">
                  {lastSentiment?.summary || 'Komportableng pakikipag-usap at maayos na daloy.'}
                </p>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-mono uppercase">Empathy Tone Output</span>
                <p className="font-semibold text-fuchsia-300">
                  {lastSentiment?.empathyTone || 'Warm Caring Presence'}
                </p>
                <p className="text-[11px] text-slate-400">
                  Confidence: {lastSentiment?.confidence || 85}% • Emotion: {emotion}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between text-xs text-slate-400">
          <span>Neural Model: Gemini 3.8 Flash Engine</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold font-sans transition-colors"
          >
            Isara
          </button>
        </div>
      </div>
    </div>
  );
};
