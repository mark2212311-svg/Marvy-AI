import React, { useState, useRef, useEffect } from 'react';
import { Send, Volume2, X, Sparkles, User, Bot, Heart, MessageSquare } from 'lucide-react';
import { ChatMessage } from '../utils/conversation';
import { sfx } from '../utils/soundEffects';

interface TranscriptViewProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onPlayMessageAudio: (message: ChatMessage) => void;
  onClose: () => void;
  isThinking: boolean;
}

export const TranscriptView: React.FC<TranscriptViewProps> = ({
  messages,
  onSendMessage,
  onPlayMessageAudio,
  onClose,
  isThinking,
}) => {
  const [inputText, setInputText] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isThinking) return;
    sfx.playClick();
    onSendMessage(inputText);
    setInputText('');
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0d16] text-slate-100">
      {/* Top Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-[#07090e]">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-bold text-white">Transcript & Kuwentuhan</h2>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs sm:text-sm">
            Wala pang usapan. Pindutin ang mikropono o mag-type sa ibaba para magsimula ng kuwentuhan kay Marvy!
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-1 animate-in fade-in duration-200`}
              >
                <div className="flex items-center gap-1.5 text-[10px] text-slate-400 px-1">
                  {isUser ? (
                    <>
                      <span>Ikaw</span>
                      <span>•</span>
                      <span>{formatTime(msg.timestamp)}</span>
                    </>
                  ) : (
                    <>
                      <span className="text-cyan-400 font-semibold">Marvy AI</span>
                      {msg.sentiment && (
                        <span className="px-1.5 py-0.2 rounded bg-amber-950/60 text-amber-300 border border-amber-500/20 text-[9px] font-medium">
                          {msg.sentiment.moodLabel}
                        </span>
                      )}
                      <span>•</span>
                      <span>{formatTime(msg.timestamp)}</span>
                    </>
                  )}
                </div>

                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-cyan-600 text-slate-950 font-medium rounded-tr-none'
                      : 'bg-slate-900 border border-slate-800/80 text-slate-100 rounded-tl-none shadow-md'
                  }`}
                >
                  <p>{msg.text}</p>

                  {!isUser && (
                    <div className="mt-2 pt-2 border-t border-slate-800/60 flex items-center justify-between">
                      <button
                        onClick={() => onPlayMessageAudio(msg)}
                        className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition"
                        title="I-play ang audio ng sagot na ito"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Pakinggan Muli</span>
                      </button>

                      {msg.sentiment?.empathyTone && (
                        <span className="text-[10px] text-slate-400 italic">
                          Tone: {msg.sentiment.empathyTone}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}

        {isThinking && (
          <div className="flex items-center gap-2 text-xs text-purple-400 px-2 py-1 animate-pulse">
            <Sparkles className="w-3.5 h-3.5 animate-spin" />
            <span>Nag-iisip si Marvy at sinusuri ang emosyon...</span>
          </div>
        )}

        <div ref={endRef} />
      </div>

      {/* Bottom Text Input Box */}
      <form onSubmit={handleSubmit} className="p-3 border-t border-slate-800/80 bg-[#07090e]">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isThinking}
            placeholder="Mag-type ng mensahe kay Marvy..."
            className="flex-1 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || isThinking}
            className={`p-2.5 rounded-xl font-bold transition active:scale-95 ${
              inputText.trim() && !isThinking
                ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
