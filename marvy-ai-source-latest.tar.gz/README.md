# PROJECT MARVY — Humanlike Filipino Voice & Emotional Companion AI

Ang **MARVY AI** ay isang intelligent, adaptive, witty, at natural na Filipino voice-only AI companion na may real-time deep emotional intelligence, sentiment tracking, at long-term memory.

---

## 🌟 Mga Pangunahing Katangian (Features)

1. **Humanlike Pinoy Taglish Voice Companion**:
   - Nagsasalita sa natural na modernong Taglish na parang tunay na tropa.
   - Tinatawag ang user na "Boss" (o nako-customize na callsign).
   - Mabilis ang sagot, swak sa phone call (1-3 maiikling pangungusap), at walang robotic script.

2. **Real-Time Sentiment Analysis & Emotional Intelligence (Deep Learning)**:
   - Sinusuri ang emosyon ng user sa bawat salita (*Malungkot, Stressed/Pagod, Masaya, Mapagbiro, Inis, Nangungulila, Chill*).
   - Dynamic tone adjustment: kusang nag-a-adjust ang boses at empatiya ni Marvy (e.g. *Calming Reassurance*, *Warm Caring Presence*, *Playful Banter*).

3. **Long-Term Memory Tracking ("Kaisipan ni Marvy")**:
   - Awtomatikong nagtatala ng mga detalye tungkol sa user (trabaho, paborito, exam, pinagdadaanan).
   - May nakalaang Memory Vault UI at Mood Timeline history.

4. **Interactive 3D Procedural Cyber Robot Avatar**:
   - May dynamic visor display na nagpapakita ng emosyon (ngiti, kindat, caring eyes, wave, data halo, radar).
   - Sumusunod ang tingin sa mouse o daliri; may physics spring bounce at sfx kapag tinatapik.

5. **Cartesia Sonic 3.6 Voice (Default)**:
   - Ang boses ni Marvy ay gamit ang Cartesia Sonic 3.6 gamit ang default voice ID `2e488ee5-a721-4466-b0b7-7e586e943ed3`.
   - Puwedeng magpalit ng ibang Cartesia Voice ID sa Settings > Boses.
   - Ang API key ay nasa server lamang (`CARTESIA_API_KEY`) at hindi napupunta sa browser.

6. **Libreng Google Gemini Model**:
   - Pinapagana ng `gemini-3.1-flash-lite` para sa ultra-fast low latency (<1s), `gemini-3.8-flash`, at `gemini-4-argon`.

---

## 🚀 Paano Patakbuhin (Quick Start)

### 1. I-install ang Dependencies:
```bash
npm install
```

### 2. Environment Setup:
Gumawa ng `.env` file (o gamitin ang `.env.example`):
```env
GEMINI_API_KEY="iyong_gemini_api_key"
CARTESIA_API_KEY="iyong_cartesia_api_key"
PORT=3000
```
Kailangan ang `CARTESIA_API_KEY` para magsalita si Marvy. Makukuha ito sa https://play.cartesia.ai.

### 3. Simulan ang Development Server:
```bash
npm run dev
```
Buksan ang browser sa `http://localhost:3000`.

### 4. Build para sa Production:
```bash
npm run build
npm start
```
