import type { IncomingMessage, ServerResponse } from 'http';
import fs from 'fs';
import nodePath from 'path';
import { GoogleGenAI } from '@google/genai';
import {
  buildMarvySystemInstruction,
  sanitizeTextForSpeech,
  quickDetectSentiment,
  mapMoodToRobotEmotion,
  RobotEmotion,
  UserMood,
} from '../src/utils/conversation';
import {
  DEFAULT_CARTESIA_VOICE_ID,
  CARTESIA_MODEL_ID,
  CARTESIA_API_VERSION,
  CARTESIA_MAX_TEXT_CHARS,
  isValidCartesiaVoiceId,
} from '../src/utils/cartesia';

// Helper to parse JSON body from incoming HTTP request stream
function parseJsonBody(req: IncomingMessage): Promise<any> {
  if ((req as any).body !== undefined && (req as any).body !== null && typeof (req as any).body === 'object') {
    return Promise.resolve((req as any).body);
  }
  if (req.readableEnded || (req as any).complete) {
    return Promise.resolve({});
  }
  return new Promise((resolve, reject) => {

    const chunks: Buffer[] = [];
    req.on('data', (chunk) => {
      chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk);
    });

    req.on('end', () => {
      const rawData = Buffer.concat(chunks).toString('utf8');
      if (!rawData.trim()) {
        return resolve({});
      }
      try {
        const parsed = JSON.parse(rawData);
        resolve(parsed);
      } catch {
        reject(new Error('Invalid JSON payload'));
      }
    });

    req.on('error', (err) => {
      reject(err);
    });

    req.resume();
  });
}

// Helper to send JSON response
function sendJson(res: ServerResponse, statusCode: number, data: any) {
  const jsonStr = JSON.stringify(data);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(jsonStr),
    'Access-Control-Allow-Origin': '*',
  });
  res.end(jsonStr);
}

/** Bump this string on every deploy. Shown in /api/status and at startup so you can tell which build is live. */
export const SERVER_BUILD = 'cartesia-only-2026-10-30-logs';

/** Masks a secret for logs: length + last 4 chars only. */
function maskSecret(value: string): string {
  if (!value) return '(empty)';
  return `len=${value.length} ...${value.slice(-4)}`;
}

/** Cartesia key from server env. Ignores the unedited .env.example placeholder. */
function getCartesiaApiKey(): string {
  const key = (process.env.CARTESIA_API_KEY || '').trim();
  if (!key || key === 'your_cartesia_api_key_here' || key === 'MY_CARTESIA_API_KEY') return '';
  return key;
}

function getCartesiaModelId(): string {
  return (process.env.CARTESIA_MODEL_ID || '').trim() || CARTESIA_MODEL_ID;
}

/**
 * Main API Handler: /api/status, /api/chat, /api/vision/analyze, /api/cartesia/tts, /api/sentiment/analyze, /api/download/source
 */
export async function apiHandler(req: IncomingMessage, res: ServerResponse, next?: () => void) {
  const url = req.url || '';
  const method = req.method?.toUpperCase();

  // Handle CORS Preflight
  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, x-gemini-api-key',
    });
    return res.end();
  }

  // Normalize path (handle both /api/... and stripped prefix /...)
  const path = url.split('?')[0].replace(/^\/api/, '');

  // 1. GET /status
  if (path === '/status' && method === 'GET') {
    return sendJson(res, 200, {
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
      buildVersion: SERVER_BUILD,
      cartesiaConfigured: Boolean(getCartesiaApiKey()),
      cartesiaModel: getCartesiaModelId(),
      defaultVoiceId: DEFAULT_CARTESIA_VOICE_ID,
      models: [
        { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite (Lowest Latency / Default)', speed: 'Ultra-fast (<1s)', description: 'Pinakamabilis na tugon. Zero lag para sa real-time mobile voice call at Android APK.' },
        { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash (Balanced & High Intelligence)', speed: 'Fast (~1.2s)', description: 'Pinakamatalino at natural sa Pinoy Taglish kuwentuhan at emosyon.' },
        { id: 'gemini-4-argon', name: 'Gemini 4 Argon (Deep Empathy & Reasoning)', speed: 'Deep (~2.5s)', description: 'Malalim na pang-unawa sa kumplikadong emosyon at seryosong payo sa buhay.' },
        { id: 'gemini-flash-latest', name: 'Gemini Flash Latest (Continuous Updates)', speed: 'Fast (~1.1s)', description: 'Pinakabagong build ng Google Gemini na may updated general knowledge.' },
      ],
      timestamp: Date.now(),
    });
  }

  // 3. POST /chat (AI Voice Response + Real-time Transformer Emotional Intelligence + Memory Extraction)
  if (path === '/chat' && method === 'POST') {
    let body: any = {};
    try {
      body = await parseJsonBody(req);
    } catch {
      return sendJson(res, 400, { error: 'Invalid JSON request payload' });
    }

    const {
      message,
      history = [],
      voiceGender = 'male',
      userCallsign = 'Boss',
      memoriesContext = '',
      aiModel = 'gemini-3.1-flash-lite',
      activeAvatarForm = 'quantum_core',
      customApiKey,
    } = body;

    if (!message || typeof message !== 'string') {
      return sendJson(res, 400, { error: 'Message is required' });
    }

    const effectiveApiKey = customApiKey || (req.headers['x-gemini-api-key'] as string) || process.env.GEMINI_API_KEY;
    if (!effectiveApiKey) {
      return sendJson(res, 500, {
        error: 'GEMINI_API_KEY is missing in server environment. Please attach a Gemini API key or enter one in Settings.',
      });
    }

    try {
      const ai = new GoogleGenAI({
        apiKey: effectiveApiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build-marvy',
          },
        },
      });

      // Quick fallback sentiment
      const fallbackSentiment = quickDetectSentiment(message);

      const systemInstruction = `${buildMarvySystemInstruction(
        voiceGender,
        userCallsign,
        memoriesContext,
        fallbackSentiment.primaryMood,
        activeAvatarForm
      )}

OUTPUT FORMAT INSTRUCTION:
You MUST respond with valid JSON containing the spoken response, deep emotional sentiment analysis, and any key memory extracted from the user's message:
{
  "reply": "Your natural Pinoy Taglish speech response. Remember: strictly NO emojis, NO markdown formatting, NO asterisks like *tawa*, 1-3 spoken phone sentences.",
  "sentiment": {
    "primaryMood": "malungkot" | "kabado" | "masaya" | "nangungulila" | "inis" | "mapagbiro" | "nagtatanong" | "chill",
    "moodLabel": "e.g., Malungkot / May Dinaramdam o Masaya / Tropa Vibes",
    "valence": -1.0 to 1.0,
    "arousal": "low" | "medium" | "high",
    "empathyTone": "Tone description (e.g., Warm Caring Presence, Playful Banter, Calming Reassurance)",
    "confidence": 0 to 100,
    "summary": "Short 1-sentence note on why this emotion was detected"
  },
  "robotEmotion": "happy" | "playful" | "empathic" | "listening" | "thinking" | "soothing" | "neutral" | "confused",
  "newMemory": {
    "key": "Title of memory (e.g., Trabaho / Exam / Paboritong Ulam / Alagang Hayop / Problema)",
    "value": "Brief fact about the user to remember",
    "category": "personal" | "mood" | "preference" | "milestone"
  } // Set to null if the user just said general greetings or no personal facts were shared
}`;

      const formattedContents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

      // Include recent turns for fast low-latency context
      const recentHistory = (history || []).slice(-4);
      for (const turn of recentHistory) {
        if (turn.text && turn.role) {
          formattedContents.push({
            role: turn.role === 'user' ? 'user' : 'model',
            parts: [{ text: turn.text }],
          });
        }
      }

      formattedContents.push({
        role: 'user',
        parts: [{ text: message }],
      });

      // Select valid model: default gemini-3.1-flash-lite for ultra-fast voice responses
      const validModel = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-4-argon', 'gemini-flash-latest'].includes(aiModel)
        ? aiModel
        : 'gemini-3.1-flash-lite';

      const candidateModels = [
        validModel,
        'gemini-3.1-flash-lite',
        'gemini-flash-latest',
        'gemini-3.8-flash',
      ].filter((m, idx, arr) => arr.indexOf(m) === idx);

      let response: any = null;
      let lastChatError: any = null;
      let isChatQuotaExhausted = false;

      for (const modelToTry of candidateModels) {
        try {
          response = await ai.models.generateContent({
            model: modelToTry,
            contents: formattedContents,
            config: {
              systemInstruction,
              temperature: 0.78,
              topP: 0.95,
              responseMimeType: 'application/json',
              thinkingConfig: {
                thinkingBudget: 0,
              },
            },
          });
          if (response) break;
        } catch (err: any) {
          lastChatError = err;
          const msg = String(err?.message || '');
          if (err?.status === 429 || msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED') || msg.includes('quota')) {
            console.warn(`[Marvy Chat] Quota exceeded on ${modelToTry}, trying fallback model...`);
            isChatQuotaExhausted = true;
            continue;
          }
          console.warn(`[Marvy Chat] Error on ${modelToTry}:`, err.message);
          continue;
        }
      }

      // If all models hit quota, return graceful smart contextual response
      if (!response && isChatQuotaExhausted) {
        let intelligentFallback = 'Andito lang ako Boss, nakikinig sa iyo. Tuloy lang ang kuwentuhan natin!';
        if (fallbackSentiment.primaryMood === 'malungkot' || fallbackSentiment.primaryMood === 'kabado') {
          intelligentFallback = 'Naiintindihan kita Boss, andito lang ako karamay mo. Magpahinga ka muna at huminga nang malalim. Huwag mong kakalimutan na may tropa ka dito.';
        } else if (fallbackSentiment.primaryMood === 'mapagbiro' || message.toLowerCase().includes('biro') || message.toLowerCase().includes('joke')) {
          intelligentFallback = 'Haha Boss, anong sabi ng isda nung mahiwa? Da-ing! Sana napangiti kita tol!';
        } else if (message.toLowerCase().includes('araw') || message.toLowerCase().includes('kumusta')) {
          intelligentFallback = 'Ayos naman ako Boss, laging ganado makipag-usap sa iyo! Ikaw, kumusta ang lagay mo ngayon?';
        } else if (message.toLowerCase().includes('alala') || message.toLowerCase().includes('tandaan')) {
          intelligentFallback = 'Naaalala ko lahat ng pinag-usapan natin Boss, lalo na yung mga paborito at kinukuwento mo sa akin!';
        }

        return sendJson(res, 200, {
          reply: intelligentFallback,
          cleanSpeechText: sanitizeTextForSpeech(intelligentFallback),
          sentiment: fallbackSentiment,
          robotEmotion: mapMoodToRobotEmotion(fallbackSentiment.primaryMood),
          newMemory: null,
          isQuotaLimit: true,
        });
      }

      if (!response) {
        throw lastChatError || new Error('All Gemini model candidates failed to generate response');
      }

      const rawJson = response.text?.trim() || '{}';
      let parsedData: any = {};
      try {
        parsedData = JSON.parse(rawJson);
      } catch {
        // Fallback if model gave raw text
        parsedData = {
          reply: rawJson.replace(/```json/g, '').replace(/```/g, '').trim(),
          sentiment: fallbackSentiment,
          robotEmotion: mapMoodToRobotEmotion(fallbackSentiment.primaryMood),
          newMemory: null,
        };
      }

      const reply = parsedData.reply || 'Pasensya na Boss, medyo naputol ako saglit. Pwede mo bang ulitin?';
      const cleanSpeech = sanitizeTextForSpeech(reply);
      const sentiment = parsedData.sentiment || fallbackSentiment;
      const robotEmotion: RobotEmotion = parsedData.robotEmotion || mapMoodToRobotEmotion(sentiment.primaryMood);
      const newMemory = parsedData.newMemory || null;

      return sendJson(res, 200, {
        reply,
        cleanSpeechText: cleanSpeech,
        sentiment,
        robotEmotion,
        newMemory,
      });
    } catch (error: any) {
      console.error('Gemini chat error:', error);
      const status = error.status || error.code || 500;
      let userMessage = 'Nagka-aberya sa AI response. Pakisubukan muli.';

      if (status === 429 || error.message?.includes('429')) {
        userMessage = 'Naabot na ang pansamantalang quota limit. Maghintay nang kaunti o maglagay ng sariling API key sa Settings.';
      } else if (error.message) {
        userMessage = error.message;
      }

      return sendJson(res, status === 429 ? 429 : 500, {
        error: userMessage,
      });
    }
  }

  // 3b. POST /vision/analyze (Multimodal Optical Vision Perception)
  if (path === '/vision/analyze' && method === 'POST') {
    let body: any = {};
    try {
      body = await parseJsonBody(req);
    } catch {
      return sendJson(res, 400, { error: 'Invalid JSON request payload' });
    }

    const {
      imageBase64,
      mimeType = 'image/jpeg',
      prompt = 'Ano ang nakikita mo, Boss?',
      voiceGender = 'male',
      userCallsign = 'Boss',
      customApiKey,
    } = body;

    if (!imageBase64) {
      return sendJson(res, 400, { error: 'imageBase64 parameter is required for visual analysis' });
    }

    const effectiveApiKey = customApiKey || (req.headers['x-gemini-api-key'] as string) || process.env.GEMINI_API_KEY;
    if (!effectiveApiKey) {
      return sendJson(res, 500, { error: 'GEMINI_API_KEY is missing' });
    }

    // Strip data:image/...;base64, prefix if present
    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');

    // Fallback model list: try flash lite first, then flash latest, then 3.8 flash
    const visionCandidateModels = [
      'gemini-3.1-flash-lite',
      'gemini-flash-latest',
      'gemini-3.8-flash',
    ];

    let lastVisionError: any = null;
    let isVisionQuotaExhausted = false;

    for (const modelToTry of visionCandidateModels) {
      try {
        const ai = new GoogleGenAI({
          apiKey: effectiveApiKey,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build-marvy' } },
        });

        const response = await ai.models.generateContent({
          model: modelToTry,
          contents: [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    data: cleanBase64,
                    mimeType: mimeType || 'image/jpeg',
                  },
                },
                {
                  text: `Tingnan mo ang nakikita sa camera o litrato na ito mula kay ${userCallsign || 'Boss'}.
Katanungan o Mensahe ng User: "${prompt}"

Bilang si MARVY (isang transcendent Pinoy AI companion na may Neural Optical Eyes), magbigay ng natural, maikli (1 hanggang 2 maiikling pangungusap), matalino, at may empatiyang Pinoy Taglish speech reaction na parang kasama mo siyang tumitingin sa larawan.
Output JSON format:
{
  "reply": "Your natural Pinoy Taglish response to speak aloud. Strictly NO emojis, NO markdown asterisks.",
  "opticalBreakdown": "Short 1-sentence technical optical summary of what was detected (e.g. Tao na nakangiti, Laptop sa lamesa, Barong Tagalog)",
  "sentiment": {
    "primaryMood": "masaya" | "mapagbiro" | "chill" | "nagtatanong",
    "moodLabel": "Optical Scan Complete",
    "valence": 0.8,
    "arousal": "medium",
    "empathyTone": "Observant & Witty",
    "confidence": 95,
    "summary": "Visual analysis detected object/scene"
  },
  "robotEmotion": "happy" | "thinking" | "playful"
}`,
                },
              ],
            },
          ],
          config: {
            responseMimeType: 'application/json',
            temperature: 0.75,
          },
        });

        const rawJson = response.text?.trim() || '{}';
        let parsedData: any = {};
        try {
          parsedData = JSON.parse(rawJson);
        } catch {
          parsedData = {
            reply: rawJson.replace(/```json/g, '').replace(/```/g, '').trim() || 'Nakita ko Boss! Mukhang maayos at interesante yan.',
            opticalBreakdown: 'Visual object scanned',
            sentiment: {
              primaryMood: 'chill',
              moodLabel: 'Visual Scan Complete',
              valence: 0.5,
              arousal: 'medium',
              empathyTone: 'Observant',
              confidence: 85,
              summary: 'Visual scan processed',
            },
            robotEmotion: 'happy',
          };
        }

        const reply = parsedData.reply || 'Nakita ko Boss! Mukhang ayos yan ah.';
        const cleanSpeech = sanitizeTextForSpeech(reply);

        return sendJson(res, 200, {
          reply,
          cleanSpeechText: cleanSpeech,
          opticalBreakdown: parsedData.opticalBreakdown || `Optical analysis complete (${modelToTry})`,
          sentiment: parsedData.sentiment || {
            primaryMood: 'chill',
            moodLabel: 'Optical Scan Complete',
            valence: 0.6,
            arousal: 'medium',
            empathyTone: 'Observant',
            confidence: 90,
            summary: 'Scanned image',
          },
          robotEmotion: parsedData.robotEmotion || 'happy',
          isQuotaLimit: false,
        });
      } catch (err: any) {
        lastVisionError = err;
        const msg = String(err?.message || '');
        if (err?.status === 429 || msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED') || msg.includes('quota')) {
          console.warn(`[Marvy Vision] Quota exceeded on ${modelToTry}, trying next fallback...`);
          isVisionQuotaExhausted = true;
          continue;
        }
        console.warn(`[Marvy Vision] Error on ${modelToTry}:`, err.message);
        continue;
      }
    }

    // If all models hit quota limit, return graceful notification with advice
    if (isVisionQuotaExhausted) {
      const friendlyNotice = 'Boss, saglit lang ha! Naabot na ang pansamantalang Free Tier quota limit ng Gemini para sa Vision scan. Pero huwag mag-alala, pwede kang maglagay ng sarili mong libreng Gemini API Key sa Voice Settings (⚙️) para makapag-scan tayo nang walang limitasyon!';
      return sendJson(res, 200, {
        reply: friendlyNotice,
        cleanSpeechText: sanitizeTextForSpeech(friendlyNotice),
        opticalBreakdown: '⚠️ Quota limit reached sa Free Tier. Maglagay ng sariling Gemini API Key sa Settings (⚙️) para sa unlimited optical scans.',
        sentiment: {
          primaryMood: 'chill',
          moodLabel: 'Quota Notice',
          valence: 0.2,
          arousal: 'low',
          empathyTone: 'Friendly Guidance',
          confidence: 100,
          summary: 'Gemini free tier quota limit reached',
        },
        robotEmotion: 'thinking',
        isQuotaLimit: true,
      });
    }

    console.error('Vision analysis all models failed:', lastVisionError);
    return sendJson(res, 500, {
      error: `Vision error: ${lastVisionError?.message || 'Nabigo ang pagsusuri sa larawan'}`,
    });
  }


  // 4. POST /cartesia/tts — Cartesia Sonic TTS (the only voice engine). API key stays on the server.
  if (path === '/cartesia/tts' && method === 'POST') {
    let body: any = {};
    try {
      body = await parseJsonBody(req);
    } catch {
      return sendJson(res, 400, { error: 'Invalid JSON request payload' });
    }

    const rawText = typeof body.text === 'string' ? body.text.trim() : '';
    if (!rawText) {
      return sendJson(res, 400, { error: 'Text parameter is required for Cartesia TTS' });
    }
    const transcript = rawText.slice(0, CARTESIA_MAX_TEXT_CHARS);

    const requestedVoice = typeof body.voice_id === 'string' ? body.voice_id.trim() : '';
    const voiceId = requestedVoice || DEFAULT_CARTESIA_VOICE_ID;
    console.log(`[Marvy TTS] POST /api/cartesia/tts build=${SERVER_BUILD} textLen=${transcript.length} voice=${voiceId}`);
    if (!isValidCartesiaVoiceId(voiceId)) {
      return sendJson(res, 400, {
        error: 'Hindi valid ang Voice ID. Dapat ito ay Cartesia voice ID (UUID format).',
        code: 'INVALID_VOICE_ID',
      });
    }

    const apiKey = getCartesiaApiKey();
    console.log(`[Marvy TTS] CARTESIA_API_KEY present=${Boolean(apiKey)} ${apiKey ? maskSecret(apiKey) : `raw_env=${maskSecret((process.env.CARTESIA_API_KEY || '').trim())}`} model=${getCartesiaModelId()}`);
    if (!apiKey) {
      console.warn('[Marvy TTS] 503: no usable CARTESIA_API_KEY on this server instance');
      return sendJson(res, 503, {
        error: 'Walang CARTESIA_API_KEY sa server. Ilagay ang Cartesia API key sa environment variables (.env o Secrets) at i-restart ang server.',
        code: 'MISSING_CARTESIA_API_KEY',
      });
    }

    try {
      const response = await fetch('https://api.cartesia.ai/tts/bytes', {
        method: 'POST',
        headers: {
          'X-API-Key': apiKey,
          'Cartesia-Version': CARTESIA_API_VERSION,
          'Content-Type': 'application/json',
          'Accept': 'audio/mpeg',
        },
        body: JSON.stringify({
          model_id: getCartesiaModelId(),
          transcript,
          voice: { mode: 'id', id: voiceId },
          output_format: { container: 'mp3', sample_rate: 44100, bit_rate: 128000 },
        }),
      });

      if (!response.ok) {
        const detail = await response.text().catch(() => '');
        console.warn(`[Marvy TTS] Cartesia HTTP ${response.status}: ${detail.slice(0, 300)}`);
        let friendly = `Cartesia error (HTTP ${response.status}).`;
        if (response.status === 401 || response.status === 403) {
          friendly = 'Mali o hindi valid ang CARTESIA_API_KEY sa server. Pakisuri ang key.';
        } else if (response.status === 402) {
          friendly = 'Naubos na ang credits ng Cartesia account.';
        } else if (response.status === 429) {
          friendly = 'Naabot na ang rate limit ng Cartesia. Subukan ulit maya-maya.';
        } else if (response.status === 400) {
          friendly = `Hindi tinanggap ng Cartesia ang request (${detail.slice(0, 160)}).`;
        }
        return sendJson(res, response.status >= 500 ? 502 : response.status, {
          error: friendly,
          code: 'CARTESIA_API_ERROR',
        });
      }

      const audio = Buffer.from(await response.arrayBuffer());
      console.log(`[Marvy TTS] Cartesia OK bytes=${audio.byteLength}`);
      if (audio.byteLength === 0) {
        return sendJson(res, 502, { error: 'Walang audio na natanggap mula sa Cartesia.', code: 'EMPTY_AUDIO' });
      }

      res.writeHead(200, {
        'Content-Type': 'audio/mpeg',
        'Content-Length': audio.byteLength,
        'Cache-Control': 'no-store',
        'Access-Control-Allow-Origin': '*',
      });
      res.end(audio);
      return;
    } catch (error: any) {
      console.error('Cartesia TTS network error:', error);
      return sendJson(res, 502, {
        error: `Hindi makakonekta sa Cartesia: ${error?.message || 'network error'}`,
        code: 'NETWORK_ERROR',
      });
    }
  }

  // 4b. GET /download/source (Download Full Project Source Code Archive)
  if (path === '/download/source' && method === 'GET') {
    const candidatePaths = [
      nodePath.resolve(process.cwd(), 'marvy-ai-source-latest.zip'),
      nodePath.resolve(process.cwd(), 'public', 'marvy-ai-source-latest.zip'),
    ];

    let foundPath: string | null = null;
    for (const p of candidatePaths) {
      if (fs.existsSync(p)) {
        foundPath = p;
        break;
      }
    }

    if (!foundPath) {
      return sendJson(res, 404, {
        error: 'Hindi pa handa ang source zip. Pakitakbo ang bundler script o maghintay saglit.',
      });
    }

    try {
      const stat = fs.statSync(foundPath);
      res.writeHead(200, {
        'Content-Type': 'application/zip',
        'Content-Length': stat.size,
        'Content-Disposition': 'attachment; filename="marvy-ai-source-latest.zip"',
        'Access-Control-Allow-Origin': '*',
      });

      const readStream = fs.createReadStream(foundPath);
      readStream.pipe(res);
      return;
    } catch (e: any) {
      return sendJson(res, 500, { error: `Failed to stream zip: ${e.message}` });
    }
  }

  // 5. POST /sentiment/analyze (Standalone sentiment & emotional intelligence analyzer)
  if (path === '/sentiment/analyze' && method === 'POST') {
    let body: any = {};
    try {
      body = await parseJsonBody(req);
    } catch {
      return sendJson(res, 400, { error: 'Invalid JSON request payload' });
    }

    const { text } = body;
    if (!text || typeof text !== 'string') {
      return sendJson(res, 400, { error: 'Text is required for analysis' });
    }

    const sentiment = quickDetectSentiment(text);
    return sendJson(res, 200, { sentiment });
  }

  // Pass to next middleware or return 404
  if (next) {
    return next();
  }

  return sendJson(res, 404, { error: 'Not Found' });
}
